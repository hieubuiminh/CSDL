# Hướng dẫn đọc và đối chiếu SQL của website

Cập nhật ngày 11/11/2026. Tài liệu gồm 5 mục. Bạn đọc từ mục 1 đến mục 3 trước; mục 4 ghi các điểm cần lưu ý.

## 1. Kết luận cần biết

File SQL bạn đưa được giữ trong database/truy_van.sql. Backend sử dụng các truy vấn đã điều chỉnh để phục vụ web, không chép nguyên văn cả 7 câu.

Bảng đối chiếu dưới đây mô tả quyền ADMIN. Với cán bộ, backend bổ sung điều kiện Ho_So_Khai_Tu.MaCanBoTiepNhan trùng App_User.MaCanBo của tài khoản đang đăng nhập; vì vậy chỉ tính hồ sơ của cán bộ đó.

Các truy vấn giữ cùng cách lấy/đếm dữ liệu với những khác biệt ghi ở bảng mục 3. Riêng truy vấn tuổi và nguyên nhân: SQL backend chỉ đếm theo nhóm; JavaScript mới tính tổng nhóm và nguyên nhân phổ biến nhất. Vì vậy, nếu chạy riêng câu SQL backend này, kết quả chưa đầy đủ như câu SQL nguồn.

Lượt dọn hướng dẫn chỉ sửa tài liệu. Mã nguồn, SQL, cách xử lý trạng thái và dữ liệu giữ nguyên.

## 2. Mở đúng file chứa SQL

Nhấn Windows + E, sau đó Alt + D, dán đường dẫn thư mục này rồi nhấn Enter:

    E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu

Trong thư mục dự án, phần cần xem chỉ gồm:

    database\
        truy_van.sql                 Bản SQL nguồn để đối chiếu
    backend\modules\
        registrations\
            queries.js               SQL dùng chung cho danh sách và tra cứu
            index.js                 Thêm điều kiện, truyền CCCD và chạy SQL
        reports\
            queries.js               SQL của 5 báo cáo

Ba file chính có đường dẫn đầy đủ:

    E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\database\truy_van.sql
    E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations\queries.js
    E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\queries.js

Để đọc file, nhấn chuột phải → Open with / Mở bằng → Notepad hoặc Visual Studio Code nếu đã cài. Các file queries.js chứa SQL dưới dạng chuỗi JavaScript; bạn dùng Ctrl + F để tìm tên truy vấn trong bảng bên dưới.

## 3. Đối chiếu đủ 7 truy vấn

Số thứ tự giữ theo file truy_van.sql bạn đưa.

| Câu | Chức năng | Tên cần tìm ở backend | Điều kiện và kết quả đối chiếu |
|---|---|---|---|
| 1 | Tra cứu theo CCCD người mất | registrationQuery trong registrations/queries.js | Cùng đường nối bảng và tìm đúng CCCD. Backend thêm thông tin, JOIN CSYT và LIMIT 1; dùng dấu ? để nhận CCCD. Với khóa ngoại và tính duy nhất của bảng hiện tại, các phần thêm này giữ hồ sơ hợp lệ được tìm. |
| 2 | Thống kê giới tính | genderQuery trong reports/queries.js | Cùng đếm Cong_Dan có TrangThai = 'Đã mất', nhóm theo GioiTinh. Backend đổi tên cột và thêm sắp xếp. |
| 3 | Danh sách hồ sơ | registrationQuery trong registrations/queries.js | Dùng chung SELECT với tra cứu; cùng dữ liệu hồ sơ và thứ tự khi không chọn bộ lọc. Có thêm cột hiển thị, JOIN CSYT và bộ lọc tìm kiếm/trạng thái nếu người dùng chọn. |
| 4 | Thống kê địa bàn | areaQuery trong reports/queries.js | Cùng LEFT JOIN, đếm theo năm đăng ký, loại Từ chối, giữ địa bàn 0 ca và sắp số ca giảm dần. Backend lọc bằng khoảng ngày thay YEAR(...), cho phép chọn năm. |
| 5 | Nguyên nhân theo tuổi | ageCauseQuery trong reports/queries.js | Chỉ hồ sơ Đã duyệt; tuổi tại thời điểm mất, nhóm Dưới 18 / 18–60 / Trên 60. SQL viết khác nguồn: cần JavaScript tổng hợp tiếp mới có tổng nhóm và nguyên nhân phổ biến nhất. |
| 6 | Báo cáo CSYT | hospitalQuery trong reports/queries.js | Cùng đếm giấy báo tử theo ngày cấp trong quý lịch liền trước, chỉ cơ sở có trên 50 giấy. Backend tính mốc quý rồi truyền vào SQL; giữ cách ước tính nơi mất bằng tên/địa chỉ CSYT. |
| 7 | Thống kê năm mất | yearQuery trong reports/queries.js | Cùng đếm Giay_Bao_Tu theo YEAR(NgayGioMat), sắp năm tăng dần. Backend đổi tên cột kết quả. |

Có 7 chức năng nhưng 6 biến SQL vì câu 1 và câu 3 dùng chung registrationQuery.

Phần giới hạn cán bộ của danh sách/tra cứu nằm trong registrations/index.js và backend/utils/record-scope.js. Với báo cáo, tìm hàm scopedReport trong reports/queries.js. ADMIN dùng truy vấn gốc; cán bộ thêm điều kiện sở hữu bằng tham số, giữ nguyên mốc năm, trạng thái và ngưỡng trên 50 giấy trong phạm vi của mình.

## 4. Những điểm cần lưu ý

### Địa bàn: “đã đăng ký” khác “đã duyệt”

Yêu cầu là đếm hồ sơ đã đăng ký trong năm, không bắt buộc chỉ lấy hồ sơ Đã duyệt. Cả SQL nguồn và backend hiện áp dụng:

| Trạng thái | Có tính vào địa bàn trong năm đăng ký được chọn? |
|---|---|
| Chờ xử lý | Có |
| Đã duyệt | Có |
| Từ chối | Không |

Điều kiện loại Từ chối đã có trong SQL nguồn, không phải điều kiện mới tự thêm vào backend. Đây là địa bàn nơi mất và năm đăng ký hồ sơ, không phải quê quán hoặc năm mất.

Cả hai bản lấy danh mục Noi_Mat, hiện dùng cả Xã/Phường. SQL chưa có điều kiện riêng để lọc tỉnh Hà Nội hoặc chỉ lấy loại Xã; phạm vi Hà Nội dựa vào danh mục đã nạp.

### Tuổi: SQL nguồn và SQL backend viết khác

- Nguồn dùng WITH và RANK() để tự trả tổng người theo nhóm và mọi nguyên nhân đồng hạng cao nhất.
- Backend dùng SQL đếm từng nhóm/nguyên nhân; hàm summarizeAgeCauses trong reports/helpers.js tính tổng và chọn nguyên nhân cao nhất.
- Với ngày hợp lệ và tên nguyên nhân không rỗng, kết quả nghiệp vụ tương ứng. Có khác biệt ở dữ liệu biên: tuổi âm được backend tách riêng; nhóm không có ca vẫn hiện tổng 0; tên nguyên nhân rỗng được thay bằng “Chưa rõ nguyên nhân”.

Do đó, chưa thể gọi câu SQL tuổi trong backend là bản sao đầy đủ của câu SQL nguồn.

### Vì sao tổng các báo cáo có thể khác?

Giới tính đếm công dân Đã mất; địa bàn đếm hồ sơ không bị từ chối trong năm đăng ký; tuổi chỉ đếm hồ sơ Đã duyệt; năm mất đếm giấy báo tử. Các báo cáo đang dùng phạm vi khác nhau theo chính bộ truy vấn nguồn.

## 5. Cách đọc để kiểm tra SQL

1. Mở database/truy_van.sql, chọn câu số 1–7 cần kiểm tra.
2. Mở file backend tương ứng và Ctrl + F tìm tên biến ở mục 3.
3. So sánh bảng nối JOIN, điều kiện WHERE/ON, cách COUNT/GROUP BY và thứ tự ORDER BY. Tên viết tắt của bảng hoặc tên cột kết quả có thể khác nhưng cần giữ đúng ý nghĩa.
4. Với câu 1 và câu 3, xem thêm file sau vì bộ lọc được nối vào đây:

    ~~~text
    E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations\index.js
    ~~~

Tra cứu CCCD thêm điều kiện WHERE d.CCCD=?; danh sách thêm bộ lọc tìm kiếm/trạng thái. Queries.js cung cấp SQL, index.js truyền tham số và yêu cầu MySQL chạy SQL đó. File index.js còn chứa các chức năng ghi hồ sơ, không cần đọc những phần này khi chỉ đối chiếu truy vấn danh sách/tra cứu.

Chỉ sửa file database/truy_van.sql sẽ chưa đổi câu SQL mà web sử dụng. Lượt làm tài liệu này không sửa các file đó.

Kết quả kiểm thử từ lần trước nằm trong [kết quả Docker và API](work/new-schema-review/docker-first-init-results.json). Muốn mở web, đọc [hướng dẫn chạy và đăng nhập](HUONG_DAN_KHOI_TAO_CSDL_MOI.md).

