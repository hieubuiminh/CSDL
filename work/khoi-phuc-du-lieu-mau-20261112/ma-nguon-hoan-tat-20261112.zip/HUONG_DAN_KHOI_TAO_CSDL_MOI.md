# Hướng dẫn cài đặt, mở web và đăng nhập

Cập nhật ngày 12/11/2026.

Website chỉ phục vụ trên máy này tại http://localhost:3001. MySQL không mở cổng ra ngoài. CSDL đang dùng là quan_li_khai_tu; giữ nguyên CSDL và các volume cũ.

## 1. Mở bản đang có trên máy

Máy này đã được khởi tạo và đã có tài khoản trong lần kiểm tra trước đó. Bạn mở lại dịch vụ, không nạp lại SQL mẫu.

1. Mở Docker Desktop và đợi Docker sẵn sàng.
2. Mở PowerShell, chạy:

    ~~~powershell
    cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --no-build
    ~~~

3. Mở http://localhost:3001 và nhấn Ctrl + F5.
4. Đăng nhập bằng tài khoản bạn đã tạo cho bản này. Nếu quên mật khẩu, chọn Quên mật khẩu? và dùng thông tin khôi phục đã đặt.

## 2. Chỉ dùng khi cài lần đầu trên máy mới

### Bước 1. Chuẩn bị

- Máy đã cài Docker Desktop và chạy được Linux containers.
- Có PowerShell và trình duyệt để mở website.
- Có đủ mã nguồn dự án, gồm backend, public, database, docker, package.json và .dockerignore; giữ đúng cấu trúc thư mục.
- Có kết nối Internet để Docker tải các image/thư viện chưa có khi dựng lần đầu. Ứng dụng vẫn chỉ phục vụ local.

Docker đã cung cấp môi trường Node.js và MySQL theo cấu hình dự án; không cần cài riêng hai phần mềm này để chạy bằng cách dưới đây.

### Bước 2. Mở Docker và khởi chạy dự án

Mở Docker Desktop, đợi dịch vụ sẵn sàng. Đặt mã nguồn tại thư mục dự án rồi mở PowerShell và chạy:

~~~powershell
cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
~~~

Nếu đặt dự án ở thư mục khác thì thay đường dẫn sau cd bằng vị trí thực tế. Chạy lệnh trong thư mục có package.json và thư mục docker.

Lệnh sẽ dựng ứng dụng và khởi động MySQL. Docker tạo vùng lưu trữ nếu chưa có và chỉ chạy SQL khởi tạo khi vùng dữ liệu MySQL còn mới, theo thứ tự:

| Thứ tự | File | Công dụng |
|---|---|---|
| 1 | database/tao_bang.sql | Tạo 9 bảng nghiệp vụ và 6 trigger. |
| 2 | database/du_lieu_mau.sql | Nạp 491 bản ghi mẫu ban đầu. |
| 3 | database/app_setup.sql | Tạo bảng tài khoản web và liên kết cán bộ. |

database/truy_van.sql là bản SQL để đọc kết quả 7 chức năng, không phải bước tạo bảng hoặc nạp dữ liệu.

Giữ app_setup.sql vì website cần bảng tài khoản để đăng nhập.

### Bước 3. Kiểm tra cài đặt

Sau khi lệnh khởi chạy hoàn tất, kiểm tra:

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml ps
~~~

Kết quả cần có dịch vụ db ở trạng thái healthy và app đang chạy. Sau đó mở http://localhost:3001. Nếu chưa mở được, xem mục 4; không nạp lại SQL bằng tay.

### Bước 4. Tạo ADMIN và dùng lần đầu

Chỉ khi chưa có ADMIN, web hiện Tạo tài khoản quản trị. Nhập họ tên, tên đăng nhập, mật khẩu ít nhất 10 ký tự, nhập lại mật khẩu, chọn câu hỏi khôi phục và câu trả lời ít nhất 3 ký tự.

Nếu web hiện Đăng nhập thì đã có tài khoản, không cần tạo lại. Dữ liệu mẫu không có mật khẩu ADMIN cài sẵn; tài khoản cũ ở cổng 3000 không tự chuyển sang bản mới. Dữ liệu và tài khoản trên các máy không tự đồng bộ.

Sau khi vào được giao diện, mở mục Hồ sơ để xem dữ liệu, vào Tra cứu và thử CCCD mẫu 001000000001. Những lần sử dụng sau làm theo mục 1, không thực hiện lại bước tạo bảng hoặc nạp mẫu.

Để tạo tài khoản cán bộ: ADMIN mở Tài khoản → chọn vai trò Cán bộ → chọn cán bộ tiếp nhận liên kết → nhập thông tin rồi tạo. Một cán bộ chỉ gắn một tài khoản. Cấp mã mời cũng phải chọn cán bộ; người đăng ký không tự đổi mã cán bộ đã gắn với lời mời.

Cán bộ chỉ xem, tra cứu/in, xuất CSV và thống kê hồ sơ do mình tiếp nhận. Người tiếp nhận trong hồ sơ mới được cố định là chính cán bộ đăng nhập. ADMIN xem toàn bộ. Tài khoản canbo01 trên máy này đã được gắn CB01 – Vũ Đức Bình; mật khẩu tạm được gửi riêng trong chat.

Khi đưa phần này vào báo cáo, có thể dùng ba ảnh minh họa: trạng thái các dịch vụ sau cài đặt, màn hình tạo ADMIN đầu tiên và giao diện tổng quan sau khi vào hệ thống. Đây là gợi ý ảnh cần chụp, không phải ảnh đã được tạo trong lần viết hướng dẫn này.

## 3. Dừng rồi mở lại mà giữ dữ liệu

Tại thư mục dự án, dừng dịch vụ bằng:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml stop

Khi cần dùng lại, thực hiện mục 1. Không dùng lệnh xóa volume để xử lý đăng nhập hoặc để đưa số hồ sơ về số mẫu ban đầu.

## 4. Nếu chưa mở được hoặc có thông báo lỗi

Trước hết kiểm tra đúng địa chỉ localhost:3001, nhấn Ctrl + F5; nếu có nút Thử lại thì bấm sau khi dịch vụ sẵn sàng.

Xem trạng thái và nhật ký bằng:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml ps
    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml logs --tail=80 db app

MySQL cần healthy và app cần đang chạy. Nếu cổng 3001 bị ứng dụng khác chiếm, cần xử lý trùng cổng.

Đọc nhật ký để xác định nguyên nhân. Không chạy lại toàn bộ SQL mẫu hoặc xóa CSDL để thử sửa lỗi.

## 5. Cập nhật ứng dụng và SQL là hai việc khác nhau

Khi cần áp dụng mã ứng dụng mới và dịch vụ đang chạy:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml build app
    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --no-deps --no-build --force-recreate app

Sau đó nhấn Ctrl + F5. Các lệnh này thay container app, giữ dữ liệu MySQL.

Sửa file SQL rồi dựng lại ứng dụng không tự cập nhật CSDL đã có. Các thay đổi SQL cần được xem xét và chạy bổ sung riêng; không dùng cách nạp lại schema/dữ liệu mẫu trên CSDL đang dùng.

### Bổ sung liên kết tài khoản cán bộ cho CSDL đã có

File database/cap_nhat_lien_ket_can_bo.sql chỉ bổ sung cột và ràng buộc cho App_User. Bản cài mới đã có trong app_setup.sql. CSDL trên máy này đã được cập nhật; không cần chạy lại.

Khi áp dụng cho một CSDL web cũ khác, sao lưu trước rồi chạy tại thư mục dự án:

~~~powershell
Get-Content -Raw -Encoding UTF8 database/cap_nhat_lien_ket_can_bo.sql | docker exec -i khai-tu-bang-moi-local-db-1 sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot --default-character-set=utf8mb4'
~~~

Nếu file báo tài khoản cán bộ chưa liên kết thì dừng để xác định đúng cán bộ cho từng tài khoản; không tự gán. Chỉ dựng lại app sau khi SQL chạy thành công. Không tạo lại 9 bảng nghiệp vụ.

## 6. Thông tin tham khảo khi cần

- Mẫu ban đầu có 200 công dân, 100 giấy báo tử, 100 hồ sơ và 64 an táng. Số thực tế tăng khi bạn thêm hồ sơ.
- CCCD mẫu để tra cứu: 001000000001.
- Người mất nằm ở Giay_Bao_Tu.CCCD_NgMat; hồ sơ nối qua SoGiayBaoTu.
- Bộ nguồn gốc và cấu hình trước chuyển bảng nằm trong work/truoc-khi-dung-bang-moi-20261110/. Dùng bản SQL hiện tại trong database/; nguồn gốc tạo bảng có lệnh DROP DATABASE đã được bỏ ở bản dùng cho app.
- Nếu cần quay về bản cũ, xem mục 7 dưới đây.
- Nếu cần đối chiếu câu SQL, đọc [hướng dẫn truy vấn](HUONG_DAN_TRUY_VAN_BACKEND.md).

Chỉ khi tạo CSDL mới/riêng bằng công cụ MySQL, dùng MySQL từ 8.0.16 và chạy theo thứ tự: tao_bang.sql → du_lieu_mau.sql đúng một lần → app_setup.sql nếu dùng web. Chạy truy_van.sql khi cần xem kết quả. Nếu gặp trùng mã, dừng để kiểm tra, không ghi đè dữ liệu đang có.

## 7. Khi cần mở lại bản cũ

Chỉ dùng khi bạn muốn quay về bản trước và image, volume cũ còn trên máy. Chạy từ thư mục dự án:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml down
    docker compose -p he_thong_quan_ly_dang_ky_khai_tu -f work/truoc-khi-dung-bang-moi-20261110/docker/compose.yaml up -d --no-build

Bản cũ mở ở http://localhost:3000. Các lệnh trên giữ dữ liệu; không thêm tùy chọn xóa volume.

