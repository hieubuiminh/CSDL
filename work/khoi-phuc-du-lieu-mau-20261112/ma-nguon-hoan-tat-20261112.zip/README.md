# Hệ thống quản lý đăng ký khai tử

Chỉ chạy local trên máy cá nhân tại http://localhost:3001. CSDL dùng tên quan_li_khai_tu. MySQL không công bố cổng ra ngoài.

## Bạn cần đọc file nào?

| Bạn muốn làm gì? | File cần đọc |
|---|---|
| Mở web, đăng nhập, dừng/mở lại hoặc cài lần đầu | [Hướng dẫn chạy web và đăng nhập](HUONG_DAN_KHOI_TAO_CSDL_MOI.md) |
| Xem SQL nằm ở đâu, có khớp truy vấn bạn đưa không | [Hướng dẫn truy vấn](HUONG_DAN_TRUY_VAN_BACKEND.md) |

Hiện có 3 file MD chính, tính cả README này. Hướng dẫn khởi tạo bao gồm cài đặt, mở web và đăng nhập.

## Các thư mục chính

| Thư mục | Nội dung |
|---|---|
| backend | Xử lý chức năng và thực thi SQL. |
| public | Giao diện web. |
| database | SQL tạo bảng, mẫu, tài khoản và truy vấn. |
| docker | Cấu hình chạy local. |
| tests | Các kiểm thử. |
| docs | Script kiểm tra ràng buộc chỉ đọc. |
| work | Bản lưu và kết quả kiểm tra. |

Người mất được liên kết qua Giay_Bao_Tu.CCCD_NgMat; Ho_So_Khai_Tu nối qua SoGiayBaoTu.

## Ràng buộc hiện có

- Người đi khai khác người mất.
- Ngày mất ≤ ngày cấp giấy báo tử ≤ ngày đăng ký, so sánh theo ngày.
- Một công dân có tối đa một hồ sơ qua các khóa duy nhất trên giấy báo tử và hồ sơ.
- Công dân được đánh dấu Đã mất với hồ sơ không bị từ chối, kể cả Chờ xử lý; không tự chuyển về Còn sống khi từ chối/xóa hồ sơ.

Riêng 9 bảng nghiệp vụ có 9 khóa ngoại, 7 CHECK, 4 UNIQUE và 6 trigger. [Script kiểm tra chỉ đọc](docs/kiem_tra_rang_buoc_chi_doc.sql) giữ nguyên trong dự án. App_User có thêm khóa ngoại, UNIQUE và CHECK cho liên kết cán bộ.

ADMIN xem toàn bộ hồ sơ và quản lý tài khoản/danh mục. Mỗi tài khoản cán bộ gắn duy nhất một Can_Bo qua App_User.MaCanBo. Cán bộ chỉ xem, tra cứu/in, xuất CSV, đổi trạng thái và thống kê hồ sơ có MaCanBoTiepNhan trùng mã của mình; hồ sơ mới tự gắn chính cán bộ đó. Quyền được kiểm tra ở backend trên mỗi yêu cầu. Xóa hồ sơ chỉ dành cho ADMIN.

## Ghi chú thiết kế để xem lại sau

Các đề xuất dưới đây chưa được tự thêm vào mô hình:

- Bảo vệ ngày sinh ≤ ngày mất và ngày an táng ≥ ngày mất trên mọi đường cập nhật.
- Phát hiện khác biệt họ tên/ngày sinh khi nhập lại CCCD đã có.
- Lưu lịch sử người xử lý, lý do từ chối/đính chính và quy trình mở lại hồ sơ.
- Lưu UBND tại thời điểm tiếp nhận để giữ lịch sử khi cán bộ chuyển đơn vị.
- Thêm tỉnh/thành và nơi mất tại CSYT thành trường có cấu trúc để thống kê chính xác hơn.

App_User là phần bổ sung của web. Cấu trúc 9 bảng nghiệp vụ vẫn theo bộ SQL nguồn. CSDL và volume của bản cũ được giữ nguyên.

## Thứ tự trình bày phần website trong báo cáo

Có thể đặt hướng dẫn cài đặt ở cuối phần trình bày website, trước kết luận chương:

1. Giới thiệu website và phạm vi sử dụng.
2. Các chức năng và phân quyền ADMIN/cán bộ.
3. Giao diện từng chức năng, ảnh minh họa và chú thích dưới ảnh.
4. Kiểm tra hoạt động của website.
5. Hướng dẫn cài đặt và sử dụng.
6. Đánh giá và kết luận chương.

Mục cài đặt gồm: chuẩn bị môi trường → khởi chạy dự án → kiểm tra dịch vụ → tạo ADMIN và truy cập lần đầu. Các bước đầy đủ đã có ở mục 2 của [hướng dẫn cài đặt](HUONG_DAN_KHOI_TAO_CSDL_MOI.md). Không cần tạo thêm file MD riêng cho phần này.

