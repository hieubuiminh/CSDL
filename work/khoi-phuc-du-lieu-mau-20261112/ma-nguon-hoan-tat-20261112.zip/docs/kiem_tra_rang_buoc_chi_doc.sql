-- CHỈ ĐỌC: kiểm tra bộ bảng mới quan_li_khai_tu; không đổi dữ liệu/cấu trúc.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
USE quan_li_khai_tu;

-- Chỉ trả số lượng, không in họ tên/CCCD.
SELECT
  (SELECT COUNT(*) FROM Cong_Dan) AS TongCongDan,
  (SELECT COUNT(*) FROM Giay_Bao_Tu) AS TongGiayBaoTu,
  (SELECT COUNT(*) FROM Ho_So_Khai_Tu) AS TongHoSo,
  (SELECT COUNT(*) FROM Ho_So_Khai_Tu h JOIN Giay_Bao_Tu g ON g.SoGiayBaoTu=h.SoGiayBaoTu
    WHERE h.CCCD_NgKhaiTu=g.CCCD_NgMat) AS NguoiKhaiTrungNguoiMat,
  (SELECT COUNT(*) FROM Giay_Bao_Tu WHERE DATE(NgayGioMat)>NgayCap) AS NgayMatSauNgayCap,
  (SELECT COUNT(*) FROM Ho_So_Khai_Tu h JOIN Giay_Bao_Tu g ON g.SoGiayBaoTu=h.SoGiayBaoTu
    WHERE g.NgayCap>h.NgayDangKi) AS NgayCapSauNgayDangKy,
  (SELECT COUNT(*) FROM (
    SELECT CCCD_NgMat FROM Giay_Bao_Tu GROUP BY CCCD_NgMat HAVING COUNT(*)>1
  ) d) AS CongDanCoNhieuGiayBaoTu,
  (SELECT COUNT(*) FROM (
    SELECT SoGiayBaoTu FROM Ho_So_Khai_Tu GROUP BY SoGiayBaoTu HAVING COUNT(*)>1
  ) h) AS GiayBaoTuGanNhieuHoSo,
  (SELECT COUNT(*) FROM (
    SELECT SoGiayKhaiTu FROM An_Tang GROUP BY SoGiayKhaiTu HAVING COUNT(*)>1
  ) a) AS HoSoCoNhieuAnTang,
  (SELECT COUNT(*) FROM Ho_So_Khai_Tu h
    JOIN Giay_Bao_Tu g ON g.SoGiayBaoTu=h.SoGiayBaoTu
    JOIN Cong_Dan c ON c.CCCD=g.CCCD_NgMat
    WHERE h.TrangThaiHoSo<>'Từ chối' AND c.TrangThai<>'Đã mất') AS HoSoHopLeChuaDongBoDaMat;

SELECT TABLE_NAME AS TenBang, CONSTRAINT_NAME AS TenRangBuoc, CONSTRAINT_TYPE AS Loai
FROM information_schema.TABLE_CONSTRAINTS
WHERE TABLE_SCHEMA=DATABASE()
ORDER BY TABLE_NAME, CONSTRAINT_TYPE, CONSTRAINT_NAME;

SELECT TRIGGER_NAME AS TenTrigger, EVENT_OBJECT_TABLE AS TenBang,
       ACTION_TIMING AS ThoiDiem, EVENT_MANIPULATION AS ThaoTac
FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()
ORDER BY TRIGGER_NAME;
