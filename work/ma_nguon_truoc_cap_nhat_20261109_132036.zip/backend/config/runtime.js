const crypto = require('crypto');

const secret = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? null : 'local-development-secret-change-before-deployment');
// Compose publishes the app on 127.0.0.1; recovery-by-name remains local-only.
const secureCookie = process.env.COOKIE_SECURE === 'true' || (process.env.COOKIE_SECURE !== 'false' && process.env.NODE_ENV === 'production');
const localAdminRecoveryEnabled = process.env.ALLOW_LOCAL_PASSWORD_RESET === 'true' && String(process.env.ADMIN_RECOVERY_TOKEN || '').length >= 32;
const localAdminNameFallbackEnabled = process.env.ALLOW_LOCAL_PASSWORD_RESET === 'true';
const isLocalAdminNameRecoveryRequest = req => localAdminNameFallbackEnabled &&
  ['localhost', '127.0.0.1', '::1', '[::1]'].includes(String(req.hostname || '').toLowerCase());
const matchesSecret = (provided, expected) => {
  const actual = Buffer.from(String(provided || ''));
  const configured = Buffer.from(String(expected || ''));
  return actual.length > 0 && actual.length === configured.length && crypto.timingSafeEqual(actual, configured);
};

module.exports = {
  secret,
  secureCookie,
  localAdminRecoveryEnabled,
  isLocalAdminNameRecoveryRequest,
  matchesSecret
};