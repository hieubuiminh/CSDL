const express = require('express');
const { pool } = require('../config/database');
const { asyncRoute, required, localDate } = require('../utils/http');
const { adminOnly } = require('../middleware/auth');

const router = express.Router();
// Dashboard, registration creation/search, certificate lookup and status updates.
router.get('/dashboard', asyncRoute(async (_req,res) => {
  const [[{ total }]] = await pool.query('SELECT COUNT(*) AS total FROM Ho_So_Khai_Tu');
  const [[{ thisMonth }]] = await pool.query('SELECT COUNT(*) AS thisMonth FROM Ho_So_Khai_Tu WHERE NgayDangKi >= DATE_FORMAT(CURDATE(), "%Y-%m-01") AND NgayDangKi < DATE_ADD(DATE_FORMAT(CURDATE(), "%Y-%m-01"), INTERVAL 1 MONTH)');
  const [[{ completed }]] = await pool.query("SELECT COUNT(*) AS completed FROM Ho_So_Khai_Tu WHERE TrangThaiHoSo='Đã hoàn tất'");
  const [[{ active }]] = await pool.query("SELECT COUNT(*) AS active FROM Ho_So_Khai_Tu WHERE TrangThaiHoSo IN ('Đã tiếp nhận','Đang xử lý')");
  const [gender] = await pool.query("SELECT c.GioiTinh AS name, COUNT(*) AS value FROM Ho_So_Khai_Tu h JOIN Cong_Dan c ON c.CCCD=h.CCCD_NgMat GROUP BY c.GioiTinh ORDER BY value DESC");
  const [yearly] = await pool.query('SELECT YEAR(NgayDangKi) AS year, COUNT(*) AS value FROM Ho_So_Khai_Tu GROUP BY YEAR(NgayDangKi) ORDER BY year');
  const [recent] = await pool.query(`${registrationQuery} ORDER BY h.NgayDangKi DESC, h.SoGiayKhaiTu DESC LIMIT 6`);
  res.json({ cards: { total, thisMonth, completed, active }, gender, yearly, recent });
}));
const registrationQuery = `SELECT h.SoGiayKhaiTu AS id, h.NgayDangKi AS registeredAt, h.QuanHe AS relation, h.TrangThaiHoSo AS status,
 d.CCCD AS deceasedId, d.HoTen AS deceasedName, d.NgaySinh AS birthDate,
 a.CCCD AS applicantId, a.HoTen AS applicantName, g.NgayGioMat AS deathAt,
 n.TenNguyenNhan AS cause, u.TenUBND AS officeName, cb.HoTen AS officerName,
 g.SoGiayBaoTu AS certificateId, cs.TenCSYT AS hospitalName
 FROM Ho_So_Khai_Tu h JOIN Cong_Dan d ON d.CCCD=h.CCCD_NgMat JOIN Cong_Dan a ON a.CCCD=h.CCCD_NgKhaiTu
 JOIN Giay_Bao_Tu g ON g.SoGiayBaoTu=h.SoGiayBaoTu JOIN Nguyen_Nhan n ON n.MaNguyenNhan=g.MaNguyenNhan
 JOIN Can_Bo cb ON cb.MaCanBo=h.MaCanBoTiepNhan JOIN UBND u ON u.MaUBND=cb.MaUBND JOIN CSYT cs ON cs.MaCSYT=g.MaCSYT`;
router.get('/registrations', asyncRoute(async (req,res) => {
  const search = `%${String(req.query.search || '').trim()}%`;
  const status = String(req.query.status || '').trim();
  const [rows] = await pool.execute(`${registrationQuery} WHERE (?='' OR h.TrangThaiHoSo=?) AND (?='%%' OR h.SoGiayKhaiTu LIKE ? OR g.SoGiayBaoTu LIKE ? OR d.HoTen LIKE ? OR d.CCCD LIKE ? OR a.HoTen LIKE ? OR a.CCCD LIKE ?) ORDER BY h.NgayDangKi DESC`, [status,status,search,search,search,search,search,search,search]);
  res.json(rows);
}));
router.get('/registrations/:cccd', asyncRoute(async (req,res) => {
  const [rows] = await pool.execute(`${registrationQuery} WHERE d.CCCD=? LIMIT 1`, [req.params.cccd]);
  if (!rows.length) return res.status(404).json({ error: 'Chưa tìm thấy hồ sơ theo CCCD này.' });
  res.json(rows[0]);
}));
router.post('/registrations', asyncRoute(async (req,res) => {
  const b = req.body;
  const groups = { deceased:['cccd','name','birthDate','gender','hometown','ethnicity','phone'], applicant:['cccd','name','birthDate','gender','hometown','ethnicity','phone'], certificate:['id','issuedAt','deathAt','placeDetail','causeDescription','causeId','wardId','hospitalId'], registration:['id','registeredAt','relation','officerId'] };
  for (const [group, fields] of Object.entries(groups)) { const missing = required(b[group] || {}, fields); if (missing.length) return res.status(400).json({ error: `Thiếu thông tin bắt buộc trong nhóm ${group}.` }); }
  if (b.deceased.cccd === b.applicant.cccd) return res.status(400).json({ error: 'Người khai tử phải khác người đã mất.' });
  if (!localDate(b.certificate.issuedAt) || !localDate(b.registration.registeredAt) || !localDate(String(b.certificate.deathAt).slice(0,10))) return res.status(400).json({ error: 'Ngày tháng không hợp lệ.' });
  if (String(b.certificate.deathAt).slice(0,10) > b.certificate.issuedAt || b.certificate.issuedAt > b.registration.registeredAt) return res.status(400).json({ error: 'Ngày mất ≤ ngày cấp giấy báo tử ≤ ngày đăng ký khai tử.' });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const citizenSql = `INSERT IGNORE INTO Cong_Dan (CCCD,HoTen,NgaySinh,GioiTinh,QueQuan,DanToc,SDT,TrangThai) VALUES (?,?,?,?,?,?,?,'Đang sống')`;
    for (const person of [b.deceased,b.applicant]) await conn.execute(citizenSql, [person.cccd,person.name,person.birthDate,person.gender,person.hometown,person.ethnicity,person.phone]);
    await conn.execute('INSERT INTO Giay_Bao_Tu (SoGiayBaoTu,NgayCap,NgayGioMat,NoiMatChiTiet,MoTaNguyenNhan,MaNguyenNhan,MaXaPhuong,MaCSYT) VALUES (?,?,?,?,?,?,?,?)', [b.certificate.id,b.certificate.issuedAt,b.certificate.deathAt,b.certificate.placeDetail,b.certificate.causeDescription,b.certificate.causeId,b.certificate.wardId,b.certificate.hospitalId]);
    await conn.execute('INSERT INTO Ho_So_Khai_Tu (SoGiayKhaiTu,NgayDangKi,QuanHe,TrangThaiHoSo,SoGiayBaoTu,CCCD_NgMat,CCCD_NgKhaiTu,MaCanBoTiepNhan) VALUES (?,?,? ,?, ?,?,?,?)', [b.registration.id,b.registration.registeredAt,b.registration.relation,b.registration.status || 'Đã tiếp nhận',b.certificate.id,b.deceased.cccd,b.applicant.cccd,b.registration.officerId]);
    if (b.burial && b.burial.id) {
      if (required(b.burial, ['id','form','cemetery','date']).length || !localDate(b.burial.date)) throw Object.assign(new Error('Nếu nhập thông tin an táng, hãy điền đủ mã, hình thức, địa điểm và ngày thực hiện.'), { statusCode: 400 });
      await conn.execute('INSERT INTO An_Tang (MaAnTang,HinhThuc,TenNghiaTrang,NgayAnTang,SoGiayKhaiTu) VALUES (?,?,?,?,?)', [b.burial.id,b.burial.form,b.burial.cemetery,b.burial.date,b.registration.id]);
    }
    await conn.execute("UPDATE Cong_Dan SET TrangThai='Đã mất' WHERE CCCD=?", [b.deceased.cccd]);
    await conn.commit();
    res.status(201).json({ id: b.registration.id, message: 'Đã tạo hồ sơ khai tử.' });
  } catch (error) { await conn.rollback(); throw error; } finally { conn.release(); }
}));
router.patch('/registrations/:id/status', asyncRoute(async (req,res) => {
  const allowed = ['Đã tiếp nhận','Đang xử lý','Đã hoàn tất','Từ chối'];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: 'Trạng thái hồ sơ không hợp lệ.' });
  const [r] = await pool.execute('UPDATE Ho_So_Khai_Tu SET TrangThaiHoSo=? WHERE SoGiayKhaiTu=?', [req.body.status,req.params.id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'Không tìm thấy hồ sơ.' });
  res.json({ ok: true });
}));


router.delete('/registrations/:id', adminOnly, asyncRoute(async (req,res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[record]] = await conn.execute('SELECT SoGiayBaoTu, CCCD_NgMat, CCCD_NgKhaiTu FROM Ho_So_Khai_Tu WHERE SoGiayKhaiTu=? FOR UPDATE', [req.params.id]);
    if (!record) {
      await conn.rollback();
      return res.status(404).json({ error: 'Không tìm thấy hồ sơ cần xóa.' });
    }
    await conn.execute('DELETE FROM An_Tang WHERE SoGiayKhaiTu=?', [req.params.id]);
    await conn.execute('DELETE FROM Ho_So_Khai_Tu WHERE SoGiayKhaiTu=?', [req.params.id]);
    await conn.execute('DELETE FROM Giay_Bao_Tu WHERE SoGiayBaoTu=? AND NOT EXISTS (SELECT 1 FROM Ho_So_Khai_Tu WHERE SoGiayBaoTu=?)', [record.SoGiayBaoTu, record.SoGiayBaoTu]);
    const [deletedCitizens] = await conn.execute('DELETE FROM Cong_Dan WHERE CCCD IN (?, ?) AND NOT EXISTS (SELECT 1 FROM Ho_So_Khai_Tu h WHERE h.CCCD_NgMat=Cong_Dan.CCCD OR h.CCCD_NgKhaiTu=Cong_Dan.CCCD)', [record.CCCD_NgMat, record.CCCD_NgKhaiTu]);
    await conn.commit();
    res.json({ ok: true, deletedCitizens: deletedCitizens.affectedRows, message: 'Đã xóa hồ sơ khai tử.' });
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally { conn.release(); }
}));
module.exports = router;
