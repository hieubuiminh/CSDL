const express = require('express');
const crypto = require('crypto');
const { pool } = require('../config/database');
const { asyncRoute, required } = require('../utils/http');
const { adminOnly } = require('../middleware/auth');
const { buildCredential, validateRecovery, invitations } = require('../utils/auth');

const router = express.Router();
// Admin account management and reference catalogs used by registration forms.
router.post('/users', adminOnly, asyncRoute(async (req,res) => {
  const missing = required(req.body, ['username','password','displayName','securityQuestion','securityAnswer']);
  if (missing.length) return res.status(400).json({ error: 'Hãy nhập họ tên, tên đăng nhập, mật khẩu và câu hỏi khôi phục.' });
  if (String(req.body.password).length < 10) return res.status(400).json({ error: 'Mật khẩu cần có ít nhất 10 ký tự.' });
  const recovery = validateRecovery(req.body);
  if (!recovery) return res.status(400).json({ error: 'Chọn câu hỏi khôi phục và nhập câu trả lời dài ít nhất 3 ký tự.' });
  const username = String(req.body.username).trim();
  if (!/^[\p{L}\p{N}_.-]{3,40}$/u.test(username)) return res.status(400).json({ error: 'Tên đăng nhập cần dài 3–40 ký tự, chỉ gồm chữ, số, dấu chấm, gạch dưới hoặc gạch ngang.' });
  const credential = await buildCredential(req.body.password, recovery.questionId, recovery.answer);
  try { await pool.execute('INSERT INTO App_User (Username,PasswordHash,DisplayName,Role) VALUES (?,?,?,?)', [username,credential,String(req.body.displayName).trim(),'staff']); }
  catch (error) { if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Tên đăng nhập đã được sử dụng.' }); throw error; }
  res.status(201).json({ ok: true, message: 'Đã tạo tài khoản cán bộ.' });
}));
router.post('/invitations', adminOnly, (_req, res) => {
  const now = Date.now(); for (const [key, invite] of invitations) if (invite.expiresAt <= now || invite.used) invitations.delete(key);
  const code = crypto.randomBytes(5).toString('hex').toUpperCase();
  const expiresAt = now + 24 * 60 * 60 * 1000; invitations.set(code, { expiresAt, used:false });
  res.status(201).json({ code, expiresAt: new Date(expiresAt).toISOString() });
});

router.get('/lookups', asyncRoute(async (_req, res) => {
  const [csyt] = await pool.query('SELECT MaCSYT AS id, TenCSYT AS name FROM CSYT ORDER BY TenCSYT');
  const [causes] = await pool.query('SELECT MaNguyenNhan AS id, TenNguyenNhan AS name FROM Nguyen_Nhan ORDER BY TenNguyenNhan');
  const [wards] = await pool.query('SELECT MaXaPhuong AS id, TenXaPhuong AS name FROM Noi_Mat ORDER BY TenXaPhuong');
  const [officers] = await pool.query('SELECT cb.MaCanBo AS id, cb.HoTen AS name, cb.MaUBND AS officeId, u.TenUBND AS officeName FROM Can_Bo cb JOIN UBND u ON u.MaUBND=cb.MaUBND ORDER BY cb.HoTen');
  const [offices] = await pool.query('SELECT MaUBND AS id, TenUBND AS name FROM UBND ORDER BY TenUBND');
  res.json({ csyt, causes, wards, officers, offices });
}));
router.post('/master/:type', adminOnly, asyncRoute(async (req,res) => {
  const b=req.body;
  const types={
    cause:{fields:['id','name'],sql:'INSERT INTO Nguyen_Nhan (MaNguyenNhan,TenNguyenNhan) VALUES (?,?)'},
    hospital:{fields:['id','name','address','phone'],sql:'INSERT INTO CSYT (MaCSYT,TenCSYT,DiaChi,SDT) VALUES (?,?,?,?)'},
    ward:{fields:['id','name'],sql:'INSERT INTO Noi_Mat (MaXaPhuong,TenXaPhuong) VALUES (?,?)'},
    office:{fields:['id','name','level','address','phone'],sql:'INSERT INTO UBND (MaUBND,TenUBND,CapHanhChinh,DiaChi,SDT) VALUES (?,?,?,?,?)'},
    officer:{fields:['id','identity','name','role','phone','officeId'],sql:'INSERT INTO Can_Bo (MaCanBo,CCCD,HoTen,ChucVu,SDT,MaUBND) VALUES (?,?,?,?,?,?)'}
  };
  const config=types[req.params.type];
  if(!config) return res.status(404).json({error:'Danh mục không hợp lệ.'});
  if(required(b,config.fields).length) return res.status(400).json({error:'Hãy điền đủ các trường bắt buộc.'});
  await pool.execute(config.sql,config.fields.map(k=>String(b[k]).trim()));
  res.status(201).json({ok:true});
}));


module.exports = router;
