const express = require('express');
const { pool } = require('../config/database');
const { asyncRoute } = require('../utils/http');

const router = express.Router();
// Statistics required by the project brief.
router.get('/reports/areas', asyncRoute(async (req,res) => {
  const year = Number(req.query.year) || new Date().getFullYear();
  const [rows] = await pool.execute(`SELECT nm.MaXaPhuong AS id,nm.TenXaPhuong AS name,COUNT(h.SoGiayKhaiTu) AS value FROM Noi_Mat nm LEFT JOIN Giay_Bao_Tu g ON g.MaXaPhuong=nm.MaXaPhuong LEFT JOIN Ho_So_Khai_Tu h ON h.SoGiayBaoTu=g.SoGiayBaoTu AND YEAR(h.NgayDangKi)=? GROUP BY nm.MaXaPhuong,nm.TenXaPhuong ORDER BY value DESC,nm.TenXaPhuong`, [year]);
  res.json({ year, rows });
}));
router.get('/reports/age-causes', asyncRoute(async (_req,res) => {
  const [rows] = await pool.query(`SELECT CASE WHEN TIMESTAMPDIFF(YEAR,d.NgaySinh,g.NgayGioMat)<18 THEN 'Dưới 18' WHEN TIMESTAMPDIFF(YEAR,d.NgaySinh,g.NgayGioMat)<=60 THEN '18–60' ELSE 'Trên 60' END AS ageGroup,n.TenNguyenNhan AS cause,COUNT(*) AS value FROM Ho_So_Khai_Tu h JOIN Cong_Dan d ON d.CCCD=h.CCCD_NgMat JOIN Giay_Bao_Tu g ON g.SoGiayBaoTu=h.SoGiayBaoTu JOIN Nguyen_Nhan n ON n.MaNguyenNhan=g.MaNguyenNhan GROUP BY ageGroup,n.TenNguyenNhan ORDER BY ageGroup,value DESC`);
  res.json(rows);
}));
router.get('/reports/hospitals', asyncRoute(async (_req,res) => {
  const [rows] = await pool.query(`SELECT c.MaCSYT AS id,c.TenCSYT AS name,COUNT(*) AS value FROM Giay_Bao_Tu g JOIN CSYT c ON c.MaCSYT=g.MaCSYT WHERE g.NgayCap >= MAKEDATE(YEAR(CURDATE()),1) + INTERVAL (QUARTER(CURDATE())-1)*3 MONTH - INTERVAL 3 MONTH AND g.NgayCap < MAKEDATE(YEAR(CURDATE()),1) + INTERVAL (QUARTER(CURDATE())-1)*3 MONTH GROUP BY c.MaCSYT,c.TenCSYT HAVING COUNT(*)>50 ORDER BY value DESC`);
  res.json(rows);
}));
router.get('/reports/years', asyncRoute(async (_req,res) => { const [rows]=await pool.query('SELECT YEAR(NgayDangKi) AS year,COUNT(*) AS value FROM Ho_So_Khai_Tu GROUP BY YEAR(NgayDangKi) ORDER BY year');res.json(rows); }));
router.get('/reports/gender', asyncRoute(async (_req,res) => {
  const [rows] = await pool.query("SELECT c.GioiTinh AS name, COUNT(*) AS value FROM Ho_So_Khai_Tu h JOIN Cong_Dan c ON c.CCCD=h.CCCD_NgMat GROUP BY c.GioiTinh ORDER BY value DESC, c.GioiTinh");
  res.json(rows);
}));


module.exports = router;
