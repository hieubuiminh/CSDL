require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const path = require('path');
const { pool } = require('./config/database');
const { secret } = require('./config/runtime');
const { asyncRoute } = require('./utils/http');
const { auth } = require('./middleware/auth');
const { errorHandler } = require('./middleware/error-handler');
const authRoutes = require('./routes/auth.routes');
const adminRoutes = require('./routes/admin.routes');
const registrationRoutes = require('./routes/registration.routes');
const reportRoutes = require('./routes/report.routes');

const app = express();

app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], fontSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'] } } }));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Health is public so local tooling can check the database connection.
app.get('/api/health', asyncRoute(async (_req, res) => {
  await pool.query('SELECT 1');
  res.json({ ok: true, database: true });
}));

// Public account flows live in their own router. All remaining API routes require a session.
app.use('/api', authRoutes);
app.use('/api', auth);
app.use('/api', adminRoutes);
app.use('/api', registrationRoutes);
app.use('/api', reportRoutes);

app.get('*', (req, res, next) => req.path.startsWith('/api/')
  ? next()
  : res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.use(errorHandler);

const port = Number(process.env.PORT || 3000);
const bindHost = process.env.BIND_HOST || '127.0.0.1';
if (!secret || secret.length < 32) console.warn('Cảnh báo: hãy đặt JWT_SECRET dài tối thiểu 32 ký tự trong .env trước khi chạy.');
app.listen(port, bindHost, () => console.log(`Ứng dụng đang chạy tại http://localhost:${port}`));