const jwt = require('jsonwebtoken');
const { secret } = require('../config/runtime');

function auth(req, res, next) {
  const token = req.cookies.session;
  if (!token) return res.status(401).json({ error: 'Vui lòng đăng nhập để tiếp tục.' });
  try {
    req.user = jwt.verify(token, secret);
    next();
  } catch {
    res.clearCookie('session');
    return res.status(401).json({ error: 'Phiên đăng nhập đã hết hạn.' });
  }
}

const adminOnly = (req, res, next) => req.user?.role === 'admin'
  ? next()
  : res.status(403).json({ error: 'Chức năng này chỉ dành cho quản trị viên.' });

module.exports = { auth, adminOnly };