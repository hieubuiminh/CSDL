# Hệ thống quản lý đăng ký khai tử

## Cấu trúc thư mục

- `backend/`: máy chủ Express, API và xử lý nghiệp vụ.
- `public/`: giao diện web HTML, CSS và JavaScript.
- `database/`: hai file SQL của nhóm, tách riêng khỏi cấu hình Docker.
- `docker/`: Dockerfile, Compose và image ứng dụng dựng sẵn.
- `docs/`: hướng dẫn chạy dành cho thành viên.
- `package.json`: lệnh chạy ứng dụng và các thư viện Node.js.
- `.dockerignore`: những file không cần gửi vào Docker build context; phải ở thư mục gốc.

## Chạy ứng dụng

Hướng dẫn Docker chi tiết nằm trong [hướng dẫn thành viên](docs/HUONG_DAN_THANH_VIEN.md). Chạy các lệnh Compose từ thư mục gốc theo dạng `docker compose -f docker/compose.yaml ...`.

Kết nối từ máy chủ web chỉ được publish trên `127.0.0.1:3000`.