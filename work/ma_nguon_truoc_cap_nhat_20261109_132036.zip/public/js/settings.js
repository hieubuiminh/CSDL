import { $, api, icon, num, showNotice, state } from './shared.js';

const settingTypes = [
  { key:'office', title:'Cơ quan tiếp nhận', icon:'building', fields:[['id','Mã UBND'],['name','Tên UBND'],['level','Cấp hành chính'],['address','Địa chỉ'],['phone','Số điện thoại']] },
  { key:'officer', title:'Cán bộ tiếp nhận', icon:'user-round', fields:[['id','Mã cán bộ'],['identity','CCCD cán bộ'],['name','Họ và tên'],['role','Chức vụ'],['phone','Số điện thoại'],['officeId','Mã UBND công tác']] },
  { key:'hospital', title:'Cơ sở y tế', icon:'hospital', fields:[['id','Mã cơ sở'],['name','Tên cơ sở y tế'],['address','Địa chỉ'],['phone','Số điện thoại']] },
  { key:'ward', title:'Xã / phường nơi mất', icon:'map-pin', fields:[['id','Mã xã/phường'],['name','Tên xã/phường']] },
  { key:'cause', title:'Nguyên nhân tử vong', icon:'stethoscope', fields:[['id','Mã nguyên nhân'],['name','Tên nhóm nguyên nhân']] }
];

export function renderSettings() {
  const counts = { office:state.lookups.offices.length, officer:state.lookups.officers.length, hospital:state.lookups.csyt.length, ward:state.lookups.wards.length, cause:state.lookups.causes.length };
  $('#settingsCards').innerHTML = settingTypes.map(type => `<article class="panel setting-card"><div class="setting-head"><div class="setting-symbol">${icon(type.icon)}</div><div><h2>${type.title}</h2><small>${num(counts[type.key])} mục đã có</small></div></div><form class="master-form" data-master="${type.key}">${type.fields.map(([key,label]) => `<label>${label}<input name="${key}" ${key === 'officeId' ? 'placeholder="Mã UBND đã tạo"' : ''} required></label>`).join('')}<button class="button secondary full">${icon('plus')} Thêm danh mục</button></form></article>`).join('');
}

export function initSettings() {
  $('#settingsCards').addEventListener('submit', async event => {
    const form = event.target.closest('[data-master]'); if (!form) return; event.preventDefault(); const button = form.querySelector('button'); button.disabled = true;
    try { await api(`/api/master/${form.dataset.master}`, { method:'POST', body:JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); showNotice('Đã thêm danh mục.'); await loadLookups(); }
    catch (error) { showNotice(error.message, true); } finally { button.disabled = false; }
  });
  $('#userAdminForm').addEventListener('submit', async event => {
    event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('button'); button.disabled = true;
    try { await api('/api/users', { method:'POST', body:JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); form.reset(); showNotice('Đã tạo tài khoản cán bộ.'); }
    catch (error) { showNotice(error.message, true); } finally { button.disabled = false; }
  });
  $('#createInviteBtn').addEventListener('click', async event => {
    const button = event.currentTarget; button.disabled = true;
    try {
      const invite = await api('/api/invitations', { method:'POST', body:'{}' });
      const result = $('#inviteResult'); result.innerHTML = `<strong>Mã mời: <code>${invite.code}</code></strong><span>Có hiệu lực đến ${new Intl.DateTimeFormat('vi-VN', { dateStyle:'short', timeStyle:'short' }).format(new Date(invite.expiresAt))}. Dùng một lần.</span><button type="button" class="button secondary" id="copyInviteBtn">${icon('copy')} Sao chép mã</button>`;
      result.classList.remove('hidden'); $('#copyInviteBtn').addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(invite.code); showNotice('Đã sao chép mã mời.'); }
        catch { showNotice(`Mã mời: ${invite.code}`); }
      });
    } catch (error) { showNotice(error.message, true); } finally { button.disabled = false; }
  });
}

let loadLookups;
export function setLookupLoader(loader) { loadLookups = loader; }
