import { $, $$, api, esc, fmt, icon, state, showNotice, statusClass, tableMarkup } from './shared.js';

export function initRegistrations(loadLookups, loadDashboard) {
  let searchTimer;
  $('#registrationSearch').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadRegistrations, 220); });
  $('#statusFilter').addEventListener('change', loadRegistrations);
  $('#registrationTable').addEventListener('change', async event => {
    const select = event.target.closest('[data-status-id]'); if (!select) return;
    try { await api(`/api/registrations/${encodeURIComponent(select.dataset.statusId)}/status`, { method: 'PATCH', body: JSON.stringify({ status: select.value }) }); select.className = `status-select ${statusClass(select.value)}`; showNotice('Đã cập nhật trạng thái hồ sơ.'); }
    catch (error) { showNotice(error.message, true); loadRegistrations(); }
  });
  $('#registrationTable').addEventListener('click', async event => {
    const button = event.target.closest('[data-delete-id]'); if (!button || state.user?.role !== 'admin') return;
    const id = button.dataset.deleteId;
    const name = button.dataset.deleteName;
    if (!window.confirm('Xóa hồ sơ ' + id + ' của ' + name + '? Hồ sơ an táng và thông tin công dân không còn được hồ sơ khác sử dụng sẽ bị xóa. Không thể hoàn tác.')) return;
    button.disabled = true;
    try {
      await api('/api/registrations/' + encodeURIComponent(id), { method: 'DELETE' });
      showNotice('Đã xóa hồ sơ ' + id + '.');
      await loadRegistrations();
      loadDashboard().catch(error => showNotice(error.message, true));
    } catch (error) { showNotice(error.message, true); button.disabled = false; }
  });
  $('#exportRegistrations').addEventListener('click', () => {
    const columns = [['Số hồ sơ','id'],['Người đã mất','deceasedName'],['CCCD người mất','deceasedId'],['Người đăng ký','applicantName'],['Quan hệ','relation'],['Ngày đăng ký','registeredAt'],['Đơn vị tiếp nhận','officeName'],['Trạng thái','status']];
    const quote = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
    const csv = '\ufeff' + [columns.map(([label]) => quote(label)).join(','), ...state.registrations.map(row => columns.map(([, key]) => quote(row[key])).join(','))].join('\r\n');
    const link = document.createElement('a'); const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    link.href = url; link.download = `ho-so-khai-tu-${new Date().toISOString().slice(0, 10)}.csv`; link.click(); URL.revokeObjectURL(url);
  });

  const dialog = $('#registrationDialog');
  function openRegistration() {
    $('#registrationError').textContent = ''; $('#registrationForm').reset();
    $('#registrationForm [name=d_ethnicity]').value = 'Kinh'; $('#registrationForm [name=a_ethnicity]').value = 'Kinh';
    $('#registrationForm [name=registeredAt]').value = new Date().toISOString().slice(0, 10); dialog.showModal();
  }
  $('#newRegistrationTop').addEventListener('click', openRegistration); $('#newRegistrationPage').addEventListener('click', openRegistration);
  $$('.close-dialog').forEach(button => button.addEventListener('click', () => dialog.close()));
  $('#registrationForm [name=officerId]').addEventListener('change', event => {
    const officer = state.lookups.officers.find(item => item.id === event.target.value); const preview = $('#officePreview');
    if (officer) { preview.textContent = `Đơn vị tiếp nhận: ${officer.officeName}`; preview.classList.remove('hidden'); } else preview.classList.add('hidden');
  });
  $('#registrationForm').addEventListener('submit', async event => {
    event.preventDefault(); const form = event.currentTarget; const values = new FormData(form); const value = key => String(values.get(key) || '').trim();
    const payload = {
      deceased: { cccd:value('d_cccd'), name:value('d_name'), birthDate:value('d_birthDate'), gender:value('d_gender'), hometown:value('d_hometown'), ethnicity:value('d_ethnicity'), phone:value('d_phone') },
      applicant: { cccd:value('a_cccd'), name:value('a_name'), birthDate:value('a_birthDate'), gender:value('a_gender'), hometown:value('a_hometown'), ethnicity:value('a_ethnicity'), phone:value('a_phone') },
      certificate: { id:value('certificateId'), issuedAt:value('issuedAt'), deathAt:value('deathAt').replace('T',' ') + ':00', placeDetail:value('placeDetail'), causeDescription:value('causeDescription'), causeId:value('causeId'), wardId:value('wardId'), hospitalId:value('hospitalId') },
      registration: { id:value('registrationId'), registeredAt:value('registeredAt'), relation:value('relation'), officerId:value('officerId') },
      burial: value('burialId') ? { id:value('burialId'), form:value('burialForm'), cemetery:value('burialCemetery'), date:value('burialDate') } : null
    };
    const submit = event.submitter; submit.disabled = true; submit.textContent = 'Đang lưu…'; $('#registrationError').textContent = '';
    try { await api('/api/registrations', { method: 'POST', body: JSON.stringify(payload) }); dialog.close(); showNotice('Đã tạo hồ sơ khai tử.'); await loadLookups(); await loadDashboard(); if ($('#page-registrations').classList.contains('active-page')) loadRegistrations(); }
    catch (error) { $('#registrationError').textContent = error.message; }
    finally { submit.disabled = false; submit.textContent = 'Lưu hồ sơ'; }
  });
  $('#lookupForm').addEventListener('submit', async event => {
    event.preventDefault(); const cccd = $('#lookupCccd').value.trim(); const root = $('#lookupResult'); root.innerHTML = '<div class="loading-line">Đang tra cứu…</div>';
    try {
      const record = await api(`/api/registrations/${encodeURIComponent(cccd)}`);
      root.innerHTML = `<article class="panel result-card"><div class="panel-heading"><div><div class="eyebrow">TRÍCH LỤC HỒ SƠ</div><h2>${esc(record.deceasedName)}</h2><p>CCCD ${esc(record.deceasedId)} · Số hồ sơ ${esc(record.id)}</p></div><div class="heading-actions"><span class="status-pill ${statusClass(record.status)}">${esc(record.status)}</span><button type="button" class="button secondary" id="printExtract">In trích lục</button></div></div><div class="detail-grid">${[['Ngày sinh',fmt(record.birthDate)],['Ngày giờ mất',esc(String(record.deathAt || '').replace('T',' ').slice(0,16))],['Nguyên nhân',esc(record.cause)],['Người đi khai tử',esc(record.applicantName)],['Quan hệ',esc(record.relation)],['UBND tiếp nhận',esc(record.officeName)],['Cán bộ tiếp nhận',esc(record.officerName)],['Cơ sở y tế cấp giấy',esc(record.hospitalName)],['Số giấy báo tử',esc(record.certificateId)],['Ngày đăng ký',fmt(record.registeredAt)]].map(([label, detail]) => `<div><small>${label}</small><strong>${detail}</strong></div>`).join('')}</div></article>`;
      $('#printExtract').addEventListener('click', () => window.print());
    } catch (error) { root.innerHTML = `<div class="empty-state"><span class="empty-state-icon">${icon('search-x')}</span><strong>Không tìm thấy hồ sơ</strong><p>${esc(error.message)}</p></div>`; }
  });
}

export async function loadRegistrations() {
  const query = new URLSearchParams({ search: $('#registrationSearch').value, status: $('#statusFilter').value });
  try { state.registrations = await api(`/api/registrations?${query}`); $('#registrationTable').innerHTML = tableMarkup(state.registrations, false, state.user?.role === 'admin'); }
  catch (error) { showNotice(error.message, true); }
}
