import { $, $$, api, esc, showNotice, state } from './shared.js';
import { initAuth } from './auth.js';
import { loadDashboard } from './dashboard.js';
import { initReports, loadReports } from './reports.js';
import { initRegistrations, loadRegistrations } from './registrations.js';
import { initSettings, renderSettings, setLookupLoader } from './settings.js';

const pageNames = { dashboard:'Tổng quan', registrations:'Hồ sơ khai tử', lookup:'Tra cứu trích lục', reports:'Báo cáo thống kê', settings:'Dữ liệu dùng chung', accounts:'Quản lý tài khoản' };
const recoveryDismissedKey = username => `khaiTuRecoverySetupDismissed:${username}`;
const hasDismissedRecoverySetup = username => { try { return localStorage.getItem(recoveryDismissedKey(username)) === 'true'; } catch { return false; } };
const rememberRecoverySetupDismissal = username => { try { localStorage.setItem(recoveryDismissedKey(username), 'true'); } catch { /* keep the dialog dismissible even when storage is disabled */ } };

async function loadLookups() {
  state.lookups = await api('/api/lookups');
  $$('select[data-options]').forEach(select => {
    const rows = state.lookups[select.dataset.options] || [];
    select.innerHTML = `<option value="">${rows.length ? 'Chọn thông tin' : 'Chưa có danh mục'}</option>` + rows.map(item => `<option value="${esc(item.id)}" ${item.officeName ? `data-office="${esc(item.officeName)}"` : ''}>${esc(item.name)}${item.officeName ? ` · ${esc(item.officeName)}` : ''}</option>`).join('');
    select.disabled = !rows.length;
  });
  renderSettings();
}

function enterApp(user) {
  const needsRecoverySetup = !user.recoveryConfigured;
  closeUserMenu();
  state.user = user; $('#authScreen').classList.add('hidden'); $('#appShell').classList.remove('hidden');
  const isAdmin = user.role === 'admin';
  $('#adminNavSection').classList.toggle('hidden', !isAdmin);
  $('#navigation [data-page="settings"]').classList.toggle('hidden', !isAdmin);
  $('#navigation [data-page="accounts"]').classList.toggle('hidden', !isAdmin);
  $('#userAdminPanel').classList.toggle('hidden', !isAdmin);
  $('#userName').textContent = user.name || user.username; $('#greetingName').textContent = (user.name || 'cán bộ').split(' ').slice(-1)[0];
  $('#userHandle').textContent = `@${user.username}`; $('#userInitial').textContent = (user.name || 'C').trim().slice(0,1).toUpperCase();
  $('#userMenuName').textContent = user.name || user.username; $('#userMenuHandle').textContent = `@${user.username}`;
  $('#userMenuInitial').textContent = (user.name || 'C').trim().slice(0,1).toUpperCase();
  $('#todayLabel').textContent = new Intl.DateTimeFormat('vi-VN', { weekday:'short', day:'2-digit', month:'long', year:'numeric' }).format(new Date());
  loadLookups().then(loadDashboard).catch(error => showNotice(error.message, true)); navigate('dashboard');
  if (needsRecoverySetup && !hasDismissedRecoverySetup(user.username)) $('#recoverySetupDialog').showModal();
}

function navigate(name) {
  if (name === 'accounts' && state.user?.role !== 'admin') name = 'dashboard';
  $$('.page').forEach(page => page.classList.toggle('active-page', page.id === `page-${name}`));
  $$('.nav-item').forEach(button => {
    const isCurrentPage = button.dataset.page === name;
    button.classList.toggle('active', isCurrentPage);
    if (isCurrentPage) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  $('#pageCrumb').textContent = pageNames[name] || pageNames.dashboard;
  if (name === 'registrations') loadRegistrations();
  if (name === 'reports') loadReports();
}

$('#navigation').addEventListener('click', event => { const button = event.target.closest('[data-page]'); if (button) navigate(button.dataset.page); });
document.addEventListener('click', event => { const button = event.target.closest('[data-goto]'); if (button) navigate(button.dataset.goto); });
$$('[data-refresh]').forEach(button => button.addEventListener('click', () => loadDashboard().then(() => showNotice('Đã cập nhật dữ liệu.')).catch(error => showNotice(error.message, true))));

$('#recoverySetupDialog').addEventListener('close', () => {
  if (state.user && !state.user.recoveryConfigured) rememberRecoverySetupDismissal(state.user.username);
});
function closeUserMenu() {
  $('#userMenu').classList.add('hidden');
  $('#userMenuToggle').setAttribute('aria-expanded', 'false');
  $('#userMenuToggle').setAttribute('aria-label', 'Mở menu tài khoản');
}
$('#userMenuToggle').addEventListener('click', () => {
  const opening = $('#userMenu').classList.contains('hidden');
  $('#userMenu').classList.toggle('hidden', !opening);
  $('#userMenuToggle').setAttribute('aria-expanded', String(opening));
  $('#userMenuToggle').setAttribute('aria-label', opening ? 'Đóng menu tài khoản' : 'Mở menu tài khoản');
  if (opening) $('#profileRecoveryBtn').focus();
});
document.addEventListener('click', event => { if (!event.target.closest('.user-row')) closeUserMenu(); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !$('#userMenu').classList.contains('hidden')) {
    closeUserMenu(); $('#userMenuToggle').focus();
  }
});
$('#profileRecoveryBtn').addEventListener('click', () => {
  closeUserMenu(); $('#recoverySetupError').textContent = ''; $('#recoverySetupForm').reset(); $('#recoverySetupDialog').showModal();
});
$('#profilePasswordBtn').addEventListener('click', () => {
  closeUserMenu(); $('#changePasswordForm').reset(); $('#changePasswordError').textContent = ''; $('#changePasswordDialog').showModal();
});
$('#skipRecoverySetupBtn').addEventListener('click', () => $('#recoverySetupDialog').close());
$('#recoverySetupForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('button[type="submit"]'); button.disabled = true;
  $('#recoverySetupError').textContent = '';
  try {
    const user = await api('/api/auth/recovery-setup', { method:'POST', body:JSON.stringify(Object.fromEntries(new FormData(form).entries())) });
    state.user = user.user; form.reset(); $('#recoverySetupDialog').close(); showNotice('Đã bật câu hỏi khôi phục cho tài khoản.');
  } catch (error) { $('#recoverySetupError').textContent = error.message; }
  finally { button.disabled = false; }
});

$$('.close-account-dialog').forEach(button => button.addEventListener('click', () => $('#changePasswordDialog').close()));
$('#changePasswordForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget; const values = Object.fromEntries(new FormData(form).entries());
  const button = form.querySelector('button[type="submit"]');
  $('#changePasswordError').textContent = '';
  if (values.newPassword !== values.confirmPassword) { $('#changePasswordError').textContent = 'Hai mật khẩu mới chưa trùng khớp.'; return; }
  button.disabled = true;
  try {
    const result = await api('/api/auth/change-password', { method:'POST', body:JSON.stringify(values) });
    state.user = result.user; form.reset(); $('#changePasswordDialog').close(); showNotice('Đã đổi mật khẩu.');
  } catch (error) { $('#changePasswordError').textContent = error.message; }
  finally { button.disabled = false; }
});

setLookupLoader(loadLookups);
initReports(); initSettings(); initRegistrations(loadLookups, loadDashboard); initAuth(enterApp);
