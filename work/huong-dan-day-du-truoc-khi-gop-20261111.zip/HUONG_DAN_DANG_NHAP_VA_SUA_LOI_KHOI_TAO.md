# Hướng dẫn đăng nhập và các phần đã sửa

Cập nhật ngày 11/11/2026. File này nằm ngay thư mục chính:
E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md.

## Bây giờ bạn làm gì?

Bản local đã được sửa và mở lại. Kiểm tra ngày 11/11 xác nhận đã có 1 tài khoản, API trả `setupRequired: false` và màn hình **Đăng nhập** hoạt động bình thường. Không cần tạo lại bảng hoặc nạp lại dữ liệu mẫu.

1. Mở **http://localhost:3001**.
2. Nhấn **Ctrl+F5** để tải lại giao diện mới.
3. Ở màn hình **Đăng nhập**, dùng tên đăng nhập và mật khẩu bạn đã tạo cho bản local này.
4. Nếu quên mật khẩu, dùng liên kết **Quên mật khẩu?** và thông tin khôi phục đã đặt.

Chỉ trên bản cài mới chưa có ADMIN, web mới hiện **Tạo tài khoản quản trị**. Khi đó nhập họ tên, tên đăng nhập, mật khẩu tối thiểu 10 ký tự, nhập lại mật khẩu, chọn câu hỏi khôi phục và câu trả lời ít nhất 3 ký tự, rồi tạo tài khoản.

CSDL mới không tự mang tài khoản từ bản cũ cổng 3000 sang. Dữ liệu mẫu không có tên đăng nhập hoặc mật khẩu ADMIN cài sẵn. Mình không tạo tài khoản/mật khẩu thay bạn trên CSDL đang dùng.

Nếu bạn đã tạo ADMIN sau khi bản sửa hoàn tất, trang sẽ hiện Đăng nhập, đây là trạng thái bình thường.

## Lỗi trước đó là gì?

Docker tạo CSDL trước khi chạy các file SQL. CSDL được tạo sẵn với quy tắc so sánh chuỗi khác quy tắc của bảng và biến trong trigger. Khi nạp hồ sơ mẫu, MySQL báo ERROR 1267. Toàn bộ transaction mẫu bị rollback và bước tạo bảng tài khoản chưa được chạy.

Vì vậy, thông báo thiếu App_User là hậu quả của lần khởi tạo bị dừng giữa chừng. Kiểm tra SQL trước đó chưa mô phỏng đầy đủ tình huống này; đã bổ sung kiểm thử khởi tạo bằng Docker thật để kiểm chứng.

## Đã sửa ở đâu?

| File/phần | Nội dung |
|---|---|
| database/tao_bang.sql | Đặt default CSDL utf8mb4_unicode_ci trước khi tạo trigger, cả khi Docker đã tạo CSDL trước đó. |
| docker/compose.yaml | Healthcheck đăng nhập MySQL qua TCP và đọc được App_User; không chỉ kiểm tra server đang sống. |
| public/js/auth.js, public/index.html | Khi trạng thái chưa sẵn sàng thì ẩn form, chặn gửi đăng nhập và có nút Thử lại; khi sẵn sàng thì chọn đúng tạo ADMIN/đăng nhập. |
| CSDL local mới | Đã đổi default và tạo lại 6 trigger, nạp 491 bản ghi mẫu ban đầu, tạo App_User; dữ liệu thêm sau đó được giữ nguyên. |
| public/theme.css | Chỉnh độ rộng form và ô chọn để màn hình điện thoại 390px không tràn ngang. |
| backend/modules/reports/queries.js | Truy vấn thống kê được thực thi trong backend. |
| backend/modules/registrations/queries.js | Truy vấn danh sách và tra cứu hồ sơ. |

Frontend trong public/ hiển thị kết quả; SQL không chạy trực tiếp trong trình duyệt.

## Đã kiểm tra những gì?

- Docker khởi tạo từ đầu với cùng cách tạo CSDL như bản thực tế.
- 491 bản ghi có checksum khớp nguồn trên cả 9 bảng; 6 trigger và bảng tài khoản đầy đủ.
- Tạo ADMIN, đăng xuất, đăng nhập lại; tạo/đăng nhập cán bộ và chặn truy cập chức năng quản trị.
- Dashboard, danh sách, tra cứu và năm báo cáo trả đúng dữ liệu.
- **52/52 kiểm tra đạt**, gồm 24 kiểm tra HTTP thật trong môi trường riêng đã được xóa.
- Ngày 11/11, trên bản local đang dùng, API trạng thái trả 200 và `setupRequired: false`; giao diện hiện đúng **Đăng nhập**. Desktop 1440px và điện thoại 390px không tràn ngang, không lỗi JavaScript. Lượt kiểm tra trực tiếp chỉ đọc, không tạo/sửa tài khoản hoặc thử mật khẩu của bạn.

Kết quả chi tiết: work/new-schema-review/docker-first-init-results.json.
Kết quả giao diện local mới nhất: work/new-schema-review/ui-live-3001-result-20261111.json.
Bản sao lưu trước sửa: work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql.

## Nếu còn thấy màn hình lỗi cũ

Nhấn Ctrl+F5 và kiểm tra đúng cổng 3001. Khi có nút Thử lại, bấm sau khi dịch vụ đã sẵn sàng. Không chạy lại toàn bộ SQL hoặc xóa volume để xử lý lỗi đăng nhập.

Có thể xem trạng thái và nhật ký tại thư mục dự án:

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml ps
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml logs --tail=80 db app
~~~

File sửa một lần trong work/sua-khoi-tao-dang-nhap-20261110/ chỉ dành cho tình trạng khởi tạo dở đã xác minh tất cả bảng còn rỗng. **Không chạy lại file này trên dữ liệu đã nạp**; nó có bước chặn để tránh trùng hoặc ghi đè.

CSDL cũ và mọi volume vẫn giữ nguyên. Ứng dụng chỉ phục vụ local tại 127.0.0.1:3001; không có bước xuất bản hay mở ra bên ngoài.
