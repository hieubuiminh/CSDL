# Giải thích các truy vấn đã tích hợp vào backend

Cập nhật ngày **11/11/2026**, đối chiếu với mã nguồn đang có tại `E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu`.

Tài liệu này giải thích vị trí và cách hoạt động của 7 chức năng tra cứu, thống kê. Lượt bổ sung tài liệu này không thay đổi câu SQL, bộ lọc hay dữ liệu. Ứng dụng vẫn chỉ chạy local tại `http://localhost:3001`.

## Đọc trước: câu SQL trong backend có đúng với truy vấn bạn đưa không?

Phần bạn quan tâm chính là **đối chiếu nội dung SQL**, không phải cách chia các file. Kết quả đối chiếu: **các chức năng giữ logic nguồn với những điều chỉnh dưới đây; không phải cả 7 câu SQL trong backend đều được chép nguyên văn**. Riêng câu 5, SQL backend đứng một mình chưa làm đủ toàn bộ truy vấn nguồn vì còn bước tổng hợp bằng JavaScript.

Nguồn đã đối chiếu:

```text
File SQL đang có trong dự án:
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\database\truy_van.sql

Bản nguồn người dùng đã được lưu trước đây:
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\work\truoc-khi-dung-bang-moi-20261110\nguon-nguoi-dung\truy_van.sql
```

Hai file này giữ nguyên phần SQL từ `USE quan_li_khai_tu;` trở xuống. Bản trong dự án chỉ thêm chú thích đầu file, cấu hình mã hóa và múi giờ trước phần đó. Đường dẫn nguồn cũ `E:\CSDL\truy_van.sql` hiện không còn file để đọc trực tiếp; lượt này dùng bản nguồn đã lưu nêu trên.

### Bảng đối chiếu 7 truy vấn

| Câu | Chức năng | Đối chiếu SQL backend với SQL nguồn |
|---|---|---|
| 1 | Tra cứu CCCD | Cùng đường nối bảng và điều kiện tìm đúng CCCD người mất. Backend truyền CCCD bằng `?`, lấy thêm trường và nối thêm CSYT, thêm `LIMIT 1`. Với khóa ngoại bắt buộc và ràng buộc duy nhất của bảng hiện tại, các phần thêm này không làm mất hồ sơ hợp lệ hoặc đổi hồ sơ được tìm. |
| 2 | Giới tính | Cùng `FROM Cong_Dan`, `WHERE TrangThai='Đã mất'` và đếm theo `GioiTinh`. Backend đổi tên cột kết quả và thêm sắp xếp. |
| 3 | Danh sách hồ sơ | Cùng dữ liệu hồ sơ và thứ tự khi chưa chọn bộ lọc. Backend lấy thêm trường/CSYT như câu 1; khi người dùng chọn tìm kiếm hoặc trạng thái, kết quả thu hẹp theo lựa chọn. |
| 4 | Địa bàn | Cùng `LEFT JOIN`, đếm hồ sơ, loại Từ chối và sắp số lượng giảm dần. Backend đổi điều kiện `YEAR(NgayDangKi)` thành khoảng đầu năm đến trước đầu năm sau. Khi chọn năm hiện tại, hai cách lọc cùng năm; backend còn cho chọn năm khác. |
| 5 | Tuổi và nguyên nhân | **SQL viết khác và chưa tự làm đủ nếu chạy riêng.** Nguồn dùng `WITH`/`RANK()` để tính tổng nhóm và nguyên nhân phổ biến nhất. SQL backend chỉ đếm theo nhóm tuổi/nguyên nhân; `summarizeAgeCauses` trong JavaScript mới tính tổng và chọn các nguyên nhân đồng hạng cao nhất. Với dữ liệu ngày và tên nguyên nhân thông thường, kết quả nghiệp vụ khớp; các khác biệt biên được ghi ngay bên dưới. |
| 6 | CSYT | Cùng lọc `NgayCap` trong quý lịch liền trước, cùng `GROUP BY`, cùng `HAVING COUNT(*) > 50` và cùng phép dò chuỗi tên/địa chỉ để ước tính ca mất tại CSYT. Backend tính mốc quý bằng JavaScript theo giờ Việt Nam rồi truyền vào SQL bằng `?`; thêm sắp xếp. |
| 7 | Năm mất | Cùng lấy `YEAR(NgayGioMat)` từ `Giay_Bao_Tu`, đếm và sắp năm tăng dần. Backend đổi tên cột kết quả. |

### Riêng câu 5: khác biệt nào cần biết?

- SQL nguồn tự trả tổng người của nhóm tuổi và nguyên nhân phổ biến nhất trong một truy vấn. SQL backend phải kết hợp hàm JavaScript mới có các thông tin này.
- Nếu ngày mất trước ngày sinh, SQL nguồn xếp tuổi âm vào Dưới 18; backend tách riêng thành dữ liệu không hợp lệ. Bảng hiện tại chưa chặn điều kiện liên bảng này trên mọi đường cập nhật, nên đây là khác biệt có thể xảy ra.
- Nhóm tuổi không có ca: SQL nguồn không có hàng tương ứng; backend trả nhóm có tổng 0.
- Tên nguyên nhân rỗng: JavaScript dùng tên “Chưa rõ nguyên nhân”; SQL nguồn giữ giá trị rỗng.

Vì vậy, nếu tiêu chí là **“câu SQL backend tự chạy phải cho đúng toàn bộ kết quả như câu SQL nguồn”**, câu 5 hiện chưa đáp ứng theo cách viết đó. Chưa sửa câu SQL trong lượt đối chiếu này.

### Riêng địa bàn: điều kiện loại Từ chối có sẵn trong nguồn

SQL nguồn và SQL backend đều có điều kiện:

```sql
AND hs.TrangThaiHoSo <> 'Từ chối'
```

Tên viết tắt của bảng trong backend là `h` thay cho `hs`, nhưng ý nghĩa điều kiện giống nhau. Nghĩa là tính Chờ xử lý và Đã duyệt trong năm đăng ký, loại Từ chối; đây không phải điều kiện mới được tự thêm vào backend.

Cả hai bản cũng chưa có điều kiện SQL lọc tỉnh/thành Hà Nội hoặc chỉ lấy loại Xã. Phạm vi Hà Nội dựa vào danh mục `Noi_Mat` được nạp; danh mục hiện tại dùng cả Xã/Phường. Nếu sau này có địa bàn ngoài Hà Nội, bản SQL này chưa tự tách được theo tỉnh/thành.

Lượt này là đối chiếu mã SQL với nguồn và lược đồ bảng. Kết quả chạy thử mẫu trước đó nằm ở mục 8; không coi việc đọc mã là một lượt chạy thử CSDL mới. Phần cây thư mục bên dưới chỉ dùng khi bạn cần tìm đến file.

## 0. Tìm file trên máy và xem cấu trúc tổng thể

Nếu bấm liên kết trong tài liệu không mở được, bạn làm theo đường dẫn bằng chữ bên dưới. Tất cả bắt đầu từ thư mục dự án:

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
```

### 0.1. Mở thư mục mà không cần bấm liên kết

1. Nhấn **Windows + E** để mở File Explorer.
2. Nhấn **Alt + D** để chọn thanh địa chỉ ở phía trên.
3. Dán đường dẫn thư mục dự án ở trên, rồi nhấn **Enter**.
4. Bạn sẽ thấy các thư mục `backend`, `database`, `public`, `docker` và các file hướng dẫn.
5. Để đọc một file mã, nhấn chuột phải vào file → **Open with / Mở bằng** → chọn **Notepad** hoặc **Visual Studio Code** nếu đã cài.

File hướng dẫn bạn đang đọc nằm ngay trong thư mục dự án, tên là:

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\HUONG_DAN_TRUY_VAN_BACKEND.md
```

### 0.2. Sơ đồ tổng thể dự án

Sơ đồ dưới đây rút gọn các phần chính và mở rộng phần liên quan đến truy vấn. Mỗi mức thụt vào là một thư mục con. Dòng có tên file là file nằm trong thư mục ngay phía trên nó.

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\
├── package.json                  Lệnh khởi chạy ứng dụng
├── README.md                     Mục lục hướng dẫn
├── HUONG_DAN_TRUY_VAN_BACKEND.md   File hướng dẫn này
│
├── backend\                      Xử lý yêu cầu và truy vấn MySQL
│   ├── index.js                  Khởi động backend
│   ├── app.js                    Gắn giao diện và các API
│   ├── server.js                 File chuyển tiếp tương thích
│   ├── config\                   Cấu hình kết nối và ứng dụng
│   │   ├── database.js           Tạo kết nối MySQL
│   │   └── runtime.js
│   ├── middleware\               Kiểm tra đăng nhập, quyền và lỗi
│   ├── utils\                    Hàm hỗ trợ
│   ├── routes\                   Các file chuyển tiếp tương thích
│   └── modules\                  Các nhóm chức năng đang dùng
│       ├── index.js              Ghép các nhóm chức năng
│       ├── auth\                 Đăng nhập, đăng ký, khôi phục
│       ├── accounts\             Quản lý tài khoản
│       ├── catalogs\             Danh mục dùng chung
│       ├── dashboard\            Tổng quan, dùng lại truy vấn
│       ├── registrations\        Hồ sơ và tra cứu CCCD
│       │   ├── queries.js        [A] Định nghĩa SELECT + JOIN hồ sơ
│       │   ├── index.js          Nhận yêu cầu, thêm bộ lọc, chạy SQL
│       │   ├── validation.js     Kiểm tra dữ liệu đầu vào
│       │   └── status.js         Xử lý tên trạng thái
│       └── reports\              Năm chức năng thống kê
│           ├── queries.js        [B] Định nghĩa SQL của 5 báo cáo
│           ├── index.js          Chuyển yêu cầu đến từng báo cáo
│           ├── helpers.js        Tính quý, tổng hợp nhóm tuổi
│           ├── gender\
│           │   └── index.js      Chạy thống kê giới tính
│           ├── areas\
│           │   └── index.js      Chạy thống kê địa bàn
│           ├── age-causes\
│           │   └── index.js      Chạy thống kê tuổi/nguyên nhân
│           ├── hospitals\
│           │   └── index.js      Chạy báo cáo cơ sở y tế
│           └── years\
│               └── index.js      Chạy thống kê năm mất
│
├── database\                     Các file SQL chạy riêng/khởi tạo
│   ├── tao_bang.sql              Tạo bảng và trigger
│   ├── du_lieu_mau.sql            Nạp dữ liệu mẫu ban đầu
│   ├── app_setup.sql             Tạo bảng tài khoản web
│   └── truy_van.sql              Bản SQL riêng của 7 chức năng
│
├── public\                       Giao diện hiển thị trên trình duyệt
│   ├── index.html
│   ├── styles.css
│   ├── theme.css
│   ├── admin.css
│   ├── assets\                   Phông chữ và biểu tượng
│   └── js\
│       ├── app.js                Khởi tạo giao diện
│       ├── auth.js               Giao diện đăng nhập
│       ├── registrations.js      Giao diện hồ sơ
│       ├── dashboard.js          Giao diện tổng quan
│       ├── lookup\               Giao diện tra cứu CCCD
│       ├── accounts\             Giao diện tài khoản
│       └── reports\              Giao diện của 5 báo cáo
│           ├── index.js
│           ├── gender\
│           ├── areas\
│           ├── age-causes\
│           ├── hospitals\
│           └── years\
│
├── docker\                       Cấu hình dựng/chạy bản local
│   ├── Dockerfile
│   └── compose.yaml
├── docs\                         Script kiểm tra ràng buộc chỉ đọc
├── tests\                        Các kiểm thử
└── work\                         Bản lưu và kết quả kiểm tra
```

Các thư mục báo cáo bên trong `public` có tên giống bên trong `backend`. Bạn đọc SQL ở nhánh **backend → modules** được đánh dấu **[A]** và **[B]**; nhánh `public` nhận kết quả rồi hiển thị bảng/biểu đồ.

### 0.3. Đến đúng hai file chứa SQL

**[A] Danh sách hồ sơ và tra cứu CCCD**

Trong File Explorer, lần lượt mở **backend → modules → registrations → queries.js**. Hoặc dán đường dẫn thư mục sau vào thanh địa chỉ, nhấn Enter, rồi mở file `queries.js` bằng Notepad/VS Code:

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations
```

Tên đầy đủ của file cần đọc:

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations\queries.js
```

Trong file này, tìm `registrationQuery`. Câu SQL nối các bảng để lấy thông tin hồ sơ; file `index.js` cùng thư mục thêm điều kiện tìm kiếm hoặc CCCD và chạy truy vấn.

**[B] Năm chức năng thống kê**

Trong File Explorer, lần lượt mở **backend → modules → reports → queries.js**. Hoặc dán đường dẫn thư mục:

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports
```

Tên đầy đủ của file cần đọc:

```text
E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\queries.js
```

Mở file rồi dùng **Ctrl + F** tìm tên tương ứng:

| Mục trên web | Tên cần tìm trong file [B] |
|---|---|
| Thống kê giới tính | `genderQuery` |
| Thống kê theo địa bàn | `areaQuery` |
| Nguyên nhân theo độ tuổi | `ageCauseQuery` |
| Cơ sở y tế | `hospitalQuery` |
| Thống kê theo năm mất | `yearQuery` |

### 0.4. Phân biệt queries.js với index.js

**“SQL danh sách và tra cứu CCCD” và “chạy truy vấn hồ sơ” là hai phần phối hợp để làm cùng chức năng.** Câu SQL mô tả cách lấy dữ liệu; phần xử lý yêu cầu sử dụng câu SQL đó để lấy dữ liệu thật từ MySQL.

Với hồ sơ, hai file cụ thể là:

```text
A. E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations\queries.js
B. E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations\index.js
```

| Bạn muốn biết điều gì? | File A: queries.js | File B: index.js |
|---|---|---|
| Lấy những thông tin nào? | Định nghĩa `SELECT`: họ tên người mất, ngày sinh, người khai, UBND… | Sử dụng các thông tin mà câu SQL trả về. |
| Lấy từ những bảng nào? | Định nghĩa `FROM` và `JOIN` giữa hồ sơ, giấy báo tử, công dân, nguyên nhân, cán bộ, UBND, CSYT. | Lấy phần SQL dùng chung từ file A. |
| Người dùng đang xem danh sách hay tra cứu CCCD? | Cùng một biến `registrationQuery` phục vụ cả hai. | Có nhánh xử lý yêu cầu danh sách và nhánh xử lý tra cứu CCCD. |
| CCCD hoặc bộ lọc lấy ở đâu? | Phần SQL dùng chung chưa có CCCD cụ thể. | Nhận từ yêu cầu của web, kiểm tra dữ liệu và thêm điều kiện tương ứng. |
| Chỗ nào gửi SQL đến MySQL? | Không có lệnh thực thi trong file A. | Gọi `pool.execute(...)` để gửi SQL và tham số qua kết nối MySQL. |
| Chỗ nào trả kết quả cho web? | Chỉ cung cấp chuỗi SQL. | Nhận các dòng dữ liệu, xử lý không tìm thấy/định dạng trạng thái, rồi gọi `res.json(...)`. |

Trong file A, biến `registrationQuery` là một **chuỗi văn bản chứa SQL**. Dòng `module.exports` cho phép file khác dùng lại chuỗi đó. Việc mở file để đọc, hoặc lấy chuỗi SQL bằng `require(...)`, chưa thực hiện truy vấn MySQL.

Trong file B, dòng sau lấy câu SQL từ file A:

```javascript
const { registrationQuery } = require('./queries');
```

Sau đó, khi nhận yêu cầu tra cứu hoặc danh sách, file B mới gọi `pool.execute(...)`. Đây là thời điểm backend yêu cầu MySQL thực thi câu SQL. MySQL đọc dữ liệu và trả kết quả; file B gửi kết quả đó về giao diện.

Tách phần SELECT dùng chung giúp danh sách và tra cứu cùng lấy thông tin theo một cách. Khi cần bổ sung một cột thông tin, có thể sửa phần dùng chung thay vì chép cùng một SELECT sang hai nơi.

### 0.5. Ví dụ đầy đủ: bạn nhập CCCD để tra cứu

Ví dụ dùng CCCD mẫu `001000000001`. Đây là minh họa luồng xử lý; phần hướng dẫn này không gửi yêu cầu đến CSDL.

1. Bạn nhập CCCD vào mục Tra cứu rồi bấm nút tra cứu.
2. Giao diện gửi yêu cầu đến `/api/registrations/001000000001`.
3. File B nhận yêu cầu, lấy CCCD từ địa chỉ và kiểm tra đủ 12 chữ số.
4. File B lấy SELECT dùng chung từ file A, nối thêm `WHERE d.CCCD=?`, cách sắp xếp và `LIMIT 1`.
5. File B truyền CCCD vào vị trí `?`, gọi MySQL, chờ các dòng kết quả.
6. Nếu không có dòng nào, backend trả thông báo không tìm thấy; nếu có, trả thông tin hồ sơ về giao diện để hiển thị.

Đoạn chạy SQL thực tế trong file B:

```javascript
const [rows] = await pool.execute(
  `${registrationQuery} WHERE d.CCCD=? ORDER BY h.NgayDangKi DESC, h.SoGiayKhaiTu DESC LIMIT 1`,
  [req.params.cccd]
);
```

Giải thích từng phần:

- `registrationQuery`: SELECT và JOIN đã lấy từ file A.
- `WHERE d.CCCD=?`: chỉ chọn người mất có CCCD cần tìm.
- `[req.params.cccd]`: giá trị CCCD nhận từ yêu cầu, truyền riêng vào dấu `?`.
- `pool`: nhóm kết nối MySQL được cấu hình trong `backend/config/database.js`.
- `execute(...)`: gửi câu SQL cùng tham số đến MySQL.
- `await`: chờ MySQL trả kết quả.
- `rows`: các dòng dữ liệu MySQL trả về, không phải nội dung câu SQL.

Sau bước kiểm tra có kết quả, backend trả hồ sơ đầu tiên bằng:

```javascript
res.json(normalizeRecord(rows[0]));
```

`normalizeRecord` thống nhất tên trạng thái hồ sơ; `res.json(...)` gửi dữ liệu cho trình duyệt. Giao diện tiếp tục điền họ tên, ngày sinh, ngày mất và các thông tin khác vào màn hình trích lục.

Luồng đọc nhanh:

```text
Bạn nhập CCCD trên web
        |
        v
index.js nhận CCCD và kiểm tra
        |
        +---- lấy SELECT + JOIN từ queries.js
        |
        v
index.js thêm WHERE và gọi pool.execute(...)
        |
        v
MySQL thực thi SQL, trả các dòng dữ liệu
        |
        v
index.js trả kết quả -> giao diện hiển thị hồ sơ
```

Một lần tra cứu dùng câu SQL chung có thêm điều kiện CCCD; việc tách hai file không làm phát sinh hai lần tra cứu cùng hồ sơ.

### 0.6. Danh sách hồ sơ dùng chung SQL nhưng khác điều kiện thế nào?

Khi mở danh sách, giao diện gọi `/api/registrations`. File B vẫn lấy `registrationQuery` từ file A, nhưng thêm bộ lọc trạng thái/từ khóa tìm kiếm thay vì giới hạn theo một CCCD duy nhất.

| Thao tác | Phần dùng chung | Phần file B thêm khi thực thi | Kết quả |
|---|---|---|---|
| Mở danh sách | SELECT và JOIN trong `registrationQuery`. | Bộ lọc trạng thái, từ khóa nếu có; sắp xếp ngày đăng ký và số hồ sơ tăng dần. | Nhiều hồ sơ phù hợp, hoặc danh sách rỗng. |
| Tra cứu CCCD | Cũng SELECT và JOIN trong `registrationQuery`. | Điều kiện `d.CCCD=?`, sắp xếp và `LIMIT 1`. | Một hồ sơ tìm thấy, hoặc thông báo không tìm thấy. |

Vì thế, chữ **“SQL danh sách và tra cứu CCCD”** trên sơ đồ có nghĩa là file chứa phần SELECT dùng chung cho hai thao tác. Chữ **“nhận yêu cầu, thêm bộ lọc, chạy SQL”** chỉ công việc của file xử lý yêu cầu.

**Phạm vi cần lưu ý:** cách tách trên mô tả hai truy vấn đọc hồ sơ. File B còn chứa chức năng tạo hồ sơ, đổi trạng thái và xóa hồ sơ, trong đó có các lệnh `INSERT`, `UPDATE`, `DELETE` và SQL phụ trợ viết trực tiếp. Vì vậy, không phải mọi câu SQL của toàn bộ chức năng hồ sơ đều đã được chuyển hết vào file A.

### 0.7. Vì sao nhiều thư mục đều có index.js?

Tên file giống nhau nhưng vai trò được xác định bởi thư mục chứa nó:

| Vị trí đầy đủ | Vai trò |
|---|---|
| `E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\index.js` | Khởi động ứng dụng backend. |
| `E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\index.js` | Ghép các nhóm chức năng như hồ sơ, thống kê, tài khoản. |
| `E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\registrations\index.js` | Nhận yêu cầu danh sách/tra cứu, chạy truy vấn; đồng thời xử lý tạo, đổi trạng thái và xóa hồ sơ. |
| `E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\index.js` | Chuyển từng địa chỉ báo cáo đến module tương ứng; ví dụ `/areas` đến module địa bàn. |
| `E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\areas\index.js` | Nhận năm, tạo khoảng ngày, chạy `areaQuery` và trả số liệu địa bàn. |

Ví dụ muốn hiểu thống kê địa bàn, bạn đọc theo thứ tự:

```text
1. E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\queries.js
   Tìm areaQuery để xem điều kiện đếm hồ sơ.

2. E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\areas\index.js
   Xem cách lấy năm, truyền khoảng ngày và chạy areaQuery.

3. E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu\backend\modules\reports\index.js
   Xem đường dẫn /areas được nối với module địa bàn.
```

Ứng dụng hiện khởi chạy theo lệnh trong `package.json`: `backend/index.js` → `backend/app.js` → `backend/modules/index.js` → module chức năng. Các file trong `backend/routes` và file `backend/server.js` có vai trò chuyển tiếp tương thích; vị trí SQL chính là hai file [A], [B] ở trên.

Từ mục 1 bên dưới là phần giải thích nghiệp vụ và từng truy vấn. Bạn có thể tìm lại từ khóa bằng Ctrl + F ngay trong file hướng dẫn này.

## 1. Ghi chú cần đọc trước: thống kê theo địa bàn

Yêu cầu bạn đưa ra:

> Thống kê tử vong theo địa bàn: Liệt kê danh sách các Xã tại Hà Nội kèm theo tổng số ca khai tử đã đăng ký trong năm, sắp xếp giảm dần theo số ca tử vong.

Cụm **“đã đăng ký trong năm”** xác định mốc đếm theo ngày đăng ký hồ sơ, không đặt điều kiện hồ sơ phải có trạng thái **“Đã duyệt”**. Vì thế, một hồ sơ đã được lập trong năm nhưng đang **“Chờ xử lý”** vẫn có thể được tính vào chỉ tiêu này.

Trong mã hiện tại, báo cáo địa bàn áp dụng quy tắc cụ thể sau:

| Trạng thái hồ sơ | Có tính vào địa bàn không? |
|---|---|
| Chờ xử lý | Có, nếu ngày đăng ký thuộc năm đang xem. |
| Đã duyệt | Có, nếu ngày đăng ký thuộc năm đang xem. |
| Từ chối | Không; truy vấn hiện có điều kiện loại trạng thái này. |

**Điểm ghi lại để bạn đọc và thống nhất sau:** câu yêu cầu nói “đã đăng ký” chứ không nói “chỉ đã duyệt”. Riêng việc có tính hồ sơ bị từ chối hay không cần quy ước rõ; mã hiện tại đang loại nhóm này. Chưa chuyển báo cáo sang cách chỉ đếm hồ sơ đã duyệt, cũng chưa đổi sang tính cả hồ sơ từ chối.

Ví dụ minh họa, không phải số liệu trên máy: một địa bàn có 3 hồ sơ đăng ký trong năm, gồm 1 Chờ xử lý, 1 Đã duyệt và 1 Từ chối, thì cách đếm hiện tại cho kết quả **2 hồ sơ**. Nếu chỉ đếm Đã duyệt sẽ là 1; nếu đếm mọi hồ sơ đã đăng ký, kể cả Từ chối, sẽ là 3. Đây là ba cách định nghĩa chỉ tiêu khác nhau.

Việc đếm báo cáo cũng cần phân biệt với trạng thái công dân: quy tắc hiện tại đánh dấu công dân **Đã mất** khi lập hoặc cập nhật hồ sơ không bị từ chối, bao gồm hồ sơ Chờ xử lý. Việc đổi hồ sơ sang Từ chối hoặc xóa hồ sơ không tự chuyển công dân về Còn sống. Do đó, “đã đăng ký”, “đã duyệt” và trạng thái “Đã mất” là các thông tin riêng trong mô hình hiện tại.

## 2. Mở những file nào để xem truy vấn?

Hai file chứa SQL dùng cho 7 chức năng trên web:

| File | Vai trò |
|---|---|
| [SQL báo cáo](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/queries.js) | Chứa 5 biến: `genderQuery`, `yearQuery`, `areaQuery`, `ageCauseQuery`, `hospitalQuery`. |
| [SQL hồ sơ](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/registrations/queries.js) | Chứa `registrationQuery`, dùng chung cho danh sách hồ sơ và tra cứu CCCD. |

Có **7 chức năng nhưng 6 biến SQL**, vì danh sách và tra cứu dùng chung phần lấy thông tin hồ sơ, sau đó thêm điều kiện tương ứng.

Các câu SQL được đặt trong chuỗi JavaScript ở file `.js`. Các file `index.js` của từng chức năng lấy những chuỗi này để gọi MySQL và trả kết quả cho giao diện.

Bản SQL để xem hoặc chạy riêng vẫn nằm tại [file truy_van.sql](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/database/truy_van.sql). Khi bạn mở báo cáo trên web, backend dùng mã JavaScript đã tích hợp; ứng dụng không tự chạy toàn bộ file SQL này mỗi lần mở trang.

## 3. Bảng đối chiếu đủ 7 chức năng

Các số dòng dưới đây được ghi theo mã nguồn ngày 11/11/2026; chúng có thể thay đổi khi sửa mã về sau.

| STT theo file SQL | Chức năng | Nơi chứa SQL | Nơi thực thi | Đường dẫn API |
|---|---|---|---|---|
| 1 | Tra cứu hồ sơ theo CCCD người mất | [registrationQuery, dòng 1](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/registrations/queries.js:1) | [Tra cứu, dòng 19](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/registrations/index.js:19) | `GET /api/registrations/:cccd` |
| 2 | Thống kê theo giới tính | [genderQuery, dòng 1](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/queries.js:1) | [Module giới tính](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/gender/index.js) | `GET /api/reports/gender` |
| 3 | Hiển thị toàn bộ hồ sơ | [registrationQuery, dòng 1](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/registrations/queries.js:1) | [Danh sách, dòng 11](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/registrations/index.js:11) | `GET /api/registrations` |
| 4 | Thống kê theo địa bàn | [areaQuery, dòng 6](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/queries.js:6) | [Module địa bàn](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/areas/index.js) | `GET /api/reports/areas?year=2026` |
| 5 | Nguyên nhân tử vong theo tuổi | [ageCauseQuery, dòng 13](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/queries.js:13) | [Module tuổi và nguyên nhân](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/age-causes/index.js) | `GET /api/reports/age-causes` |
| 6 | Báo cáo cơ sở y tế | [hospitalQuery, dòng 26](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/queries.js:26) | [Module cơ sở y tế](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/hospitals/index.js) | `GET /api/reports/hospitals` |
| 7 | Thống kê theo năm mất | [yearQuery, dòng 4](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/queries.js:4) | [Module năm mất](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/years/index.js) | `GET /api/reports/years` |

API là địa chỉ mà giao diện gọi để lấy dữ liệu. Các API trên cần đăng nhập và được dùng bởi cả ADMIN lẫn cán bộ. Bạn chỉ cần mở chức năng tương ứng trên web, không phải nhập các địa chỉ API bằng tay.

## 4. Web lấy kết quả từ CSDL như thế nào?

Luồng xử lý gồm bốn bước:

1. Bạn mở một chức năng trên giao diện, ví dụ Thống kê theo giới tính.
2. Giao diện gửi yêu cầu đến API của chức năng đó.
3. Backend lấy câu SQL từ file chứa truy vấn, dùng kết nối MySQL để thực thi.
4. MySQL trả các dòng dữ liệu; backend gửi chúng dưới dạng JSON để giao diện vẽ bảng hoặc biểu đồ.

Ví dụ thực tế trong [module giới tính](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/gender/index.js:4):

```javascript
const { genderQuery } = require('../queries');
// Trong hàm xử lý yêu cầu:
const [rows] = await pool.query(genderQuery);
res.json(rows);
```

`genderQuery` là câu SQL; `pool.query(...)` chạy câu SQL qua kết nối MySQL; `res.json(...)` trả kết quả cho web. Kết nối được cấu hình tại [database.js](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/config/database.js), mặc định dùng CSDL `quan_li_khai_tu`.

## 5. Giải thích từng truy vấn

### 5.1. Tra cứu và trích lục theo CCCD người mất

Người dùng nhập CCCD gồm đúng 12 chữ số. Backend kiểm tra định dạng rồi lấy thông tin từ `registrationQuery`, thêm điều kiện:

```sql
WHERE d.CCCD = ?
```

Dấu `?` nhận CCCD bạn nhập. Backend dùng `pool.execute(...)` để truyền CCCD thành tham số, không cố định một CCCD mẫu trong mã.

Thông tin trả về gồm người mất, CCCD, ngày sinh, ngày giờ mất, nguyên nhân và mô tả nguyên nhân; người đi khai, quan hệ; ngày đăng ký, trạng thái, số hồ sơ, số giấy báo tử; UBND, cán bộ tiếp nhận và CSYT cấp giấy.

Quan hệ chính là hồ sơ → giấy báo tử → công dân đã mất. CCCD người mất nằm tại `Giay_Bao_Tu.CCCD_NgMat`; người đi khai lấy từ `Ho_So_Khai_Tu.CCCD_NgKhaiTu`.

UBND được suy ra qua cán bộ tiếp nhận: hồ sơ → cán bộ → UBND. Mô hình hiện tại chưa lưu riêng UBND tại thời điểm lập hồ sơ, nên đây cũng là điểm cần cân nhắc nếu sau này cán bộ chuyển đơn vị.

Backend trả lỗi định dạng nếu CCCD không hợp lệ; trả thông báo không tìm thấy nếu chưa có hồ sơ. Phần hiển thị và in trích lục nằm tại [giao diện tra cứu](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/public/js/lookup/index.js).

### 5.2. Thống kê số người đã mất theo giới tính

`genderQuery` đọc bảng `Cong_Dan`, chọn các công dân có `TrangThai = 'Đã mất'`, rồi đếm theo `GioiTinh`.

Kết quả có `name` là giới tính và `value` là số người. Backend sắp xếp số lượng giảm dần, sau đó theo tên giới tính. Truy vấn này không lọc hồ sơ Đã duyệt và không giới hạn năm.

Vì vậy, số liệu phụ thuộc trạng thái công dân đang lưu; công dân được đánh dấu Đã mất từ hồ sơ Chờ xử lý cũng có thể được tính.

### 5.3. Hiển thị toàn bộ hồ sơ khai tử

Chức năng danh sách dùng cùng `registrationQuery` với tra cứu, nhưng lấy nhiều hồ sơ để hiển thị người mất, người đăng ký, ngày đăng ký, đơn vị tiếp nhận và trạng thái.

Backend hỗ trợ tìm kiếm theo số hồ sơ, số giấy báo tử, họ tên hoặc CCCD của hai người; có bộ lọc trạng thái. Nếu không chọn trạng thái, danh sách có cả Chờ xử lý, Đã duyệt và Từ chối. Mã hiện tại sắp xếp ngày đăng ký tăng dần, rồi theo số hồ sơ.

### 5.4. Thống kê theo địa bàn

`areaQuery` lấy danh mục `Noi_Mat`, nối với giấy báo tử rồi hồ sơ để đếm theo nơi mất. Đây là **địa bàn nơi mất**, không phải quê quán công dân hoặc địa bàn của UBND tiếp nhận.

Điều kiện năm dùng `Ho_So_Khai_Tu.NgayDangKi`. Ví dụ chọn năm 2026 thì backend truyền hai mốc: từ `2026-01-01` đến trước `2027-01-01`. Nếu không truyền năm, backend lấy năm hiện tại theo giờ Việt Nam.

Truy vấn dùng `LEFT JOIN`, nên địa bàn không có hồ sơ phù hợp vẫn hiện với số lượng 0. Kết quả sắp xếp số hồ sơ giảm dần, sau đó theo tên địa bàn. Cách xử lý Chờ xử lý/Đã duyệt/Từ chối đã ghi ở mục 1.

**Phạm vi hiện tại:** truy vấn lấy cả Xã/Phường trong danh mục. Nhãn Hà Nội dựa trên phạm vi bộ dữ liệu đang dùng; bảng chưa có tỉnh/thành để SQL tự lọc Hà Nội nếu sau này nạp địa bàn ngoài Hà Nội. Yêu cầu ban đầu ghi “các Xã”, còn mã và danh mục hiện tại dùng cả Xã/Phường; cần lưu ý nếu sau này muốn chỉ lấy loại Xã.

### 5.5. Thống kê nguyên nhân tử vong theo tuổi

`ageCauseQuery` chỉ lấy hồ sơ **Đã duyệt**. Tuổi được tính tại thời điểm mất bằng `TIMESTAMPDIFF(YEAR, NgaySinh, NgayGioMat)`, tức số năm tuổi đã tròn.

Ba nhóm là Dưới 18, 18–60 và Trên 60. Người vừa đủ 18 hoặc 60 tuổi thuộc nhóm 18–60.

SQL đếm số người theo từng nhóm tuổi và nguyên nhân. Hàm [summarizeAgeCauses](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/helpers.js:30) sau đó tính tổng từng nhóm và chọn nguyên nhân có số ca lớn nhất. Nếu nhiều nguyên nhân đồng hạng nhất, trả tất cả. Cả ba nhóm đều được trả về, kể cả nhóm có tổng 0; dữ liệu thiếu tuổi hoặc ngày mất trước ngày sinh được tách riêng.

Trong file SQL chạy riêng, phần tổng hợp dùng `WITH` và `RANK()`. Trong backend, phần này được chia thành SQL đếm và JavaScript tổng hợp để giao diện nhận cả tổng nhóm, nguyên nhân phổ biến và danh sách nguyên nhân.

### 5.6. Báo cáo cơ sở y tế

`hospitalQuery` đếm giấy báo tử theo CSYT cấp giấy, dựa vào **ngày cấp `NgayCap`**. Điều kiện `HAVING COUNT(*) > 50` nghĩa là từ 51 giấy trở lên; đúng 50 giấy chưa được chọn.

“Quý gần nhất” đang được hiểu là **quý lịch liền trước quý hiện tại**, không phải ba tháng gần đây. Hàm [previousQuarter](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/reports/helpers.js:13) tính khoảng này theo giờ Việt Nam. Ví dụ ngày 11/11/2026 thuộc quý IV, nên báo cáo lấy từ `2026-07-01` đến trước `2026-10-01`, tức quý III/2026.

Truy vấn đếm giấy báo tử, không lọc hồ sơ Đã duyệt. Hai thông tin bổ sung `estimatedDeaths` và `estimatedPercent` ước tính ca mất tại chính CSYT bằng cách dò tên/địa chỉ cơ sở trong chuỗi `NoiMatChiTiet`; mức chính xác phụ thuộc cách ghi địa điểm, chưa phải quan hệ nơi mất chuyên biệt.

### 5.7. Thống kê theo năm mất

`yearQuery` lấy tất cả giấy báo tử, tách năm từ `NgayGioMat`, đếm theo năm rồi sắp xếp năm tăng dần.

Đây là **năm mất**, khác với năm đăng ký của báo cáo địa bàn. Truy vấn không yêu cầu hồ sơ Đã duyệt và không tự loại giấy báo tử của hồ sơ Từ chối.

## 6. Vì sao tổng các báo cáo có thể khác nhau?

| Báo cáo | Đối tượng và điều kiện đếm hiện tại |
|---|---|
| Giới tính | Công dân có trạng thái Đã mất. |
| Danh sách | Hồ sơ, theo bộ lọc tìm kiếm/trạng thái nếu có. |
| Địa bàn | Hồ sơ không bị từ chối, theo năm đăng ký và địa bàn nơi mất. |
| Tuổi và nguyên nhân | Chỉ hồ sơ Đã duyệt. |
| CSYT | Giấy báo tử cấp trong quý lịch trước; chỉ hiển thị cơ sở có trên 50 giấy. |
| Năm mất | Tất cả giấy báo tử, nhóm theo năm mất. |

Đối chiếu trên **mẫu gốc chưa thêm hồ sơ**: 100 công dân Đã mất; 100 hồ sơ gồm 81 Đã duyệt, 15 Chờ xử lý, 4 Từ chối; địa bàn năm 2026 có 73 hồ sơ phù hợp; báo cáo tuổi có 81 người; một CSYT cấp 52 giấy trong quý III/2026; theo năm mất 2024/2025/2026 lần lượt 8/16/76.

Đây là mốc kiểm thử mẫu, không phải số liệu cố định của web. Khi kiểm tra trước đó ngày 11/11, bản local đã có 101 hồ sơ; số liệu thực tế sẽ thay đổi khi bạn thêm hoặc xử lý dữ liệu.

## 7. Những chỗ đã điều chỉnh khi đưa SQL vào web

- Giữ quan hệ của bảng mới: người mất được nối qua giấy báo tử.
- Đặt tên kết quả như `name`, `value`, `deceasedName` để giao diện sử dụng.
- Truyền CCCD và khoảng ngày bằng tham số `?` thay cho giá trị mẫu cố định.
- Cho phép chọn năm ở báo cáo địa bàn; tự tính quý trước cho báo cáo CSYT.
- Chia phần tổng hợp nguyên nhân phổ biến theo tuổi sang hàm JavaScript trong backend như mục 5.5.
- Dùng lại một câu lấy hồ sơ cho danh sách và tra cứu. [Trang tổng quan](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/backend/modules/dashboard/index.js) cũng dùng lại truy vấn giới tính, năm mất và hồ sơ gần đây.

Hai file truy vấn chứa SQL; các module `index.js` nhận yêu cầu và thực thi; giao diện trong `public/` trình bày kết quả. Muốn đổi cách đếm trên web thì cần sửa đúng mã backend liên quan. Chỉ sửa `database/truy_van.sql` sẽ chưa làm thay đổi truy vấn mà web đang gọi.

## 8. Cách kiểm tra trên web và tài liệu liên quan

Mở `http://localhost:3001`, đăng nhập rồi vào các mục Tra cứu, Hồ sơ và từng báo cáo. Với báo cáo địa bàn, chọn đúng năm; với CSYT, xem nhãn quý mà ứng dụng trả về.

Khi cập nhật mã backend/frontend, làm theo mục 9 của [hướng dẫn khởi tạo và cập nhật app](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/HUONG_DAN_KHOI_TAO_CSDL_MOI.md). Không cần nạp lại dữ liệu mẫu để mở báo cáo.

Kết quả kiểm thử khởi tạo Docker và API đã lưu tại [docker-first-init-results.json](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/work/new-schema-review/docker-first-init-results.json): 52/52 đạt trong môi trường thử riêng, gồm 24 kiểm tra HTTP. Đây là kết quả kiểm thử trước đó, không phải một lượt kiểm thử mới trong lần viết tài liệu này.

Trạng thái công việc và các việc đã làm được lưu tại [TRANG_THAI_TIEP_TUC.md](E:/CSDL/he_thong_quan_ly_dang_ky_khai_tu/TRANG_THAI_TIEP_TUC.md).
