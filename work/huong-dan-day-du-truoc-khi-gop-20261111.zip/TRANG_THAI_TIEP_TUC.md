# Trạng thái để tiếp tục công việc

Cập nhật ngày **11/11/2026**. Lưu ngay trong thư mục chính của dự án, cập nhật sau mỗi mốc công việc.

## Nguyên tắc cần giữ

- Chỉ chạy trên máy này; web chỉ mở tại `127.0.0.1:3001`, MySQL không mở cổng ra ngoài.
- Giữ nguyên CSDL cũ và các volume cũ. Không xóa CSDL hoặc nạp lại dữ liệu khi đã có dữ liệu.
- Dùng mô hình mới trong `database/tao_bang.sql`, liên kết người mất qua `Giay_Bao_Tu.CCCD_NgMat`.
- Không tự tạo ADMIN hoặc đặt mật khẩu thay chủ dự án trên CSDL đang dùng.

## Đã hoàn tất trước khi tiếp tục

- Đã sửa lỗi khởi tạo MySQL do collation không thống nhất; đã nạp 491 bản ghi mẫu, tạo `App_User` và 6 trigger trên bản local mới.
- Đã sao lưu trước khi sửa tại `work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql`.
- Đã kiểm thử lần khởi tạo Docker thật và các API trong môi trường riêng: **52/52 đạt**; kết quả ở `work/new-schema-review/docker-first-init-results.json`.
- Đã đặt truy vấn trong backend: `backend/modules/reports/queries.js` và `backend/modules/registrations/queries.js`. Frontend chỉ hiển thị kết quả từ API.
- Đã sửa xử lý trạng thái đăng nhập và giao diện màn hình nhỏ trong mã nguồn. Trước lúc dừng hôm qua, phần CSS cuối chưa được áp dụng vào container; ngày 11/11 đã dựng lại app và kiểm tra hoàn tất như bên dưới.
- Đã thêm hướng dẫn đăng nhập ở `HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md`. Nội dung tổng hợp công việc được giữ ngay trong file trạng thái này.

## Kiểm tra khi tiếp tục ngày 11/11

- Đã mở Docker Desktop, dựng lại image và thay riêng container app bằng bản mới; mở lại MySQL trên volume đang có. Không chạy thêm SQL ghi dữ liệu.
- App đang chạy tại `127.0.0.1:3001`; MySQL healthy, không công bố cổng ra máy. Các volume CSDL/cấu hình của project cũ vẫn tồn tại.
- Hash `public/theme.css` và `public/js/auth.js` trong container khớp mã nguồn dự án.
- CSDL hiện có: 8 địa bàn, 6 nguyên nhân, 4 CSYT, 3 UBND, 202 công dân, 6 cán bộ, 101 giấy báo tử, 101 hồ sơ, 64 an táng. Tổng 495 bản ghi nghiệp vụ, cùng 1 tài khoản ứng dụng. Mẫu ban đầu là 491; dữ liệu thêm sau đó được giữ nguyên.
- Default CSDL và 6 trigger đều dùng `utf8mb4_unicode_ci`.
- API trạng thái trả HTTP 200, `setupRequired: false`; hiện màn hình **Đăng nhập** vì đã có tài khoản. Không cần tạo ADMIN mới.
- Kiểm tra trực tiếp desktop 1440px và điện thoại 390px đạt: không tràn ngang, không lỗi JavaScript; 23 yêu cầu đều chỉ đọc và nội bộ. Không nhập hoặc thử mật khẩu của người dùng.
- Kiểm thử giao diện riêng đạt cả 5 tình huống lỗi/kết nối lại/tạo tài khoản/đăng nhập. Không dùng CSDL thật để tạo tài khoản thử.
- Đã gộp và bỏ 11 file Markdown trùng khỏi vị trí đang dùng, giữ lại 4 file chính tại thời điểm dọn. Sau đó bổ sung riêng hướng dẫn truy vấn theo yêu cầu người dùng, nên hiện có 5 file chính. Bản trước khi dọn gồm đủ 15 file, đã kiểm tra SHA256, nằm tại `work/tai-lieu-truoc-khi-gop-20261111.zip`.
- Theo yêu cầu tiếp theo, đã viết `HUONG_DAN_TRUY_VAN_BACKEND.md`, giải thích vị trí 7 chức năng, các API và những điều chỉnh từ SQL sang backend. Đã ghi rõ địa bàn đếm theo năm đăng ký, gồm Chờ xử lý/Đã duyệt và đang loại Từ chối; quy ước với hồ sơ Từ chối được ghi để người dùng đọc lại. Lượt viết tài liệu không đổi quy tắc đếm hoặc dữ liệu.
- Khi người dùng không mở được liên kết, đã bổ sung mục 0 ngay đầu hướng dẫn truy vấn: cây thư mục tổng thể, các bước Windows + E/Alt + D, đường dẫn Windows bằng chữ đến hai file SQL [A]/[B], cách tìm tên truy vấn bằng Ctrl + F và phân biệt queries.js/index.js. Giữ nguyên 5 file Markdown chính, không tạo thêm tài liệu rời. Đã kiểm tra 8 đường dẫn Windows ghi trong hướng dẫn và 38 liên kết nội bộ đều tồn tại; luồng khởi chạy cũng đã đối chiếu lại với mã nguồn.
- Đã mở rộng mục 0.4–0.7 trong cùng hướng dẫn để giải thích rõ SELECT/JOIN dùng chung trong queries.js, các bước index.js nhận CCCD/bộ lọc, thực thi qua MySQL và trả JSON; có ví dụ mã thật, sơ đồ luồng, so sánh danh sách với tra cứu và phân biệt các file index.js. Đã ghi đúng phạm vi: registrations/index.js còn chứa SQL tạo/sửa/xóa và SQL phụ trợ; không khẳng định toàn bộ SQL đều nằm trong queries.js. Đã đối chiếu nội dung mới với mã nguồn, kiểm tra 12 đường dẫn Windows và 38 liên kết nội bộ đều tồn tại. Lượt này chỉ cập nhật tài liệu.
- Người dùng làm rõ chỉ quan tâm nội dung SQL có đúng và giống truy vấn đã đưa hay không. Đã bổ sung bảng đối chiếu 7 câu ngay đầu hướng dẫn, ưu tiên nội dung SQL. Bản database/truy_van.sql giữ nguyên thân SQL của bản nguồn đã lưu; đường dẫn E:/CSDL/truy_van.sql hiện không còn. Không khẳng định backend chép nguyên văn: riêng câu tuổi/nguyên nhân chỉ GROUP BY trong SQL, JavaScript mới tổng hợp tổng nhóm/top; có khác biệt trên ngày không hợp lệ, nhóm rỗng và tên nguyên nhân rỗng. Địa bàn loại Từ chối đúng như SQL nguồn. Chỉ viết ghi chú, chưa thay SQL hoặc đọc/ghi CSDL trong lượt này.
- Đã rà soát tiếp Markdown theo yêu cầu: 5 file chính không trùng nguyên văn và có mục đích riêng. Thư mục lưu trước chuyển bảng có 11 file MD lịch sử, trong đó DOI_CHIEU_BAO_CAO_SQL.md ở gốc bản lưu và docs/ là một cặp trùng SHA256; giữ nguyên bộ lưu, chưa xóa thêm. Người dùng muốn bố cục báo cáo riêng phần web gồm chức năng, phân quyền, ảnh và chú thích. Đã đối chiếu UI/API: cả ADMIN/cán bộ xem, tạo, đổi trạng thái, xuất CSV, tra cứu/in và xem thống kê; chỉ ADMIN xóa hồ sơ, thêm danh mục, quản lý tài khoản và cấp mã mời. Không mô tả sửa toàn bộ hồ sơ hoặc CRUD danh mục vì web chưa có. Đề cương và gợi ý ảnh được trình bày trong chat; chưa chụp thêm ảnh, chưa tạo file MD mới.

## Kết thúc phiên tiếp tục

Đã hoàn tất phần sửa đăng nhập, đặt truy vấn trong backend, mở lại bản local, dọn tài liệu và bổ sung hướng dẫn truy vấn. Có 5 file Markdown chính. Lượt dọn đã kiểm tra nguồn SQL khớp SHA256 của kết quả Docker/API 52/52. Sau khi thêm hướng dẫn truy vấn, đã kiểm tra 38 liên kết nội bộ trong cả 5 tài liệu, gồm các số dòng đến mã nguồn; đều tồn tại. Nội dung hướng dẫn cũng đã được đối chiếu lại với SQL, các API và hàm tổng hợp.

Kết quả mới đã lưu ngay trong dự án:

- `work/new-schema-review/ui-live-3001-result-20261111.json`: kiểm tra trực tiếp màn hình đăng nhập, chỉ đọc.
- `work/new-schema-review/ui-auth-resilience-result-20261111.json`: 5 tình huống giao diện riêng.
- `work/new-schema-review/ui-live-3001-desktop-20261111.png` và `ui-live-3001-mobile-20261111.png`: ảnh kiểm tra desktop/điện thoại.

Người dùng mở `http://localhost:3001`, nhấn Ctrl+F5 và đăng nhập bằng tài khoản đã tạo. Không có công việc kỹ thuật nào trong lượt này còn chờ thực hiện; chưa thử mật khẩu hay đăng nhập thay người dùng trên CSDL đang dùng.

## Năm file cần đọc

- `README.md`: tổng quan, truy vấn backend, ràng buộc và các đề xuất chưa triển khai.
- `HUONG_DAN_KHOI_TAO_CSDL_MOI.md`: khởi tạo, mở/dừng và giữ dữ liệu.
- `HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md`: đăng nhập và lỗi khởi tạo đã sửa.
- `TRANG_THAI_TIEP_TUC.md`: trạng thái công việc và mốc kiểm tra gần nhất.
- `HUONG_DAN_TRUY_VAN_BACKEND.md`: giải thích đủ 7 chức năng truy vấn và ghi chú quy tắc đếm địa bàn để người dùng xem lại.

## Cách tiếp tục nếu phiên làm việc bị ngắt

Đọc file này trước, sau đó đọc `HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md`. Kiểm tra trạng thái thực tế trước khi thay đổi. Không chạy lại SQL sửa một lần trong `work/sua-khoi-tao-dang-nhap-20261110/` trên CSDL đã có dữ liệu.
