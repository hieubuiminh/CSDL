# Hệ thống quản lý đăng ký khai tử — bộ bảng mới

**Chỉ chạy trên máy cá nhân.** Bản mới dùng http://localhost:3001; MySQL không mở cổng ra ngoài. Không xuất bản lên hosting/cloud hoặc tạo tunnel.

Các hướng dẫn đang dùng nằm ngay trong thư mục chính:

- File này: tổng quan, vị trí mã nguồn và ghi chú thiết kế CSDL.
- [Hướng dẫn khởi tạo CSDL mới](HUONG_DAN_KHOI_TAO_CSDL_MOI.md): cài, mở, dừng và giữ dữ liệu.
- [Hướng dẫn đăng nhập, sửa lỗi khởi tạo](HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md): tài khoản và xử lý lỗi đăng nhập.
- [Trạng thái để tiếp tục](TRANG_THAI_TIEP_TUC.md): đã làm gì, kiểm tra gần nhất và việc còn lại khi phiên làm việc bị ngắt.
- [Giải thích truy vấn backend](HUONG_DAN_TRUY_VAN_BACKEND.md): đầu file có bảng đối chiếu 7 truy vấn backend với SQL nguồn, ghi rõ câu tuổi/nguyên nhân chưa tự tổng hợp đủ bằng SQL; phần sau có cây thư mục, cách tìm file và giải thích từng chức năng.

Các tài liệu trùng đã được gộp ngày 11/11/2026; bản trước khi dọn nằm trong `work/tai-lieu-truoc-khi-gop-20261111.zip`.

## Chạy lần đầu

Mở Docker Desktop rồi chạy PowerShell:

~~~powershell
cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
~~~

Bản local đã được mở lại và kiểm tra ngày 11/11/2026. Hiện CSDL có tài khoản, web hiển thị **Đăng nhập**. Mở http://localhost:3001, nhấn Ctrl+F5 và dùng tài khoản bạn đã tạo cho bản này. Tài khoản cũ không tự chuyển sang CSDL mới; không có mật khẩu ADMIN mẫu.

## Các file SQL đang dùng

| File | Vai trò |
|---|---|
| database/tao_bang.sql | Tạo bảng theo nguồn E:/CSDL/tao_bang.sql, bỏ DROP DATABASE và bổ sung trigger liên bảng. |
| database/du_lieu_mau.sql | Giữ nguyên 491 bản ghi từ file mẫu người dùng gửi, nạp riêng sau tạo bảng. |
| database/truy_van.sql | Bảy truy vấn theo nguồn E:/CSDL/truy_van.sql. |
| database/app_setup.sql | Tạo bảng tài khoản ứng dụng, không thay thế 9 bảng nghiệp vụ. |

CSDL mới: **quan_li_khai_tu**. CCCD người mất nằm ở Giay_Bao_Tu; Ho_So_Khai_Tu liên kết qua SoGiayBaoTu. Không dùng mô hình cũ chứa CCCD_NgMat trong Ho_So_Khai_Tu.

## Ràng buộc đang áp dụng

| Quy tắc | Cách bảo vệ |
|---|---|
| Người đi khai khác người mất | Trigger kiểm tra khi thêm/sửa hồ sơ và khi sửa giấy báo tử đã liên kết. |
| Ngày mất ≤ ngày cấp giấy ≤ ngày đăng ký | CHECK trên giấy báo tử và trigger liên bảng; so sánh theo ngày. |
| Một công dân có tối đa một hồ sơ | CCCD người mất UNIQUE trong giấy báo tử; số giấy báo tử UNIQUE trong hồ sơ. |
| Đồng bộ trạng thái Đã mất | Trigger cho hồ sơ không bị từ chối, kể cả Chờ xử lý; khi đổi người mất thì đồng bộ người mới. Không tự chuyển người cũ về Còn sống. |

Có 9 khóa ngoại, 7 CHECK, 4 UNIQUE và 6 trigger. Hồ sơ mặc định `Chờ xử lý`. File [kiểm tra chỉ đọc](docs/kiem_tra_rang_buoc_chi_doc.sql) dùng để xem các vi phạm đã định nghĩa mà không sửa dữ liệu.

## Dữ liệu mẫu và báo cáo

Mẫu ban đầu có 200 công dân, 100 giấy báo tử, 100 hồ sơ, 64 an táng; cùng các danh mục nguyên nhân, CSYT, UBND, cán bộ và 8 địa bàn. Khi kiểm tra ngày 11/11, bản đang dùng đã có thêm dữ liệu: 202 công dân, 101 giấy báo tử, 101 hồ sơ và 1 tài khoản. Các dữ liệu mới này được giữ nguyên; số liệu đối chiếu dưới đây dành cho mẫu ban đầu.

Nguồn đếm theo bộ truy vấn mới: giới tính 100 công dân đã mất; tuổi theo 81 hồ sơ đã duyệt; địa bàn năm 2026 có 73 hồ sơ không bị từ chối; năm mất 2024/2025/2026 lần lượt 8/16/76. Quý III/2026 có một CSYT cấp 52 giấy. Số/tỷ lệ mất tại CSYT là ước tính từ chuỗi tên/địa chỉ.

ADMIN quản lý tài khoản và danh mục. Cán bộ tạo/xử lý hồ sơ, tra cứu và xem báo cáo. Backend và từng báo cáo vẫn tách thành các module riêng.

## Truy vấn trong backend

Đọc [hướng dẫn truy vấn chi tiết](HUONG_DAN_TRUY_VAN_BACKEND.md) để đối chiếu từng yêu cầu với file SQL, module thực thi và API.

- backend/modules/reports/queries.js: SQL cho các báo cáo, dùng chung với tổng quan.
- backend/modules/registrations/queries.js: SQL danh sách, tra cứu hồ sơ.
- backend/modules/reports/*/index.js: nhận bộ lọc, chạy SQL và trả kết quả cho web.
- Frontend trong public/ hiển thị kết quả, không chạy SQL trực tiếp.

## Giữ bản cũ

Docker dùng dự án khai-tu-bang-moi-local, image khai-tu-app:bang-moi và volume mới. CSDL cũ chưa bị xóa. SQL, tài liệu và cấu hình cũ được lưu tại work/truoc-khi-dung-bang-moi-20261110/.

Không chạy lại file nâng cấp của mô hình cũ trên bộ bảng mới. Cách quay về bản cũ nằm trong hướng dẫn khởi tạo.

## Kiểm tra

Kiểm tra SQL ban đầu đạt 45/45, nhưng chưa bao phủ việc Docker tạo sẵn CSDL với collation khác. Đã bổ sung kiểm thử khởi tạo Docker thực tế và HTTP thật: **52/52 đạt**, gồm 24 kiểm tra HTTP về tạo ADMIN, đăng xuất, đăng nhập, phân quyền cán bộ và các API dữ liệu. 491 bản ghi mẫu khớp checksum nguồn trong môi trường thử. Hai lượt có phạm vi khác nhau, không cộng thành một bộ kiểm tra duy nhất. Xem [kết quả Docker và API](work/new-schema-review/docker-first-init-results.json) và [kết quả SQL trước đó](work/new-schema-review/sql-test-results.json); các container thử đã được xóa, tài khoản thử không nằm trong CSDL đang dùng.

Kiểm tra backend bằng npm test với Node.js từ 20 trở lên và thư viện đã cài. Đây là kiểm thử dữ liệu giả; không kết nối CSDL người dùng.

Các lần sửa SQL sau này không tự cập nhật một volume MySQL đã có dữ liệu. Xem [hướng dẫn đầy đủ](HUONG_DAN_KHOI_TAO_CSDL_MOI.md) trước khi nạp lại.

## Ghi chú thiết kế chưa bổ sung

Các mục này được giữ lại để tham khảo, chưa tự động thêm vào mô hình:

- Bảo vệ ngày sinh ≤ ngày mất và ngày an táng ≥ ngày mất trên mọi đường cập nhật, kể cả sửa trực tiếp công dân hoặc giấy báo tử.
- Phát hiện khác biệt họ tên/ngày sinh khi nhập lại một CCCD đã có.
- Lưu lịch sử người xử lý, lý do từ chối/đính chính và quy trình mở lại hồ sơ.
- Lưu UBND tại thời điểm tiếp nhận để giữ đúng lịch sử khi cán bộ chuyển đơn vị.
- Bổ sung tỉnh/thành và nơi mất tại CSYT thành trường có cấu trúc để thống kê chính xác hơn phép dò tên/địa chỉ hiện tại.
