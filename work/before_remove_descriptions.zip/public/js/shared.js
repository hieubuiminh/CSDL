export const state = { user: null, lookups: { csyt: [], causes: [], wards: [], officers: [], offices: [] }, registrations: [] };
export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
export const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const iconNames = new Set(['layout-dashboard','file-text','search','chart-no-axes-column-increasing','settings-2','users-round','plus','calendar-days','refresh-cw','files','loader-circle','circle-check','arrow-right','download','key-round','log-out','x','building','user-round','hospital','map-pin','stethoscope','database','search-x','copy','shield','trash-2']);
export function icon(name, className = '') {
  if (!iconNames.has(name)) throw new RangeError(`Unknown interface icon: ${name}`);
  const extraClass = className ? ` ${esc(className)}` : '';
  return `<svg class="ui-icon${extraClass}" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><use href="/assets/icons.svg#${name}"></use></svg>`;
}
export const fmt = value => value ? new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(`${String(value).slice(0, 10)}T00:00:00`)) : '—';
export const num = value => new Intl.NumberFormat('vi-VN').format(Number(value || 0));
export async function api(url, options = {}) {
  const response = await fetch(url, { credentials: 'same-origin', ...options, headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(data.error || 'Không thể tải dữ liệu.'); error.status = response.status; throw error; }
  return data;
}
export function showNotice(message, error = false) {
  const el = $('#notice'); el.textContent = message; el.classList.toggle('error', error); el.classList.remove('hidden');
  clearTimeout(showNotice.timer); showNotice.timer = setTimeout(() => el.classList.add('hidden'), 4500);
}
export const statusClass = status => status === 'Đã hoàn tất' ? 'done' : status === 'Đang xử lý' ? 'progress' : status === 'Từ chối' ? 'rejected' : 'received';
export function tableMarkup(rows, compact = false, canDelete = false) {
  if (!rows.length) return '<div class="empty-state"><span class="empty-state-icon">' + icon('database') + '</span><strong>Chưa có hồ sơ</strong><p>Hồ sơ sẽ xuất hiện ở đây sau khi được tạo.</p></div>';
  const actionHead = canDelete ? '<th>THAO TÁC</th>' : '';
  const body = rows.map(r => {
    const status = compact
      ? '<span class="status-pill ' + statusClass(r.status) + '">' + esc(r.status) + '</span>'
      : '<select class="status-select ' + statusClass(r.status) + '" data-status-id="' + esc(r.id) + '">' + ['Đã tiếp nhận', 'Đang xử lý', 'Đã hoàn tất', 'Từ chối'].map(s => '<option ' + (s === r.status ? 'selected' : '') + '>' + s + '</option>').join('') + '</select>';
    const action = canDelete
      ? '<td><button type="button" class="table-action" data-delete-id="' + esc(r.id) + '" data-delete-name="' + esc(r.deceasedName) + '" aria-label="Xóa hồ sơ ' + esc(r.id) + '">' + icon('trash-2') + ' Xóa</button></td>'
      : '';
    return '<tr><td><strong class="mono">' + esc(r.id) + '</strong></td><td><strong>' + esc(r.deceasedName) + '</strong><small>' + esc(r.deceasedId) + '</small></td><td><strong>' + esc(r.applicantName) + '</strong><small>' + esc(r.relation) + '</small></td><td>' + fmt(r.registeredAt) + '</td><td>' + esc(r.officeName || '—') + '</td><td>' + status + '</td>' + action + '</tr>';
  }).join('');
  return '<div class="table-wrap"><table><thead><tr><th>SỐ HỒ SƠ</th><th>NGƯỜI ĐÃ MẤT</th><th>NGƯỜI ĐĂNG KÝ</th><th>NGÀY ĐĂNG KÝ</th><th>ĐƠN VỊ TIẾP NHẬN</th><th>TRẠNG THÁI</th>' + actionHead + '</tr></thead><tbody>' + body + '</tbody></table></div>';
}