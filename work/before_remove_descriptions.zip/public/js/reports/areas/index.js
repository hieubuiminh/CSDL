import { $, api, num } from '../../shared.js';
import { reportTable, setLoading, setReportError } from '../shared.js';

export function initAreaReport() {
  const input = $('#reportYear'); input.value = String(new Date().getFullYear());
  input.addEventListener('input', () => input.setCustomValidity(''));
  $('#reportYearForm').addEventListener('submit', event => { event.preventDefault(); loadAreaReport(); });
}

export async function loadAreaReport() {
  const input = $('#reportYear'); const year = Number(input.value.trim());
  if (!Number.isInteger(year) || year < 1000 || year > 9998) {
    input.setCustomValidity('Vui lòng nhập năm từ 1000 đến 9998.'); input.reportValidity(); return;
  }
  input.setCustomValidity(''); setLoading(['areaReport']);
  try {
    const result = await api(`/api/reports/areas?year=${encodeURIComponent(year)}`);
    // The selected year can change while an earlier request is in flight.
    if (Number(input.value) !== year) return;
    const rows = [...result.rows].sort((a, b) => Number(b.value) - Number(a.value) || a.name.localeCompare(b.name, 'vi'));
    const total = rows.reduce((sum, row) => sum + Number(row.value || 0), 0);
    $('#areaReportCaption').textContent = `Các xã Hà Nội · Năm đăng ký ${result.year}`;
    const incomplete = Number(result.scope?.unclassifiedCount ?? result.scope?.incompleteCount ?? result.unclassifiedCount ?? 0);
    const scope = result.scope?.note || `Đếm người có hồ sơ đăng ký trong năm, không gồm hồ sơ từ chối. Địa bàn lấy theo nơi mất trên giấy báo tử; chỉ gồm đơn vị loại Xã thuộc Hà Nội đã được phân loại trong ứng dụng.${incomplete ? ` Có ${num(incomplete)} địa bàn chưa được phân loại đầy đủ nên chưa được đưa vào báo cáo.` : ''}`;
    $('#areaReportScope').textContent = `${scope} Tổng ${num(rows.length)} xã, ${num(total)} ca.${incomplete ? ' ADMIN có thể bổ sung phân loại tại Dữ liệu dùng chung.' : ''}`;
    $('#areaReport').innerHTML = reportTable(['Xếp hạng', 'Mã xã', 'Xã tại Hà Nội', 'Số ca đăng ký'], rows.map((row, index) => [num(index + 1), row.id, row.name, num(row.value)]), 'Chưa có xã nào được phân loại thuộc Hà Nội. ADMIN bổ sung tỉnh/thành và loại đơn vị trong Dữ liệu dùng chung để hiển thị báo cáo.');
  } catch (error) { setReportError(['areaReport'], error.message); }
}
