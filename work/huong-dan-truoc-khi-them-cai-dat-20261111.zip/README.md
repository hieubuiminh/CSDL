# Hệ thống quản lý đăng ký khai tử

Chỉ chạy local trên máy cá nhân tại http://localhost:3001. CSDL dùng tên quan_li_khai_tu. MySQL không công bố cổng ra ngoài.

## Bạn cần đọc file nào?

| Bạn muốn làm gì? | File cần đọc |
|---|---|
| Mở web, đăng nhập, dừng/mở lại hoặc cài lần đầu | [Hướng dẫn chạy web và đăng nhập](HUONG_DAN_KHOI_TAO_CSDL_MOI.md) |
| Xem SQL nằm ở đâu, có khớp truy vấn bạn đưa không | [Hướng dẫn truy vấn](HUONG_DAN_TRUY_VAN_BACKEND.md) |

Tên file hướng dẫn khởi tạo được giữ nguyên để dễ tìm; nội dung đã gộp cả đăng nhập. Hiện có 3 file MD chính, tính cả README này. Bản trước khi gộp được lưu tại work/huong-dan-day-du-truoc-khi-gop-20261111.zip.

## Các thư mục chính

| Thư mục | Nội dung |
|---|---|
| backend | Xử lý chức năng và thực thi SQL. |
| public | Giao diện web. |
| database | SQL tạo bảng, mẫu, tài khoản và truy vấn. |
| docker | Cấu hình chạy local. |
| tests | Các kiểm thử. |
| docs | Script kiểm tra ràng buộc chỉ đọc. |
| work | Bản lưu và kết quả kiểm tra. |

Người mất được liên kết qua Giay_Bao_Tu.CCCD_NgMat; Ho_So_Khai_Tu nối qua SoGiayBaoTu.

## Ràng buộc hiện có

- Người đi khai khác người mất.
- Ngày mất ≤ ngày cấp giấy báo tử ≤ ngày đăng ký, so sánh theo ngày.
- Một công dân có tối đa một hồ sơ qua các khóa duy nhất trên giấy báo tử và hồ sơ.
- Công dân được đánh dấu Đã mất với hồ sơ không bị từ chối, kể cả Chờ xử lý; không tự chuyển về Còn sống khi từ chối/xóa hồ sơ.

Có 9 khóa ngoại, 7 CHECK, 4 UNIQUE và 6 trigger. [Script kiểm tra chỉ đọc](docs/kiem_tra_rang_buoc_chi_doc.sql) giữ nguyên trong dự án.

ADMIN quản lý thêm tài khoản/danh mục và xóa hồ sơ. Cả ADMIN/cán bộ đều xem, tạo, thay đổi trạng thái, tra cứu/in, xuất CSV và xem thống kê theo mã hiện tại.

## Ghi chú thiết kế để xem lại sau

Các đề xuất dưới đây chưa được tự thêm vào mô hình:

- Bảo vệ ngày sinh ≤ ngày mất và ngày an táng ≥ ngày mất trên mọi đường cập nhật.
- Phát hiện khác biệt họ tên/ngày sinh khi nhập lại CCCD đã có.
- Lưu lịch sử người xử lý, lý do từ chối/đính chính và quy trình mở lại hồ sơ.
- Lưu UBND tại thời điểm tiếp nhận để giữ lịch sử khi cán bộ chuyển đơn vị.
- Thêm tỉnh/thành và nơi mất tại CSYT thành trường có cấu trúc để thống kê chính xác hơn.

CSDL và volume cũ vẫn giữ nguyên. Trong lượt sắp xếp tài liệu ngày 11/11/2026, không thay đổi mã nguồn, SQL, quy tắc xử lý hoặc dữ liệu.

