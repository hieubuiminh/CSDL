# Hướng dẫn mở web, đăng nhập và khởi tạo khi cần

Cập nhật ngày 11/11/2026. Tài liệu này đã gộp phần hướng dẫn đăng nhập vào hướng dẫn chạy web.

Website chỉ phục vụ trên máy này tại http://localhost:3001. MySQL không mở cổng ra ngoài. CSDL đang dùng là quan_li_khai_tu; giữ nguyên CSDL và các volume cũ.

## 1. Mở bản đang có trên máy

Máy này đã được khởi tạo và đã có tài khoản trong lần kiểm tra trước đó. Bạn mở lại dịch vụ, không nạp lại SQL mẫu.

1. Mở Docker Desktop và đợi Docker sẵn sàng.
2. Mở PowerShell, chạy:

    ~~~powershell
    cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --no-build
    ~~~

3. Mở http://localhost:3001 và nhấn Ctrl + F5.
4. Đăng nhập bằng tài khoản bạn đã tạo cho bản này. Nếu quên mật khẩu, chọn Quên mật khẩu? và dùng thông tin khôi phục đã đặt.

## 2. Chỉ dùng khi cài lần đầu trên máy mới

Nếu máy chưa có image ứng dụng, thay lệnh mở ở mục 1 bằng:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build

Lệnh được chạy từ thư mục dự án. Docker tạo vùng lưu trữ nếu chưa có và chỉ chạy SQL khởi tạo khi vùng dữ liệu MySQL còn mới, theo thứ tự:

| Thứ tự | File | Công dụng |
|---|---|---|
| 1 | database/tao_bang.sql | Tạo 9 bảng nghiệp vụ và 6 trigger. |
| 2 | database/du_lieu_mau.sql | Nạp 491 bản ghi mẫu ban đầu. |
| 3 | database/app_setup.sql | Tạo bảng tài khoản web. |

database/truy_van.sql là bản SQL để đọc kết quả 7 chức năng, không phải bước tạo bảng hoặc nạp dữ liệu.

Giữ app_setup.sql. Docker có thể cần Internet để tải image/thư viện khi dựng; web và dữ liệu vẫn chỉ được phục vụ local.

### Tạo tài khoản đầu tiên

Chỉ khi chưa có ADMIN, web hiện Tạo tài khoản quản trị. Nhập họ tên, tên đăng nhập, mật khẩu ít nhất 10 ký tự, nhập lại mật khẩu, chọn câu hỏi khôi phục và câu trả lời ít nhất 3 ký tự.

Nếu web hiện Đăng nhập thì đã có tài khoản, không cần tạo lại. Dữ liệu mẫu không có mật khẩu ADMIN cài sẵn; tài khoản cũ ở cổng 3000 không tự chuyển sang bản mới. Dữ liệu và tài khoản trên các máy không tự đồng bộ.

## 3. Dừng rồi mở lại mà giữ dữ liệu

Tại thư mục dự án, dừng dịch vụ bằng:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml stop

Khi cần dùng lại, thực hiện mục 1. Không dùng lệnh xóa volume để xử lý đăng nhập hoặc để đưa số hồ sơ về số mẫu ban đầu.

## 4. Nếu chưa mở được hoặc có thông báo lỗi

Trước hết kiểm tra đúng địa chỉ localhost:3001, nhấn Ctrl + F5; nếu có nút Thử lại thì bấm sau khi dịch vụ sẵn sàng.

Xem trạng thái và nhật ký bằng:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml ps
    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml logs --tail=80 db app

MySQL cần healthy và app cần đang chạy. Nếu cổng 3001 bị ứng dụng khác chiếm, cần xử lý trùng cổng.

Lỗi cũ “thiếu bảng App_User” xuất phát từ lần khởi tạo dừng vì collation không thống nhất, khiến dữ liệu mẫu bị rollback và bảng tài khoản chưa được tạo. Lỗi đó đã được sửa ở lần làm trước; kết quả kiểm tra được lưu tại [kết quả Docker và API](work/new-schema-review/docker-first-init-results.json).

Nếu lỗi xuất hiện lại, đọc nhật ký để xác định nguyên nhân. Không chạy lại toàn bộ SQL mẫu hoặc xóa CSDL để thử sửa lỗi. Script sửa một lần trong thư mục work không dành cho CSDL đã có dữ liệu.

## 5. Cập nhật ứng dụng và SQL là hai việc khác nhau

Khi cần áp dụng mã ứng dụng mới và dịch vụ đang chạy:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml build app
    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --no-deps --no-build --force-recreate app

Sau đó nhấn Ctrl + F5. Các lệnh này thay container app, giữ dữ liệu MySQL.

Sửa file SQL rồi dựng lại ứng dụng không tự cập nhật CSDL đã có. Các thay đổi SQL cần được xem xét và chạy bổ sung riêng; không dùng cách nạp lại schema/dữ liệu mẫu trên CSDL đang dùng.

Đây là hướng dẫn để đọc khi cần cập nhật. Trong lượt dọn tài liệu hiện tại không thực hiện các lệnh cập nhật này và không sửa mã ứng dụng.

## 6. Thông tin tham khảo khi cần

- Mẫu ban đầu có 200 công dân, 100 giấy báo tử, 100 hồ sơ và 64 an táng. Số thực tế tăng khi bạn thêm hồ sơ.
- CCCD mẫu để tra cứu: 001000000001.
- Người mất nằm ở Giay_Bao_Tu.CCCD_NgMat; hồ sơ nối qua SoGiayBaoTu.
- Bộ nguồn gốc và cấu hình trước chuyển bảng nằm trong work/truoc-khi-dung-bang-moi-20261110/. Dùng bản SQL hiện tại trong database/; nguồn gốc tạo bảng có lệnh DROP DATABASE đã được bỏ ở bản dùng cho app.
- Bản sao lưu CSDL trước lần sửa khởi tạo nằm tại work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql.
- Nếu cần quay về bản cũ, xem mục 7 dưới đây.
- Nếu cần đối chiếu câu SQL, đọc [hướng dẫn truy vấn](HUONG_DAN_TRUY_VAN_BACKEND.md).

Chỉ khi tạo CSDL mới/riêng bằng công cụ MySQL, dùng MySQL từ 8.0.16 và chạy theo thứ tự: tao_bang.sql → du_lieu_mau.sql đúng một lần → app_setup.sql nếu dùng web. Chạy truy_van.sql khi cần xem kết quả. Nếu gặp trùng mã, dừng để kiểm tra, không ghi đè dữ liệu đang có.

## 7. Khi cần mở lại bản cũ

Chỉ dùng khi bạn muốn quay về bản trước và image, volume cũ còn trên máy. Chạy từ thư mục dự án:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml down
    docker compose -p he_thong_quan_ly_dang_ky_khai_tu -f work/truoc-khi-dung-bang-moi-20261110/docker/compose.yaml up -d --no-build

Bản cũ mở ở http://localhost:3000. Các lệnh trên giữ dữ liệu; không thêm tùy chọn xóa volume.

