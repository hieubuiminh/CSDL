# Trạng thái để tiếp tục công việc

Cập nhật ngày 11/11/2026. File này ghi trạng thái và bằng chứng; hướng dẫn sử dụng nằm trong hai file được chỉ ra ở README.

## 1. Yêu cầu cần giữ

- Chỉ chạy trên máy cá nhân, web ở 127.0.0.1:3001; MySQL không công bố cổng.
- Giữ nguyên CSDL và volume cũ, không tự xóa hoặc nạp lại dữ liệu.
- Không tự tạo ADMIN hoặc thử mật khẩu thay người dùng trên CSDL đang dùng.
- Lượt hiện tại chỉ sửa hướng dẫn, không sửa code, SQL hoặc cách thay đổi trạng thái hồ sơ.

## 2. Phần mềm đã hoàn tất trước lượt dọn hướng dẫn

- Dùng bảng mới, CSDL quan_li_khai_tu; người mất nối qua Giay_Bao_Tu.CCCD_NgMat.
- Đã sửa lỗi khởi tạo collation 1267 ở lần làm trước, tạo đủ 6 trigger, nạp 491 dòng mẫu ban đầu và tạo App_User.
- Lần kiểm tra ngày 11/11: có 202 công dân, 101 giấy báo tử, 101 hồ sơ, 64 an táng, 1 tài khoản; tổng nghiệp vụ 495 dòng. Dữ liệu thêm sau mẫu được giữ nguyên.
- Đã dựng lại app, đối chiếu hash CSS/auth.js khớp source, xác nhận MySQL healthy và các volume cũ còn tồn tại ở lần kiểm tra đó.
- API auth trả 200, setupRequired=false; màn hình Đăng nhập đúng. Desktop 1440px và điện thoại 390px không tràn, không lỗi JavaScript; 23 yêu cầu kiểm tra đều chỉ đọc.
- Có 7 chức năng truy vấn, dùng 2 file queries.js. SQL tuổi cần JavaScript tổng hợp tiếp; chưa đổi SQL để sao chép nguyên văn nguồn.
- Địa bàn vẫn đếm hồ sơ Chờ xử lý/Đã duyệt trong năm đăng ký, loại Từ chối, như SQL nguồn; phạm vi Hà Nội dựa vào danh mục.
- Đã gợi ý bố cục báo cáo web và ảnh/chú thích trong chat. Chưa chụp thêm ảnh báo cáo.

Đây là trạng thái đã ghi nhận trước đó; lượt dọn hướng dẫn không khởi động hoặc kiểm tra lại dịch vụ/CSDL.

## 3. Hướng dẫn đã sắp xếp lại

Giữ 4 file MD chính:

| File | Dùng để làm gì? |
|---|---|
| README.md | Mục lục và ghi chú tổng quan. |
| HUONG_DAN_KHOI_TAO_CSDL_MOI.md | Mở web, đăng nhập, lỗi thường gặp và cài lần đầu. |
| HUONG_DAN_TRUY_VAN_BACKEND.md | 5 mục ngắn để tìm và đối chiếu 7 truy vấn. |
| TRANG_THAI_TIEP_TUC.md | Trạng thái và các bản lưu. |

Đã gộp phần đăng nhập vào hướng dẫn chạy web rồi bỏ file HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md khỏi vị trí đang dùng. Đã bỏ giải thích luồng JavaScript dài, cây thư mục nhiều tầng và nội dung lặp trong hướng dẫn truy vấn. Các ghi chú quan trọng về SQL, ràng buộc và khởi tạo được giữ.

Nguồn trước khi dọn được ghi SHA256 tại work/ma-nguon-truoc-khi-don-huong-dan-20261111.json để đối chiếu sau khi sửa tài liệu.

Đã đối chiếu đủ 71 file mã nguồn/SQL/cấu hình: tất cả giữ nguyên SHA256 và số file không đổi. Đã kiểm tra 13 liên kết nội bộ của 4 tài liệu, không còn liên kết đến file hướng dẫn đã bỏ; nội dung gộp/rút gọn cũng đã được rà soát lại.

## 4. Bằng chứng kiểm tra từ các lượt trước

- [Docker khởi tạo và API](work/new-schema-review/docker-first-init-results.json): 52/52 đạt, gồm 24 kiểm tra HTTP trong môi trường riêng đã xóa.
- [SQL ban đầu](work/new-schema-review/sql-test-results.json): 45/45; chưa bao phủ đường Docker tạo sẵn CSDL khác collation. Hai lượt có phạm vi khác nhau, không cộng thành một bộ.
- [Giao diện local](work/new-schema-review/ui-live-3001-result-20261111.json): kiểm tra chỉ đọc, đã có tài khoản.
- [Các tình huống giao diện](work/new-schema-review/ui-auth-resilience-result-20261111.json): 5 tình huống đạt.
- Ảnh kiểm tra: work/new-schema-review/ui-live-3001-desktop-20261111.png và ui-live-3001-mobile-20261111.png.

Không coi lượt viết hướng dẫn là một lượt chạy thử mới.

## 5. Các bản lưu

| Vị trí | Nội dung |
|---|---|
| work/huong-dan-day-du-truoc-khi-gop-20261111.zip | Đủ 5 MD trước lượt gộp/rút gọn hiện tại; đã kiểm tra bản lưu khớp SHA256. |
| work/huong-dan-truoc-khi-rut-gon-20261111.zip | Bản lưu 3 tài liệu trước bước gộp toàn bộ. |
| work/tai-lieu-truoc-khi-gop-20261111.zip | 15 MD trước lượt dọn tài liệu đầu tiên. |
| work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql | Sao lưu CSDL local mới trước lần sửa khởi tạo. |
| work/truoc-khi-dung-bang-moi-20261110/ | SQL, cấu hình và tài liệu của mô hình trước; có bản nguồn người dùng. |

Không chạy lại script sửa một lần trong work/sua-khoi-tao-dang-nhap-20261110/ trên CSDL đã có dữ liệu. Script đó dành cho lần khởi tạo dở đã xác minh chín bảng rỗng.

## 6. Khi cần quay về bản cũ

Chỉ dùng khi chủ dự án thực sự muốn mở lại bản trước, image cũ và volume cũ còn trên máy:

    docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml down
    docker compose -p he_thong_quan_ly_dang_ky_khai_tu -f work/truoc-khi-dung-bang-moi-20261110/docker/compose.yaml up -d --no-build

Chạy từ thư mục E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu. Bản cũ mở ở localhost:3000. Không thêm tùy chọn xóa volume.

Để tiếp tục công việc, đọc README rồi hướng dẫn tương ứng, kiểm tra trạng thái thực tế trước khi thay đổi. CSDL cũ và các dữ liệu hiện có cần được bảo toàn.

