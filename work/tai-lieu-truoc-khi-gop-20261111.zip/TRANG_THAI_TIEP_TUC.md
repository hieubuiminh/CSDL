# Trạng thái để tiếp tục công việc

Cập nhật ngày **11/11/2026**. Lưu ngay trong thư mục chính của dự án, cập nhật sau mỗi mốc công việc.

## Nguyên tắc cần giữ

- Chỉ chạy trên máy này; web chỉ mở tại `127.0.0.1:3001`, MySQL không mở cổng ra ngoài.
- Giữ nguyên CSDL cũ và các volume cũ. Không xóa CSDL hoặc nạp lại dữ liệu khi đã có dữ liệu.
- Dùng mô hình mới trong `database/tao_bang.sql`, liên kết người mất qua `Giay_Bao_Tu.CCCD_NgMat`.
- Không tự tạo ADMIN hoặc đặt mật khẩu thay chủ dự án trên CSDL đang dùng.

## Đã hoàn tất trước khi tiếp tục

- Đã sửa lỗi khởi tạo MySQL do collation không thống nhất; đã nạp 491 bản ghi mẫu, tạo `App_User` và 6 trigger trên bản local mới.
- Đã sao lưu trước khi sửa tại `work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql`.
- Đã kiểm thử lần khởi tạo Docker thật và các API trong môi trường riêng: **52/52 đạt**; kết quả ở `work/new-schema-review/docker-first-init-results.json`.
- Đã đặt truy vấn trong backend: `backend/modules/reports/queries.js` và `backend/modules/registrations/queries.js`. Frontend chỉ hiển thị kết quả từ API.
- Đã sửa xử lý trạng thái đăng nhập và giao diện màn hình nhỏ trong mã nguồn. Hôm qua đã kiểm tra bản local hiện đúng bước tạo ADMIN đầu tiên; phần CSS cuối cần dựng lại app.
- Đã thêm hướng dẫn đăng nhập ở `HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md`; tổng hợp việc đã làm ở `DA_THEM_VA_CHUA_CHAY.md`.

## Kiểm tra khi tiếp tục ngày 11/11

- Docker Engine chưa chạy ở lần kiểm tra đầu; chưa thể dựng lại app hoặc xác nhận trạng thái web hôm nay.
- Đang khởi động lại Docker, chỉ dựng lại dịch vụ app để áp dụng CSS đã sửa; không khởi tạo lại CSDL.
- Đang rà soát tài liệu và chuẩn bị kiểm tra giao diện desktop/điện thoại bằng các yêu cầu chỉ đọc.

## Các bước còn lại

1. Kiểm tra Docker sẵn sàng và khởi động lại app với mã nguồn hiện tại.
2. Kiểm tra web local và màn hình đăng nhập ở kích thước 390px; không tạo tài khoản thật để thử.
3. Ghi kết quả mới vào file này, hoàn thiện các hướng dẫn và báo người dùng vị trí file.

## Cách tiếp tục nếu phiên làm việc bị ngắt

Đọc file này trước, sau đó đọc `HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md`. Kiểm tra trạng thái thực tế trước khi thay đổi. Không chạy lại SQL sửa một lần trong `work/sua-khoi-tao-dang-nhap-20261110/` trên CSDL đã có dữ liệu.
