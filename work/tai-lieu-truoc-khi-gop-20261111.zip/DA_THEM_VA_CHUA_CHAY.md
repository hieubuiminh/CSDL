# Đã thêm gì, đã sửa gì và bạn cần làm gì?

Cập nhật ngày 10/11/2026, sau khi sửa lỗi web không đăng nhập được.

Phiên tiếp tục ngày 11/11/2026 được ghi riêng tại [TRANG_THAI_TIEP_TUC.md](TRANG_THAI_TIEP_TUC.md), gồm trạng thái dịch vụ mới nhất và phần đang làm.

## Đã hoàn tất trên máy

- Đã đưa đủ ba file tạo bảng, dữ liệu mẫu và truy vấn vào database/; dùng quan hệ mới qua Giay_Bao_Tu.CCCD_NgMat.
- Đã sao lưu CSDL local mới trước khi sửa: work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql.
- Đã sửa collation mặc định của CSDL và tạo lại 6 trigger trên bản khởi tạo dở.
- Đã nạp đủ 491 bản ghi mẫu và tạo bảng tài khoản App_User, giữ nguyên volume và CSDL cũ.
- Đã sửa healthcheck: ứng dụng chỉ được khởi chạy sau khi đăng nhập MySQL và đọc được bảng tài khoản.
- Đã sửa giao diện: khi máy chủ chưa sẵn sàng, ẩn form đăng nhập, hiện lỗi và nút Thử lại; không gửi yêu cầu đăng nhập sai trạng thái.
- Đã dựng lại image và khởi động bản local tại http://localhost:3001. CSDL healthy, API trạng thái trả 200 và yêu cầu tạo ADMIN đầu tiên nếu chưa có ADMIN.
- Đã thêm truy vấn backend tại backend/modules/reports/queries.js và backend/modules/registrations/queries.js; từng module API thực thi SQL và trả kết quả cho web.
- Đã bổ sung kiểm thử Docker khởi tạo lần đầu + HTTP thật: 52/52 đạt, gồm tạo ADMIN, đăng xuất, đăng nhập, quyền cán bộ và các API báo cáo. Giao diện xử lý lỗi và bước tạo ADMIN cũng đã kiểm tra riêng.

## Bạn làm tiếp

1. Mở http://localhost:3001 và nhấn Ctrl+F5.
2. Nếu hiện Tạo tài khoản quản trị, tự chọn tên đăng nhập, mật khẩu tối thiểu 10 ký tự và câu hỏi khôi phục để tạo ADMIN.
3. Sau này dùng chính tài khoản này để đăng nhập. Tài khoản CSDL cũ không tự mang sang; không có mật khẩu ADMIN mẫu.

Hướng dẫn đầy đủ: [đăng nhập và sửa lỗi khởi tạo](HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

## Giữ nguyên và chưa thực hiện

- Không xóa hoặc đưa CSDL cũ vào thùng rác; không xóa volume nào.
- Không tự tạo ADMIN/mật khẩu thay bạn trên CSDL đang dùng. Tài khoản thử chỉ được tạo trong môi trường kiểm thử đã xóa.
- Không xuất bản ứng dụng hoặc dữ liệu lên hosting/cloud, không tạo tunnel. Web chỉ mở 127.0.0.1:3001, MySQL không có cổng ra ngoài.
