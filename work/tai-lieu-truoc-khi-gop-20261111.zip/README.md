# Hệ thống quản lý đăng ký khai tử — bộ bảng mới

**Chỉ chạy trên máy cá nhân.** Bản mới dùng http://localhost:3001; MySQL không mở cổng ra ngoài. Không xuất bản lên hosting/cloud hoặc tạo tunnel.

Bắt đầu bằng [hướng dẫn khởi tạo CSDL mới](HUONG_DAN_KHOI_TAO_CSDL_MOI.md). Xem [trạng thái đã làm](DA_THEM_VA_CHUA_CHAY.md) và [hướng dẫn đăng nhập, sửa lỗi khởi tạo](HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

Nếu phiên làm việc bị ngắt, đọc [trạng thái để tiếp tục](TRANG_THAI_TIEP_TUC.md) để biết phần đã hoàn tất, kết quả kiểm tra gần nhất và việc còn lại.

## Chạy lần đầu

Mở Docker Desktop rồi chạy PowerShell:

~~~powershell
cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
~~~

Bản local trên máy hiện đã được khôi phục và đang chạy. Mở http://localhost:3001, nhấn Ctrl+F5 và tạo ADMIN lần đầu nếu chưa có. Tài khoản cũ không tự chuyển sang CSDL mới; không có mật khẩu ADMIN mẫu.

## Các file SQL đang dùng

| File | Vai trò |
|---|---|
| database/tao_bang.sql | Tạo bảng theo nguồn E:/CSDL/tao_bang.sql, bỏ DROP DATABASE và bổ sung trigger liên bảng. |
| database/du_lieu_mau.sql | Giữ nguyên 491 bản ghi từ file mẫu người dùng gửi, nạp riêng sau tạo bảng. |
| database/truy_van.sql | Bảy truy vấn theo nguồn E:/CSDL/truy_van.sql. |
| database/app_setup.sql | Tạo bảng tài khoản ứng dụng, không thay thế 9 bảng nghiệp vụ. |

CSDL mới: **quan_li_khai_tu**. CCCD người mất nằm ở Giay_Bao_Tu; Ho_So_Khai_Tu liên kết qua SoGiayBaoTu. Không dùng mô hình cũ chứa CCCD_NgMat trong Ho_So_Khai_Tu.

## Dữ liệu mẫu và báo cáo

Có 200 công dân, 100 giấy báo tử, 100 hồ sơ, 64 an táng; cùng các danh mục nguyên nhân, CSYT, UBND, cán bộ và 8 địa bàn.

Nguồn đếm theo bộ truy vấn mới: giới tính 100 công dân đã mất; tuổi theo 81 hồ sơ đã duyệt; địa bàn năm 2026 có 73 hồ sơ không bị từ chối; năm mất 2024/2025/2026 lần lượt 8/16/76. Quý III/2026 có một CSYT cấp 52 giấy. Số/tỷ lệ mất tại CSYT là ước tính từ chuỗi tên/địa chỉ.

ADMIN quản lý tài khoản và danh mục. Cán bộ tạo/xử lý hồ sơ, tra cứu và xem báo cáo. Backend và từng báo cáo vẫn tách thành các module riêng.

## Truy vấn trong backend

- backend/modules/reports/queries.js: SQL cho các báo cáo, dùng chung với tổng quan.
- backend/modules/registrations/queries.js: SQL danh sách, tra cứu hồ sơ.
- backend/modules/reports/*/index.js: nhận bộ lọc, chạy SQL và trả kết quả cho web.
- Frontend trong public/ hiển thị kết quả, không chạy SQL trực tiếp.

## Giữ bản cũ

Docker dùng dự án khai-tu-bang-moi-local, image khai-tu-app:bang-moi và volume mới. CSDL cũ chưa bị xóa. SQL, tài liệu và cấu hình cũ được lưu tại work/truoc-khi-dung-bang-moi-20261110/.

Không chạy lại file nâng cấp của mô hình cũ trên bộ bảng mới. Cách quay về bản cũ nằm trong hướng dẫn khởi tạo.

## Kiểm tra

Kiểm tra SQL ban đầu đạt 45/45, nhưng chưa bao phủ việc Docker tạo sẵn CSDL với collation khác. Đã bổ sung kiểm thử khởi tạo Docker thực tế và HTTP thật: **52/52 đạt**, gồm tạo ADMIN, đăng xuất, đăng nhập, phân quyền cán bộ và các API dữ liệu. 491 bản ghi khớp checksum nguồn. Kết quả: work/new-schema-review/docker-first-init-results.json; các container thử đã được xóa.

Kiểm tra backend bằng npm test với Node.js từ 20 trở lên và thư viện đã cài. Đây là kiểm thử dữ liệu giả; không kết nối CSDL người dùng.

Các lần sửa SQL sau này không tự cập nhật một volume MySQL đã có dữ liệu. Xem [hướng dẫn đầy đủ](HUONG_DAN_KHOI_TAO_CSDL_MOI.md) trước khi nạp lại.
