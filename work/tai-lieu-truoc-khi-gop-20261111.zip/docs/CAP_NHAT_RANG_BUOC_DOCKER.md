# Đã chuyển sang bộ bảng mới

Hướng dẫn hiện tại nằm tại [Khởi tạo CSDL mới](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md). Bản ngày 10/11/2026 dùng CSDL `quan_li_khai_tu`; không áp dụng file nâng cấp của mô hình trước vào bộ bảng này. Nếu cần mở web hoặc tạo tài khoản, xem [Đăng nhập và sửa lỗi khởi tạo](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

Bộ SQL đang dùng:

- `database/tao_bang.sql`: chín bảng và sáu trigger.
- `database/du_lieu_mau.sql`: dữ liệu mẫu giữ nguyên giá trị người dùng cung cấp.
- `database/truy_van.sql`: bảy truy vấn báo cáo.
- `database/app_setup.sql`: bảng tài khoản web, không tạo sẵn tài khoản.

Docker dùng project riêng `khai-tu-bang-moi-local`, image `khai-tu-app:bang-moi` và volume mới. Project, volume và image `khai-tu-app:1.0` của bản trước được giữ nguyên. Không dùng lại volume CSDL cũ cho mô hình bảng mới.

Ngày 10/11/2026, project mới đã khởi động và được sửa lỗi khởi tạo collation. CSDL có đủ 491 bản ghi mẫu; web tại [127.0.0.1:3001](http://127.0.0.1:3001) đã kiểm tra được luồng tạo ADMIN đầu tiên. Không cần nạp lại SQL trên máy đã được sửa.

Nội dung hướng dẫn trước đã lưu trong `work/truoc-khi-dung-bang-moi-20261110/`. Đây là lịch sử, không phải quy trình đang áp dụng. Xem [phạm vi kiểm thử hiện tại](KIEM_THU_SQL_BAO_CAO.md).
