# Hướng dẫn thành viên chạy bộ bảng mới

Đọc [hướng dẫn khởi tạo CSDL mới](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md) để cài trên máy khác và [hướng dẫn đăng nhập](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md) để dùng project hiện tại. Tài liệu này là phần tra cứu nhanh cho phiên bản ngày 10/11/2026.

Cần Docker Desktop đang hoạt động và toàn bộ thư mục mã nguồn dự án. Docker có thể tải image và thư viện khi dựng lần đầu; không cần cài MySQL Server hoặc Node.js trực tiếp trên máy. Image cũ `khai-tu-app:1.0` không thay thế cho bản mới `khai-tu-app:bang-moi`.

Tại thư mục gốc dự án, chạy:

```powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
```

Khi dịch vụ sẵn sàng, mở [127.0.0.1:3001](http://127.0.0.1:3001), nhấn Ctrl+F5 nếu trình duyệt còn trang cũ. Khi web hiển thị thiết lập ban đầu, tạo tài khoản ADMIN: mật khẩu ít nhất 10 ký tự, chọn câu hỏi khôi phục và nhập câu trả lời ít nhất 3 ký tự. Dữ liệu mẫu không chứa tài khoản hoặc mật khẩu đăng nhập. Nếu ADMIN đã được tạo, dùng tài khoản của project này để đăng nhập.

Tài khoản của bản cũ ở cổng 3000 không tự chuyển sang cổng 3001. Mỗi máy có volume và tài khoản riêng, dữ liệu không tự đồng bộ giữa thành viên.

Bộ khởi tạo gồm `database/tao_bang.sql`, `database/du_lieu_mau.sql` và `database/app_setup.sql`. File `database/truy_van.sql` dùng để đọc bảy báo cáo, không phải file nạp dữ liệu. Mẫu có 200 công dân, 100 giấy báo tử, 100 hồ sơ và 64 bản ghi an táng.

Các truy vấn dùng khi mở web đã nằm trong backend:

- [backend/modules/reports/queries.js](../backend/modules/reports/queries.js): thống kê giới tính, năm mất, địa bàn, nguyên nhân theo tuổi và cơ sở y tế.
- [backend/modules/registrations/queries.js](../backend/modules/registrations/queries.js): danh sách và tra cứu hồ sơ, lấy người mất qua giấy báo tử.

Các module API gọi truy vấn và trả dữ liệu cho giao diện trong `public/`. Trình duyệt chỉ hiển thị kết quả; không cần chạy thủ công `database/truy_van.sql` mỗi lần mở báo cáo trên web.

Tra cứu trạng thái dịch vụ hoặc xem nhật ký:

```powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml ps
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml logs --tail 100
```

Tạm dừng rồi mở lại mà giữ dữ liệu:

```powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml stop
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml start
```

Giữ nguyên project và volume cũ. Không thêm tùy chọn xóa volume khi dừng, vì volume chứa dữ liệu và tài khoản. Không tự chạy các hướng dẫn lịch sử trong `work/truoc-khi-dung-bang-moi-20261110/` bằng cấu hình Compose hiện tại.

Trên máy đang làm việc, project mới đã chạy và sửa lỗi khởi tạo ngày 10/11/2026, có đủ 491 bản ghi mẫu. Không nạp lại SQL hoặc xóa volume để xử lý đăng nhập. Các kiểm tra khởi tạo Docker và API đạt 52/52; xem [kết quả kiểm thử](KIEM_THU_SQL_BAO_CAO.md).
