# Chỉ chạy trên máy cá nhân

Cấu hình hiện tại phục vụ bộ bảng mới của CSDL `quan_li_khai_tu`, không xuất bản website hoặc mở truy cập từ mạng bên ngoài. Xem [hướng dẫn khởi tạo](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md) và [hướng dẫn đăng nhập](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

Các thiết lập trong `docker/compose.yaml`:

- Project `khai-tu-bang-moi-local`, image `khai-tu-app:bang-moi` và volume riêng với bản trước.
- Web ánh xạ `127.0.0.1:3001:3000`; địa chỉ trên máy là [127.0.0.1:3001](http://127.0.0.1:3001).
- MySQL không công bố cổng ra máy; ứng dụng kết nối dịch vụ `db` trong mạng Docker.
- `BIND_HOST=0.0.0.0` là địa chỉ nghe bên trong container. Cổng trên máy vẫn giới hạn ở `127.0.0.1`.
- CSS, JavaScript và API nghiệp vụ được phục vụ cùng ứng dụng; không có bước đưa hồ sơ lên hosting hoặc tạo tunnel.

Chạy Node trực tiếp vẫn mặc định nghe `127.0.0.1`; hướng dẫn chính hiện tại dùng Docker để đồng bộ bộ bảng mới. Không đổi ánh xạ cổng thành địa chỉ mạng bên ngoài khi chưa có yêu cầu mới.

Docker có thể cần Internet để tải image/thư viện trong lúc dựng. Đây là bước cài đặt, không phải xuất bản ứng dụng.

Ngày 10/11/2026, project mới đã được khởi động, sửa lỗi khởi tạo và kiểm tra trên máy. Web tại cổng 3001 và CSDL đã sẵn sàng; CSDL có 491 bản ghi mẫu. Project, volume và dữ liệu cũ không bị thay đổi. Người dùng mở web để tạo ADMIN đầu tiên nếu chưa có tài khoản của project mới.

Các lượt kiểm thử độc lập vẫn dùng container riêng, không công bố cổng hoặc gắn volume dự án; container thử đã được xóa. Xem [kết quả kiểm thử](KIEM_THU_SQL_BAO_CAO.md).
