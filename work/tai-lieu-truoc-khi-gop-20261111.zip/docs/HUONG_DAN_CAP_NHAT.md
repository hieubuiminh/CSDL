# Dùng phiên bản bảng mới trên máy cá nhân

Lần thay đổi này tạo một môi trường riêng cho CSDL `quan_li_khai_tu`, không nâng cấu trúc trực tiếp trên CSDL cũ. Project mới đã khởi động và sửa lỗi khởi tạo trên máy ngày 10/11/2026. Để dùng ngay, xem [hướng dẫn đăng nhập](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md); để cài trên máy khác, xem [hướng dẫn khởi tạo đầy đủ](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md).

Project hiện tại là `khai-tu-bang-moi-local`; Compose nằm ở `docker/compose.yaml`; image được dựng với tên `khai-tu-app:bang-moi`. Web chỉ mở tại [127.0.0.1:3001](http://127.0.0.1:3001). Giữ nguyên các volume của project trước.

Trên máy đã sửa, mở [127.0.0.1:3001](http://127.0.0.1:3001) và nhấn Ctrl+F5. Nếu web yêu cầu thiết lập ban đầu, tạo ADMIN với mật khẩu ít nhất 10 ký tự và câu hỏi khôi phục. Không có tài khoản mẫu; tài khoản cũ ở cổng 3000 không tự chuyển sang đây.

Khi cần dựng hoặc mở lại project bằng mã nguồn hiện tại, chạy tại thư mục gốc dự án:

```powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
```

Compose nạp bộ schema, dữ liệu mẫu và bảng tài khoản khi volume mới được khởi tạo lần đầu. Những lần chạy sau giữ dữ liệu của volume mới; không tự nạp lại SQL và không tự cập nhật cấu trúc chỉ vì file nguồn đã đổi.

Nếu đã có dữ liệu cần chuyển từ một mô hình khác, cần kế hoạch sao lưu và chuyển đổi riêng. Không nạp lại schema vào CSDL đang có hoặc xóa volume để ép khởi tạo. Hướng dẫn nâng cấp của mô hình trước đã được lưu trong `work/truoc-khi-dung-bang-moi-20261110/` và không còn là hướng dẫn hiện tại.

Trước khi sửa, transaction dữ liệu mẫu đã rollback nên cả chín bảng nghiệp vụ rỗng. Sau sao lưu và sửa, CSDL có đủ 491 bản ghi mẫu; sáu trigger và default CSDL cùng dùng `utf8mb4_unicode_ci`. Healthcheck kiểm đăng nhập TCP và bảng `App_User` trước khi mở ứng dụng. Máy đã sửa không cần chạy lại SQL hoặc xóa volume.

Kiểm thử SQL ban đầu đạt 45/45; kiểm tra bổ sung khởi tạo Docker và API đạt 52/52. Xem [phạm vi kiểm thử](KIEM_THU_SQL_BAO_CAO.md).
