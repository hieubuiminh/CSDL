# Kết quả kiểm thử bộ bảng mới

Ngày 10/11/2026, lượt kiểm tra bổ sung đường khởi tạo Docker thực tế và API đạt **52/52**, gồm **24 kiểm tra HTTP**, trên MySQL **8.0.46**. Nguồn kết quả: [docker-first-init-results.json](../work/new-schema-review/docker-first-init-results.json).

| Nội dung | Kết quả |
|---|---|
| Docker tự tạo CSDL qua `MYSQL_DATABASE`, rồi chạy ba file khởi tạo | Thành công |
| Default CSDL và collation lưu trong cả sáu trigger | Đều là `utf8mb4_unicode_ci` |
| So sánh chín bảng với bản lưu mẫu người dùng | Giữ nguyên 491 bản ghi và giá trị các cột |
| Cấu trúc | 9 FK, 7 CHECK, 4 UNIQUE và 6 trigger |
| Bảy truy vấn SQL và các API đọc tương ứng | Khớp số liệu mẫu |
| Tạo ADMIN, đăng xuất, đăng nhập lại; tạo và đăng nhập cán bộ | Thành công qua HTTP |
| Cán bộ truy cập quản trị tài khoản | Bị từ chối với HTTP 403 |
| Tài khoản có sẵn trong dữ liệu mẫu | Không có; lần đầu yêu cầu thiết lập ADMIN |

Lượt SQL ban đầu đạt **45/45**, lưu tại [sql-test-results.json](../work/new-schema-review/sql-test-results.json). Lượt đó kiểm tra các trường hợp vi phạm: người khai trùng người mất; ngày mất sau ngày cấp; ngày đăng ký trước ngày cấp; sửa giấy báo tử gây sai liên kết; trùng công dân/giấy báo tử; CCCD không phải chữ số ASCII; mã giấy quá 20 ký tự. Cũng kiểm tra đồng bộ `Đã mất` khi hồ sơ không bị từ chối và khi đổi người mất trên giấy báo tử đã liên kết.

Giới hạn của lượt 45 kiểm tra là tạo CSDL sẵn với collation chuẩn, nên chưa phát hiện đường Docker tự tạo CSDL mặc định `utf8mb4_0900_ai_ci`. Khi khởi tạo thật, bảng dùng `utf8mb4_unicode_ci` nhưng biến ký tự trong trigger kế thừa default khác, gây lỗi 1267 ở INSERT hồ sơ. Nguồn hiện tại đã thêm `ALTER DATABASE` trước khi tạo trigger; lượt 52 kiểm tra tái hiện đúng đường khởi tạo này. Hai lượt có phạm vi khác nhau, không cộng thành một bộ kiểm tra duy nhất.

Số liệu đối chiếu qua API: 100 hồ sơ; 100 công dân đã mất; 8 địa bàn với 73 hồ sơ không từ chối đăng ký trong năm 2026; 81 hồ sơ đã duyệt dùng cho thống kê tuổi; một CSYT cấp 52 giấy trong quý III/2026; số giấy báo tử theo năm mất 2024/2025/2026 lần lượt là 8/16/76. Những tổng khác nhau phản ánh bộ lọc của từng truy vấn.

Các container kiểm thử dùng dữ liệu tạm, không công bố cổng hoặc gắn volume dự án và đã được xóa. Trong lượt HTTP, container ứng dụng dùng chung không gian mạng với container CSDL thử. Các kết quả 88 kiểm tra của mô hình trước thuộc bản lưu lịch sử, không dùng để xác nhận bộ bảng mới.

Riêng project mới trên máy này đã được sửa và khởi động ngày 10/11/2026. Trước sửa, cả chín bảng nghiệp vụ có 0 dòng do transaction seed rollback; sau sao lưu, sửa sáu trigger và nạp lại trên các bảng đã xác nhận rỗng, CSDL có đủ 491 dòng mẫu. Bản sao lưu trước sửa nằm tại `work/sua-khoi-tao-dang-nhap-20261110/khai_tu_truoc_sua_dang_nhap_20261110.sql`. Project cũ không bị thay đổi.

Ứng dụng và CSDL mới đã qua healthcheck; API trạng thái trả HTTP 200 với `setupRequired: true` trước khi tạo tài khoản. Healthcheck hiện đăng nhập TCP bằng người dùng CSDL của ứng dụng và truy vấn bảng `App_User`, thay vì chỉ kiểm server còn sống. Giao diện mở tại [127.0.0.1:3001](http://127.0.0.1:3001) đã được kiểm tra hiển thị thiết lập ban đầu. Đây chưa phải kiểm thử mọi thao tác trên giao diện.

Máy đã sửa không cần nạp lại SQL. Làm theo [hướng dẫn đăng nhập](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md); cài trên máy khác theo [hướng dẫn khởi tạo](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md).
