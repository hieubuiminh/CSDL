# Đối chiếu bộ bảng đang dùng

Từ ngày 10/11/2026, nguồn quyết định cấu trúc là `E:/CSDL/tao_bang.sql`, `E:/CSDL/truy_van.sql` và file dữ liệu mẫu người dùng cung cấp. Xem [bản đối chiếu hiện tại](../DOI_CHIEU_BAO_CAO_SQL.md) và [hướng dẫn khởi tạo](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md).

Các bản dùng trong dự án nằm tại `database/tao_bang.sql`, `database/du_lieu_mau.sql`, `database/truy_van.sql`. Bản lưu nguồn người dùng nằm trong `work/truoc-khi-dung-bang-moi-20261110/nguon-nguoi-dung/`; không phụ thuộc file dữ liệu mẫu ở thư mục gốc. Bản schema trong dự án bỏ thao tác xóa CSDL, bổ sung sáu trigger kiểm tra liên bảng và đặt default collation của CSDL thành `utf8mb4_unicode_ci` trước khi tạo trigger.

Những điểm cần nhớ khi đọc mã:

- Người mất nằm tại `Giay_Bao_Tu.CCCD_NgMat`, có UNIQUE và FK đến công dân. Hồ sơ lấy người mất qua giấy báo tử, không lưu thêm cột người mất.
- Số giấy báo tử và số hồ sơ tối đa 20 ký tự; trạng thái hồ sơ mặc định `Chờ xử lý`.
- CSDL dùng tên `quan_li_khai_tu`. Bảng tài khoản vẫn là phần bổ sung riêng trong `app_setup.sql`.
- Báo cáo giới tính đếm công dân `Đã mất`; tuổi chỉ lấy hồ sơ `Đã duyệt`; năm đếm giấy báo tử. Vì khác nguồn đếm nên tổng có thể khác nhau.

Bản đối chiếu PDF và bộ SQL trước nằm trong `work/truoc-khi-dung-bang-moi-20261110/`; không dùng tài liệu lịch sử đó để khởi tạo bộ bảng hiện tại. Kiểm thử ban đầu đạt 45/45 SQL; lượt kiểm tra bổ sung đường khởi tạo Docker và API đạt 52/52. Xem [kết quả và giới hạn kiểm thử](KIEM_THU_SQL_BAO_CAO.md).

Project mới đã chạy trên máy ngày 10/11/2026 với đủ 491 bản ghi mẫu. Lỗi collation khi khởi tạo lần đầu đã được sửa; xem [hướng dẫn đăng nhập hiện tại](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md). Tài khoản của ứng dụng cũ ở cổng 3000 không tự chuyển sang project mới.
