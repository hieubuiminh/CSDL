# Ràng buộc của bộ bảng mới

Tài liệu hiện tại áp dụng cho `database/tao_bang.sql`, CSDL `quan_li_khai_tu`. Xem [hướng dẫn khởi tạo](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md), [hướng dẫn đăng nhập](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md) và [kết quả kiểm thử SQL, Docker và API](KIEM_THU_SQL_BAO_CAO.md).

| Quy tắc | Cách bảo vệ trong mô hình hiện tại |
|---|---|
| Người khai khác người mất | Trigger khi thêm/sửa hồ sơ đối chiếu người khai với `Giay_Bao_Tu.CCCD_NgMat`; sửa giấy báo tử cũng kiểm tra hồ sơ liên quan. |
| Ngày mất ≤ ngày cấp ≤ ngày đăng ký | CHECK trên giấy báo tử và trigger khi thêm/sửa hồ sơ hoặc sửa giấy báo tử đã liên kết. So sánh theo ngày. |
| Một người có tối đa một hồ sơ | Người mất là UNIQUE trong giấy báo tử; số giấy báo tử là UNIQUE trong hồ sơ. Hai ràng buộc kết hợp bảo đảm tính duy nhất. |
| Đồng bộ trạng thái công dân | Trigger đánh dấu `Đã mất` cho hồ sơ không bị từ chối khi thêm/sửa; thay người mất trên giấy báo tử đã liên kết cũng đồng bộ người mới. Không tự suy ra người cũ còn sống. |

Bộ bảng có 9 khóa ngoại, 7 CHECK, 4 UNIQUE và 6 trigger. `Ho_So_Khai_Tu` không lưu cột người mất; việc kiểm tra và truy vấn phải lấy người mất qua giấy báo tử. Hồ sơ mặc định `Chờ xử lý`.

Mẫu người dùng đã được nạp và kiểm tra trong container thử riêng; không phát hiện vi phạm các điều kiện đã kiểm. Kiểm thử SQL ban đầu đạt 45/45; kiểm tra bổ sung đường khởi tạo Docker và API đạt 52/52.

Trên project mới của máy này, ngày 10/11/2026 đã sửa lỗi collation và nạp đủ 491 bản ghi mẫu sau khi xác nhận cả chín bảng nghiệp vụ rỗng và sao lưu. Default CSDL và cả sáu trigger hiện dùng `utf8mb4_unicode_ci`. Đây không phải kết quả kiểm tra hay thay đổi dữ liệu của project CSDL cũ.

Hướng dẫn và script kiểm tra của mô hình trước đã có bản lưu trong `work/truoc-khi-dung-bang-moi-20261110/`. Không chạy script lịch sử theo mô hình cũ trên bộ bảng mới. Chỉ dùng các file đang được chỉ định trong hướng dẫn khởi tạo hiện tại.
