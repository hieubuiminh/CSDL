# Ghi chú mở rộng sau bộ bảng mới

Đây là đề xuất thiết kế, không phải hướng dẫn sửa CSDL hay yêu cầu pháp lý. Bộ bảng đang dùng là `database/tao_bang.sql`, CSDL `quan_li_khai_tu`; nguồn người dùng được ưu tiên thay cho bản đối chiếu PDF trước. Xem [bản đối chiếu hiện tại](../DOI_CHIEU_BAO_CAO_SQL.md).

Bốn quy tắc cốt lõi đã được bảo vệ bằng khóa, CHECK và sáu trigger, đồng thời được kiểm thử trong môi trường riêng. Lượt kiểm tra bổ sung khởi tạo Docker và API ngày 10/11/2026 đạt 52/52; project mới trên máy cũng đã chạy với đủ 491 bản ghi mẫu sau sửa lỗi collation. Xem [phạm vi kiểm thử](KIEM_THU_SQL_BAO_CAO.md) và [hướng dẫn đăng nhập](../HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

Các mục dưới đây chưa được tự động thêm vào mô hình:

- Kiểm soát ngày sinh ≤ ngày mất và ngày an táng ≥ ngày mất cả khi sửa công dân, giấy báo tử hoặc an táng; kiểm tra lúc tạo hồ sơ chưa bao phủ mọi lần cập nhật sau đó.
- Đối chiếu thông tin công dân có CCCD sẵn để phát hiện khác biệt họ tên/ngày sinh, thay vì chỉ tái sử dụng bản ghi hiện có.
- Lưu lịch sử xử lý, người sửa, lý do từ chối/đính chính và quy trình mở lại hồ sơ; tránh coi việc xóa hồ sơ là cách sửa dữ liệu thông thường.
- Lưu trực tiếp UBND tại thời điểm tiếp nhận nếu cần giữ lịch sử khi cán bộ chuyển đơn vị.
- Bổ sung địa bàn có cấu trúc và trường xác nhận nơi mất tại CSYT nếu cần thống kê chính xác hơn phạm vi danh mục hoặc phép dò chuỗi tên/địa chỉ.

Mọi mở rộng cần thống nhất trước khi sửa nguồn. Không tự chuyển công dân về `Còn sống` chỉ vì hồ sơ bị từ chối hoặc bị xóa. Không chuyển dữ liệu giữa bộ bảng cũ và mới bằng cách nạp lại schema.

Nội dung đề xuất và kiểm tra của các phiên bản trước nằm trong `work/truoc-khi-dung-bang-moi-20261110/` để tham khảo lịch sử; không dùng các hướng dẫn đó làm quy trình đang áp dụng. Để dùng bộ hiện tại, làm theo [hướng dẫn khởi tạo](../HUONG_DAN_KHOI_TAO_CSDL_MOI.md).
