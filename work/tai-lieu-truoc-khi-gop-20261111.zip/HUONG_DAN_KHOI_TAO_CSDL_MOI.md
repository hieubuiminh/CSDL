# Bắt đầu ở đây: khởi tạo CSDL theo bảng mới

Bộ này dùng đúng cấu trúc bạn cung cấp ngày 10/11/2026. CSDL có tên **quan_li_khai_tu**. Người mất nằm ở **Giay_Bao_Tu.CCCD_NgMat**; hồ sơ khai tử liên kết qua số giấy báo tử.

**Cập nhật ngày 10/11/2026: bản local trên máy đã được sửa lỗi khởi tạo và đang chạy ở localhost:3001, đủ 491 bản ghi.** Bạn mở trang, nhấn Ctrl+F5 và tạo ADMIN đầu tiên nếu chưa có tài khoản. Xem [hướng dẫn đăng nhập và phần đã sửa](HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

Các bước bên dưới dành cho lần khởi tạo trên máy mới hoặc lúc cần mở lại dịch vụ. Không xóa CSDL cũ.

## 1. Ba file chính

| File trong dự án | Dùng để làm gì? |
|---|---|
| database/tao_bang.sql | Tạo 9 bảng và 6 trigger bảo vệ nghiệp vụ. |
| database/du_lieu_mau.sql | Nạp 491 bản ghi mẫu do bạn cung cấp. |
| database/truy_van.sql | Bảy truy vấn để tra cứu, thống kê; không tạo bảng hoặc nạp mẫu. |

database/app_setup.sql là phần bổ sung tạo bảng tài khoản web. Docker tự chạy file này sau dữ liệu mẫu; giữ file này.

Bộ nguồn gốc được lưu đối chiếu trong work/truoc-khi-dung-bang-moi-20261110/nguon-nguoi-dung/. Dùng **bản trong database/** để chạy với ứng dụng: bản tạo bảng này đã bỏ lệnh DROP DATABASE của nguồn gốc.

## 2. Mở Docker Desktop và PowerShell

Mở Docker Desktop, đợi Docker sẵn sàng. Trong PowerShell, chuyển đến dự án:

~~~powershell
cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
~~~

## 3. Khởi tạo và chạy bản mới

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
~~~

Đợi lệnh hoàn tất. Lần đầu, Docker tạo vùng lưu trữ mới rồi lần lượt chạy: tạo bảng → dữ liệu mẫu → bảng tài khoản. Không chạy lại các file SQL bằng tay sau bước này.

Tên dự án mới khai-tu-bang-moi-local và image khai-tu-app:bang-moi tách khỏi bản cũ. Các volume MySQL/cấu hình cũ vẫn giữ nguyên.

Trên máy hiện tại, dịch vụ đã được dựng và khôi phục thành công sau lỗi khởi tạo đầu tiên. Không cần chạy lại SQL tạo bảng/dữ liệu mẫu. Khi dựng trên máy mới, Docker có thể cần Internet để tải image/thư viện; website và CSDL vẫn chỉ phục vụ trên máy.

## 4. Mở ứng dụng

Mở **http://localhost:3001**.

Lần đầu, màn hình phải hiện **Tạo tài khoản quản trị**. Nhập họ tên, tên đăng nhập, mật khẩu tối thiểu 10 ký tự, nhập lại mật khẩu và câu hỏi/câu trả lời khôi phục, rồi tạo tài khoản. Sau này đăng nhập bằng chính tài khoản này.

Dữ liệu mẫu không có tài khoản hoặc mật khẩu ghi sẵn. Tài khoản của CSDL cũ ở cổng 3000 không tự chuyển sang CSDL mới. Nếu trang vẫn hiện lỗi cũ, nhấn Ctrl+F5.

Bạn sẽ có 200 công dân, 100 giấy báo tử, 100 hồ sơ khai tử và 64 bản ghi an táng. Có thể dùng CCCD mẫu **001000000001** để thử tra cứu.

Cổng MySQL không công bố ra ngoài. Không có bước đăng website lên hosting/cloud hoặc tạo tunnel.

## 5. Kiểm tra nếu chưa mở được

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml ps
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml logs --tail=80 db app
~~~

DB cần ở trạng thái healthy, ứng dụng ở trạng thái chạy. Healthcheck mới kiểm tra được bảng App_User bằng tài khoản ứng dụng qua TCP; ping MySQL đơn thuần chưa đủ xác nhận khởi tạo hoàn tất. Nếu cổng 3001 đang được ứng dụng khác dùng, cần xử lý trùng cổng trước khi khởi chạy.

Sửa SQL rồi build lại **không tự nạp lại** vào CSDL đã khởi tạo. Nếu lần đầu nạp lỗi hoặc bạn muốn nạp lại từ đầu, dừng để kiểm tra; không dùng down -v hoặc xóa volume đang chứa dữ liệu cần giữ.

## 6. Dừng và mở lại bản mới

Dừng nhưng giữ dữ liệu:

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml down
~~~

Mở lại:

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --no-build
~~~

Không thêm -v vào lệnh dừng nếu muốn giữ dữ liệu.

## 7. Nếu muốn quay về bản cũ

CSDL cũ chưa bị xóa hay đưa vào thùng rác. Cấu hình và SQL trước lần chuyển này được lưu trong work/truoc-khi-dung-bang-moi-20261110/.

Nếu muốn mở lại bản cũ, dùng cấu hình đã lưu và image cũ còn trên máy:

~~~powershell
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml down
docker compose -p he_thong_quan_ly_dang_ky_khai_tu -f work/truoc-khi-dung-bang-moi-20261110/docker/compose.yaml up -d --no-build
~~~

Bản cũ dùng http://localhost:3000 và vùng lưu trữ cũ. Không cần xóa hoặc ghi đè CSDL mới để quay lại.

## 8. Nếu chạy SQL bằng công cụ MySQL riêng

Chỉ thực hiện trên CSDL mới/riêng, MySQL từ 8.0.16:

1. Chạy database/tao_bang.sql.
2. Chạy database/du_lieu_mau.sql đúng một lần.
3. Chạy database/app_setup.sql nếu cần đăng nhập ứng dụng web.
4. Chạy database/truy_van.sql khi muốn xem bảy kết quả truy vấn.

File mẫu không dùng INSERT IGNORE hoặc REPLACE. Nếu bị trùng mã, dừng để kiểm tra; không tự ghi đè dữ liệu đã có.

Xem thêm [trạng thái đã làm](DA_THEM_VA_CHUA_CHAY.md) và [đối chiếu bảng mới](DOI_CHIEU_BAO_CAO_SQL.md).
