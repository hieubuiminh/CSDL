# Hướng dẫn sử dụng CSDL bảng mới

Bản hướng dẫn này thay hướng dẫn migration của mô hình cũ. Bộ đang dùng gồm database/tao_bang.sql, database/du_lieu_mau.sql và database/truy_van.sql; CSDL tên quan_li_khai_tu.

**Đọc và thực hiện theo [hướng dẫn khởi tạo CSDL mới](HUONG_DAN_KHOI_TAO_CSDL_MOI.md).**

Lệnh khởi tạo bản mới trên máy:

~~~powershell
cd E:\CSDL\he_thong_quan_ly_dang_ky_khai_tu
docker compose -p khai-tu-bang-moi-local -f docker/compose.yaml up -d --build
~~~

Sau đó mở http://localhost:3001. Docker tự tạo bảng, nạp 491 bản ghi mẫu và tạo bảng tài khoản. Lần đầu thiết lập ADMIN trên web.

Cấu hình này dùng volume riêng, không xóa CSDL cũ. Các file SQL và cấu hình trước đây được lưu ở work/truoc-khi-dung-bang-moi-20261110/. Không chạy cap_nhat_rang_buoc.sql cũ trên cấu trúc mới.

Bản local trên máy đã được khôi phục sau lỗi khởi tạo: đủ 491 bản ghi, có bảng App_User và dịch vụ đang chạy. Bạn không cần chạy lại SQL mẫu; mở localhost:3001, nhấn Ctrl+F5 rồi tạo ADMIN lần đầu nếu chưa có. Đọc [hướng dẫn đăng nhập và phần đã sửa](HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md) và [trạng thái công việc](DA_THEM_VA_CHUA_CHAY.md).

