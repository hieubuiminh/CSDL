# Đối chiếu bộ SQL mới người dùng cung cấp

Bộ nguồn đã được lưu đối chiếu trong work/truoc-khi-dung-bang-moi-20261110/nguon-nguoi-dung/. Bộ đang dùng nằm trong database/.

## Đã đưa vào dự án

- database/tao_bang.sql dùng cấu trúc mới: Giay_Bao_Tu chứa CCCD_NgMat UNIQUE/FK; Ho_So_Khai_Tu không lưu trùng CCCD người mất.
- database/du_lieu_mau.sql giữ nguyên giá trị của toàn bộ 491 bản ghi, không chuyển CCCD sang hồ sơ như phiên bản trước.
- database/truy_van.sql dùng đúng quan hệ và nguồn đếm của file truy vấn mới; thêm cấu hình mã hóa và múi giờ Việt Nam.
- database/app_setup.sql tạo tài khoản ứng dụng trên CSDL mới quan_li_khai_tu.

Bản tạo bảng dùng trong ứng dụng bỏ DROP DATABASE, dùng CREATE DATABASE IF NOT EXISTS và mã hóa utf8mb4_unicode_ci cho các bảng. File tạo bảng và dữ liệu mẫu tách riêng, không nạp mẫu hai lần.

## Ràng buộc bổ sung

Sáu trigger bảo đảm người khai khác người mất; ngày mất ≤ ngày cấp giấy ≤ ngày đăng ký; bảo vệ khi thêm/sửa hồ sơ hoặc sửa giấy báo tử; đánh dấu công dân đã mất với hồ sơ không bị từ chối. Khi đổi người mất trên giấy báo tử đã gắn hồ sơ hợp lệ, trạng thái người mới được đồng bộ. Không tự suy ra người cũ còn sống.

Mặc định hồ sơ mới là **Chờ xử lý**, đúng bảng mới. Theo quy tắc không bị từ chối, hồ sơ chờ xử lý vẫn đánh dấu đã mất. Một giấy báo tử cho mỗi người, một hồ sơ cho mỗi giấy được bảo đảm bằng UNIQUE.

## Vì sao tổng các báo cáo khác nhau?

Bộ truy vấn mới chủ động dùng các nguồn đếm khác nhau:

| Báo cáo | Phạm vi của dữ liệu mẫu |
|---|---|
| Giới tính | 100 công dân có trạng thái Đã mất. |
| Toàn bộ hồ sơ | 100 hồ sơ: 81 đã duyệt, 15 chờ xử lý, 4 từ chối. |
| Địa bàn năm 2026 | 73 hồ sơ không bị từ chối trong năm đăng ký 2026. |
| Nguyên nhân theo tuổi | 81 hồ sơ đã duyệt; các nhóm tuổi lần lượt 1, 17, 63. |
| CSYT quý III/2026 | CS01 cấp 52 giấy, vượt ngưỡng 50. |
| Theo năm mất | Tất cả giấy báo tử: 2024=8, 2025=16, 2026=76. |

Tỷ lệ mất tại CSYT là ước tính bằng đối chiếu tên/địa chỉ, không phải trường dữ liệu nơi mất chuyên biệt. Địa bàn lấy toàn bộ Xã/Phường trong danh mục thuộc phạm vi Hà Nội của bộ dữ liệu; bảng chưa có tỉnh/thành để lọc dữ liệu ngoài phạm vi.

## Trạng thái bàn giao

SQL ban đầu đã qua 45 kiểm tra riêng nhưng chưa bao phủ collation của CSDL do Docker tạo sẵn. Đã sửa bằng cách đặt default CSDL trước khi tạo trigger; các trigger trên bản khởi tạo dở đã được tạo lại. Đã bổ sung 52 kiểm tra Docker/HTTP thực tế, gồm đăng nhập và phân quyền; tất cả đạt, checksum 491 bản ghi không đổi.

Bản local mới đã được sao lưu, sửa và khởi động lại thành công; App_User đã có để tạo ADMIN đầu tiên. CSDL cũ không bị xóa. Xem [hướng dẫn sửa lỗi đăng nhập](HUONG_DAN_DANG_NHAP_VA_SUA_LOI_KHOI_TAO.md).

Đọc [hướng dẫn khởi tạo](HUONG_DAN_KHOI_TAO_CSDL_MOI.md) và [đã thêm/chưa chạy](DA_THEM_VA_CHUA_CHAY.md). Tài liệu cũ được giữ trong work/truoc-khi-dung-bang-moi-20261110/.
