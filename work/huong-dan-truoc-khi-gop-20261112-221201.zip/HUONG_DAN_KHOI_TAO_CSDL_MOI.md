# Hướng dẫn chạy website

Dự án sử dụng Docker để chạy ứng dụng Node.js và cơ sở dữ liệu MySQL. Sau khi khởi động, bạn truy cập website tại http://localhost:3001. Cấu hình hiện tại chỉ cho phép truy cập từ máy đang chạy ứng dụng.

## 1. Chuẩn bị

- Cài Docker Desktop và chuyển sang chế độ Linux containers.
- Tải hoặc clone mã nguồn về máy.
- Mở PowerShell hoặc terminal tại thư mục dự án, nơi có package.json và thư mục docker.
- Mở Docker Desktop và chờ Docker khởi động xong.

Lần chạy đầu cần Internet để Docker tải các thành phần chưa có. Bạn không cần cài riêng Node.js hoặc MySQL.

## 2. Khởi chạy lần đầu

Chạy lệnh sau trong thư mục dự án:

~~~powershell
docker compose -f docker/compose.yaml up -d --build
~~~

Docker sẽ dựng ứng dụng, tạo cơ sở dữ liệu và nạp dữ liệu mẫu. Quá trình này có thể mất vài phút ở lần đầu.

Để xem trạng thái các dịch vụ, chạy:

~~~powershell
docker compose -f docker/compose.yaml ps
~~~

Khi dịch vụ db hiển thị healthy và app đang chạy, mở trình duyệt tại:

http://localhost:3001

## 3. Đăng nhập và tạo tài khoản

Ở lần sử dụng đầu tiên, website hiển thị màn hình tạo tài khoản quản trị. Nhập họ tên, tên đăng nhập, mật khẩu có ít nhất 10 ký tự và thông tin khôi phục để tạo ADMIN.

Nếu màn hình đã hiển thị Đăng nhập, hãy dùng tài khoản đã tạo trên máy đó. Bộ dữ liệu mẫu không tạo sẵn tài khoản đăng nhập.

Để tạo tài khoản cán bộ, ADMIN vào mục Tài khoản, chọn vai trò Cán bộ và chọn cán bộ tiếp nhận cần liên kết. Mỗi cán bộ chỉ gắn với một tài khoản. Nếu đăng ký bằng mã mời, ADMIN cần chọn cán bộ trước khi cấp mã.

ADMIN xem được toàn bộ hồ sơ. Cán bộ chỉ xem hồ sơ do mình tiếp nhận và các thống kê tương ứng.

Bạn có thể đăng nhập bằng ADMIN, mở mục Hồ sơ để xem dữ liệu mẫu hoặc thử tra cứu CCCD 001000000001.

## 4. Dừng và mở lại website

Dừng các dịch vụ bằng lệnh:

~~~powershell
docker compose -f docker/compose.yaml stop
~~~

Khi cần mở lại, khởi động Docker Desktop rồi chạy:

~~~powershell
docker compose -f docker/compose.yaml up -d
~~~

Sau đó truy cập lại http://localhost:3001. Dữ liệu và tài khoản được giữ trong vùng lưu trữ của Docker. Không cần tạo bảng hay nạp lại dữ liệu mẫu mỗi lần mở web.

Mã nguồn trên GitHub không bao gồm dữ liệu và tài khoản trong Docker của máy khác. Khi cài trên máy mới, bạn sẽ tạo tài khoản ADMIN riêng.

## 5. Cập nhật mã nguồn

Khi dự án đang chạy và bạn muốn áp dụng thay đổi trong backend hoặc giao diện, chạy:

~~~powershell
docker compose -f docker/compose.yaml build app
docker compose -f docker/compose.yaml up -d --no-deps --no-build --force-recreate app
~~~

Mở lại trình duyệt và nhấn Ctrl + F5 để tải giao diện mới.

Việc dựng lại ứng dụng không tự cập nhật cấu trúc cơ sở dữ liệu đã có. Nếu phiên bản mới có thay đổi SQL, cần sao lưu và áp dụng tệp nâng cấp tương ứng. Docker chỉ tự chạy các tệp SQL khởi tạo khi vùng dữ liệu MySQL còn mới.

## 6. Nếu chưa mở được website

Kiểm tra Docker Desktop đã chạy, terminal đang ở đúng thư mục dự án và địa chỉ truy cập là http://localhost:3001.

Xem trạng thái và nhật ký bằng:

~~~powershell
docker compose -f docker/compose.yaml ps
docker compose -f docker/compose.yaml logs --tail=80 db app
~~~

Nếu MySQL đang khởi động, chờ db chuyển sang healthy rồi mở lại trang. Nếu cổng 3001 đang được chương trình khác sử dụng, cần xử lý việc trùng cổng trước khi chạy tiếp.

Khi giao diện chưa cập nhật, nhấn Ctrl + F5. Tránh xóa volume hoặc nạp lại SQL mẫu để thử xử lý lỗi, vì có thể làm mất hoặc trùng dữ liệu đang sử dụng.

